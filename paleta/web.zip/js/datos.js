/* Paleta — datos en el teléfono: configuración y jugadores (localStorage), sesiones con su esqueleto,
   fotogramas y video (IndexedDB). Todo queda en el teléfono; nada se sube a internet. */
"use strict";
const Datos = (() => {
  const KCFG = 'paleta_cfg', KJUG = 'paleta_jugadores';
  const leer = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const guardar = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { window.toast && toast('No se pudo guardar: memoria llena.'); } };
  const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  const cfg = () => leer(KCFG, { modo: null, activo: null });
  const setCfg = c => guardar(KCFG, Object.assign(cfg(), c));

  const jugadores = () => leer(KJUG, []);
  const jugador = i => jugadores().find(j => j.id === i) || null;
  function guardarJugador(j) {
    const l = jugadores(); if (!j.id) { j.id = id(); j.creado = new Date().toISOString(); }
    const k = l.findIndex(x => x.id === j.id); if (k >= 0) l[k] = j; else l.push(j);
    guardar(KJUG, l); return j;
  }
  function borrarJugador(i) { guardar(KJUG, jugadores().filter(j => j.id !== i)); sesiones(i).then(s => s.forEach(x => borrarSesion(x.id))); }
  function activo() {
    const c = cfg(); let j = c.activo && jugador(c.activo);
    if (!j && c.modo === 'alumno') j = jugadores().find(x => x.propio) || null;
    return j;
  }

  /* ---------- IndexedDB ---------- */
  let db = null;
  function abrir() {
    if (db) return Promise.resolve(db);
    return new Promise((ok, mal) => {
      const r = indexedDB.open('paleta', 1);
      r.onupgradeneeded = () => { const d = r.result; const s = d.createObjectStore('sesiones', { keyPath: 'id' }); s.createIndex('jugador', 'jugadorId'); };
      r.onsuccess = () => { db = r.result; ok(db); }; r.onerror = () => mal(r.error);
    });
  }
  async function tx(modo, fn) { const d = await abrir(); return new Promise((ok, mal) => { const t = d.transaction('sesiones', modo); const s = t.objectStore('sesiones'); const r = fn(s); t.oncomplete = () => ok(r && r.result); t.onerror = () => mal(t.error); }); }
  async function guardarSesion(s) { if (!s.id) s.id = id(); await tx('readwrite', st => st.put(s)); return s; }
  async function sesion(i) { return tx('readonly', st => st.get(i)); }
  async function sesiones(jugadorId) {
    const todas = await tx('readonly', st => jugadorId ? st.index('jugador').getAll(jugadorId) : st.getAll());
    /* lista liviana: sin cuadros ni video */
    return (todas || []).map(s => ({ id: s.id, jugadorId: s.jugadorId, fecha: s.fecha, golpeId: s.golpeId, golpeNombre: s.golpeNombre, puntaje: s.resumen && s.resumen.puntaje, fallas: s.resumen && s.resumen.fallas, demo: s.demo }))
      .sort((a, b) => (b.fecha || '').localeCompare(a.fecha || ''));
  }
  async function borrarSesion(i) { return tx('readwrite', st => st.delete(i)); }

  /* Respaldo: jugadores y sesiones (sin videos), para pasar a otro teléfono */
  async function respaldo() {
    const d = await abrir();
    const todas = await new Promise(ok => { const r = d.transaction('sesiones').objectStore('sesiones').getAll(); r.onsuccess = () => ok(r.result); });
    return JSON.stringify({ app: 'paleta', version: 1, fecha: new Date().toISOString(), cfg: cfg(), jugadores: jugadores(), sesiones: todas.map(s => Object.assign({}, s, { video: null })) });
  }
  async function importar(texto) {
    const j = JSON.parse(texto); if (j.app !== 'paleta') throw new Error('El archivo no es un respaldo de Paleta.');
    const l = jugadores(); for (const x of j.jugadores || []) if (!l.find(y => y.id === x.id)) l.push(x); guardar(KJUG, l);
    for (const s of j.sesiones || []) await guardarSesion(s);
    return { jugadores: (j.jugadores || []).length, sesiones: (j.sesiones || []).length };
  }

  return { cfg, setCfg, jugadores, jugador, guardarJugador, borrarJugador, activo, guardarSesion, sesion, sesiones, borrarSesion, respaldo, importar, id };
})();

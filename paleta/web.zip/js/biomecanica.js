/* Paleta — biomecánica: cálculos puros sobre el esqueleto 3D (MediaPipe Pose, 33 puntos).
   Detecta los golpes, mide cada uno, los clasifica y genera la versión corregida del movimiento.
   Coordenadas: metros, eje Y hacia arriba, origen en el centro de las caderas. Funciona en el navegador y en Node. */
(function (raiz, fabrica) {
  const m = fabrica();
  if (typeof module === 'object' && module.exports) module.exports = m; else raiz.Bio = m;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Índices de MediaPipe Pose */
  const J = {
    nariz: 0, ojoI: 2, ojoD: 5, orejaI: 7, orejaD: 8,
    hombroI: 11, hombroD: 12, codoI: 13, codoD: 14, munecaI: 15, munecaD: 16,
    menI: 17, menD: 18, indiceI: 19, indiceD: 20, pulgarI: 21, pulgarD: 22,
    caderaI: 23, caderaD: 24, rodillaI: 25, rodillaD: 26, tobilloI: 27, tobilloD: 28,
    talonI: 29, talonD: 30, pieI: 31, pieD: 32
  };
  const HUESOS = [[11, 12], [11, 13], [13, 15], [12, 14], [14, 16], [15, 19], [16, 20], [15, 21], [16, 22],
    [11, 23], [12, 24], [23, 24], [23, 25], [25, 27], [24, 26], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32],
    [0, 2], [0, 5], [2, 7], [5, 8]];

  /* Lados: D = diestro (golpea con la derecha), Z = zurdo */
  function lados(mano) {
    const d = mano !== 'Z';
    return d ? { h: 12, c: 14, m: 16, i: 20, p: 22, me: 18, hl: 11, cl: 13, ml: 15, il: 19, pl: 21, mel: 17, signo: 1 }
      : { h: 11, c: 13, m: 15, i: 19, p: 21, me: 17, hl: 12, cl: 14, ml: 16, il: 20, pl: 22, mel: 18, signo: -1 };
  }

  /* ---------- vectores ---------- */
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const norm = a => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
  const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const ARRIBA = [0, 1, 0];
  const grados = r => r * 180 / Math.PI;
  function angulo(a, b, c) { /* ángulo en b, en grados */
    const u = sub(a, b), v = sub(c, b);
    const k = dot(u, v) / ((len(u) * len(v)) || 1);
    return grados(Math.acos(Math.max(-1, Math.min(1, k))));
  }
  function horizontal(v) { return [v[0], 0, v[2]]; }
  function yaw(v) { return Math.atan2(v[2], v[0]); }
  function difAng(a, b) { let d = a - b; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; }
  function rotY(p, centro, ang) {
    const c = Math.cos(ang), s = Math.sin(ang), x = p[0] - centro[0], z = p[2] - centro[2];
    return [centro[0] + x * c + z * s, p[1], centro[2] - x * s + z * c];
  }
  function rotEje(p, centro, eje, ang) { /* Rodrigues */
    const v = sub(p, centro), k = norm(eje), c = Math.cos(ang), sn = Math.sin(ang);
    const r = add(add(mul(v, c), mul(cross(k, v), sn)), mul(k, dot(k, v) * (1 - c)));
    return add(centro, r);
  }
  const media = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
  const desv = a => { if (a.length < 2) return 0; const m = media(a); return Math.sqrt(media(a.map(x => (x - m) ** 2))); };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

  /* MediaPipe entrega Y hacia abajo: se invierte para trabajar con Y hacia arriba. */
  function desdeMediaPipe(world) { return world.map(p => [p.x, -p.y, -p.z]); }

  /* ---------- marco del cuerpo ---------- */
  function marco(P) {
    const cad = mid(P[23], P[24]), hom = mid(P[11], P[12]);
    const derCad = norm(horizontal(sub(P[24], P[23])));
    let frente = norm(cross(ARRIBA, derCad));
    /* la nariz queda por delante de los hombros: confirma hacia dónde mira */
    if (dot(sub(P[0], hom), frente) < 0) frente = mul(frente, -1);
    const torso = len(sub(hom, cad)) || 0.5;
    const anchoHombros = len(horizontal(sub(P[12], P[11]))) || 0.35;
    return { cad, hom, der: derCad, frente, torso, anchoHombros };
  }

  /* ---------- medidas por cuadro ---------- */
  function rodilla(P) { return (angulo(P[23], P[25], P[27]) + angulo(P[24], P[26], P[28])) / 2; }
  function apoyo(P) { const mk = marco(P); return len(horizontal(sub(P[28], P[27]))) / mk.anchoHombros; }

  /* Medidas rápidas para los consejos en vivo durante la grabación */
  function inclinacion(P) { const mk = marco(P); const v = norm(sub(mk.hom, mk.cad)); return grados(Math.acos(Math.max(-1, Math.min(1, v[1])))); }
  function medidasEnVivo(P, mano) {
    const L = lados(mano), mk = marco(P);
    return {
      tronco: inclinacion(P),
      rodillas: rodilla(P),
      apoyo: apoyo(P),
      brazoLibre: (P[L.ml][1] - mk.cad[1]) / mk.torso,
      codo: angulo(P[L.h], P[L.c], P[L.m])
    };
  }

  /* Desde dónde mira la cámara, con los puntos 2D de MediaPipe (x, y, z normalizados y visibilidad).
     Devuelve la vista (frente, diagonal, lado, atras) y qué lado del cuerpo está más cerca de la cámara. */
  function vistaCamara(n, ancho, alto) {
    if (!n) return null;
    const px = p => [p.x * ancho, p.y * alto];
    const hI = px(n[11]), hD = px(n[12]), cI = px(n[23]), cD = px(n[24]);
    const anchoH = Math.hypot(hD[0] - hI[0], hD[1] - hI[1]);
    const torso = Math.hypot((hI[0] + hD[0]) / 2 - (cI[0] + cD[0]) / 2, (hI[1] + hD[1]) / 2 - (cI[1] + cD[1]) / 2) || 1;
    const r = anchoH / torso;
    const cerca = (n[12].z ?? 0) < (n[11].z ?? 0) ? 'D' : 'I';
    const nariz = n[0].visibility ?? 1;
    /* de frente, el hombro derecho del jugador aparece a la izquierda de la imagen; de espaldas, a la derecha */
    const deEspaldas = hD[0] > hI[0];
    let tipo;
    if (r < 0.32) tipo = 'lado';
    else if (r < 0.62) tipo = deEspaldas && nariz < 0.6 ? 'atras' : 'diagonal';
    else tipo = deEspaldas || nariz < 0.5 ? 'atras' : 'frente';
    const alturaCuerpo = (Math.max(n[27].y, n[28].y, n[31].y, n[32].y) - n[0].y) + 0.06;
    return { tipo, cerca, relacion: r, alturaCuerpo };
  }

  /* ---------- detección de golpes ---------- */
  function suavizar(a, r) {
    const o = new Array(a.length);
    for (let i = 0; i < a.length; i++) { let s = 0, n = 0; for (let k = -r; k <= r; k++) { const j = i + k; if (j >= 0 && j < a.length) { s += a[j]; n++; } } o[i] = s / n; }
    return o;
  }

  /* Velocidad de la muñeca que golpea respecto de la cadera, en largos de torso por segundo */
  function velocidades(cuadros, mano) {
    const L = lados(mano);
    const rel = cuadros.map(c => sub(c.P[L.m], mid(c.P[23], c.P[24])));
    const torso = media(cuadros.map(c => marco(c.P).torso)) || 0.5;
    const v = cuadros.map((c, i) => {
      if (i === 0) return 0;
      const dt = Math.max(0.008, c.t - cuadros[i - 1].t);
      return len(sub(rel[i], rel[i - 1])) / dt / torso;
    });
    v[0] = v[1] || 0;
    return { v: suavizar(v, 1), torso };
  }

  function detectarGolpes(cuadros, mano, opciones) {
    const o = Object.assign({ separacion: 0.38, minimo: 1.4 }, opciones || {});
    if (!cuadros || cuadros.length < 8) return [];
    const { v } = velocidades(cuadros, mano);
    const picos = [];
    for (let i = 1; i < v.length - 1; i++) if (v[i] >= v[i - 1] && v[i] > v[i + 1] && v[i] > o.minimo) picos.push(i);
    if (!picos.length) return [];
    const altos = picos.map(i => v[i]).sort((a, b) => a - b);
    const p90 = altos[Math.floor(altos.length * 0.9)] || altos[altos.length - 1];
    const umbral = Math.max(o.minimo, p90 * 0.42);
    let elegidos = picos.filter(i => v[i] >= umbral);
    /* separa golpes: deja el pico más alto dentro de cada ventana */
    const fin = [];
    for (const i of elegidos) {
      const u = fin[fin.length - 1];
      if (u !== undefined && cuadros[i].t - cuadros[u].t < o.separacion) { if (v[i] > v[u]) fin[fin.length - 1] = i; }
      else fin.push(i);
    }
    const golpes = fin.map(pk => {
      const lim = v[pk] * 0.25;
      /* retrocede hasta que la mano se detiene (fin de la preparación) y avanza hasta el fin de la terminación */
      let a = pk; while (a > 0 && cuadros[pk].t - cuadros[a - 1].t < 0.9 && (v[a] > lim) && (v[a - 1] <= v[a] || v[a] > v[pk] * 0.6)) a--;
      let b = pk; while (b < v.length - 1 && cuadros[b + 1].t - cuadros[pk].t < 0.9 && (v[b] > lim) && (v[b + 1] <= v[b] || v[b] > v[pk] * 0.6)) b++;
      return { inicio: a, impacto: pk, fin: b, velocidad: v[pk] };
    }).filter(g => g.fin - g.inicio >= 3);
    /* descarta los cortados al inicio o al final del video y los movimientos lentos (volver a la posición de espera) */
    const t0 = cuadros[0].t, t1 = cuadros[cuadros.length - 1].t;
    const vm = golpes.map(g => g.velocidad).sort((a, b) => a - b)[Math.floor(golpes.length / 2)] || 0;
    return golpes.filter(g => cuadros[g.inicio].t - t0 > 0.12 && t1 - cuadros[g.fin].t > 0.05 && g.velocidad >= vm * 0.5 && g.inicio > 0);
  }

  /* ---------- medidas de un golpe ---------- */
  function medirGolpe(cuadros, g, mano) {
    const L = lados(mano);
    const A = cuadros[g.inicio].P, C = cuadros[g.impacto].P, B = cuadros[g.fin].P;
    const mk = marco(C), mkA = marco(A), T = mk.torso;
    /* ejes del cuerpo fijos al inicio del golpe (las caderas giran durante el golpe) */
    const der = mul(mkA.der, L.signo), frente = mkA.frente;
    const ventana = cuadros.slice(g.inicio, g.fin + 1).map(c => c.P);

    /* giro de hombros y de caderas: rango de orientación durante el golpe */
    const yawH = ventana.map(P => yaw(horizontal(sub(P[12], P[11]))));
    const yawC = ventana.map(P => yaw(horizontal(sub(P[24], P[23]))));
    const rango = arr => { const b = arr[0]; const d = arr.map(x => difAng(x, b)); return grados(Math.max(...d) - Math.min(...d)); };

    /* trayectoria de la muñeca relativa a la cadera */
    const rel = ventana.map(P => sub(P[L.m], mid(P[23], P[24])));
    let recorrido = 0; for (let i = 1; i < rel.length; i++) recorrido += len(sub(rel[i], rel[i - 1]));
    const d = sub(rel[rel.length - 1], rel[0]);
    const avance = dot(d, frente), lateral = dot(d, der), vertical = d[1];
    const anguloSwing = grados(Math.atan2(vertical, Math.hypot(avance, lateral) || 1e-6));

    /* lado del golpe: desde dónde parte la muñeca respecto del centro del cuerpo */
    const ladoInicio = dot(sub(A[L.m], mkA.hom), der) / T;
    const ladoImpacto = dot(sub(C[L.m], mk.hom), der) / T;
    const lado = (ladoInicio + ladoImpacto * 0.5) > -0.05 ? 'derecho' : 'reves';

    const cadA = mid(A[23], A[24]), cadB = mid(B[23], B[24]);
    const dCad = sub(cadB, cadA);
    const transferencia = (lado === 'derecho' ? -dot(dCad, der) + 0.5 * dot(dCad, frente) : dot(dCad, frente) + 0.3 * dot(dCad, der)) / T;

    const nariz = ventana.map(P => P[0]);
    const narizMov = Math.max(...nariz.map(p => len(sub(p, nariz[0])))) / T;

    const munecas = ventana.map(P => angulo(P[L.c], P[L.m], P[L.i]));
    const muneca = Math.max(...munecas) - Math.min(...munecas);

    /* lanzamiento de pelota en el saque: cuánto sube la mano libre antes del impacto (cm) */
    let lanzamiento = 0;
    { const desde = Math.max(0, g.inicio - 25); let minY = Infinity, maxY = -Infinity;
      for (let i = desde; i <= g.impacto; i++) { const y = cuadros[i].P[L.ml][1]; if (y < minY) minY = y; if (y > maxY) maxY = y; }
      lanzamiento = Math.round((maxY - minY) * 100); }

    const res = {
      lado,
      codo: angulo(C[L.h], C[L.c], C[L.m]),
      rodillas: rodilla(C),
      tronco: inclinacion(C),
      rodillasMin: Math.min(...ventana.map(rodilla)),
      apoyo: apoyo(C),
      giro: rango(yawH),
      cadera: rango(yawC),
      transferencia,
      angulo: anguloSwing,
      amplitud: recorrido / T,
      avance: avance / T,
      terminacion: (B[L.m][1] - B[0][1]) / T,
      impacto: dot(sub(C[L.m], mk.hom), frente) / T,
      alturaImpacto: (C[L.m][1] - mk.cad[1]) / T,
      brazoLibre: (C[L.ml][1] - mk.cad[1]) / T,
      muneca,
      cabeza: narizMov,
      codoCuerpo: Math.abs(dot(sub(C[L.c], mk.hom), der)) / T,
      recuperacion: cuadros[g.fin].t - cuadros[g.impacto].t,
      duracion: cuadros[g.fin].t - cuadros[g.inicio].t,
      velocidad: g.velocidad,
      lanzamiento,
      t: cuadros[g.impacto].t
    };
    res.tipo = clasificar(res);
    return res;
  }

  /* Tipo de golpe según la forma del movimiento */
  function clasificar(r) {
    if (r.alturaImpacto > 1.25 && r.angulo < 5 && r.velocidad > 6) return 'remate';
    if (r.angulo < -18) return r.amplitud > 1.4 ? 'corte_defensivo' : 'push';
    if (r.amplitud < 0.75) return r.angulo > 25 ? 'flick' : 'bloqueo';
    if (r.angulo > 28) return 'topspin';
    if (r.alturaImpacto > 1.2 && r.angulo > 15) return 'globo';
    return 'drive';
  }

  /* ---------- regularidad entre golpes ---------- */
  function regularidad(medidas) {
    if (medidas.length < 3) return null;
    const cv = k => { const a = medidas.map(x => x[k]); const m = media(a); return Math.abs(m) > 1e-6 ? desv(a) / Math.abs(m) : desv(a); };
    const tiempos = medidas.map(x => x.t); const intervalos = [];
    for (let i = 1; i < tiempos.length; i++) intervalos.push(tiempos[i] - tiempos[i - 1]);
    return {
      codo: desv(medidas.map(x => x.codo)),
      alturaImpacto: desv(medidas.map(x => x.alturaImpacto)),
      amplitud: cv('amplitud'),
      ritmo: intervalos.length > 1 ? desv(intervalos) / (media(intervalos) || 1) : 0,
      intervalo: media(intervalos)
    };
  }

  /* ---------- versión corregida del movimiento ---------- */
  /* Rodilla por cinemática inversa de dos huesos: ubica la rodilla entre cadera y tobillo. */
  function ik2(raizP, punta, l1, l2, haciaDonde) {
    const d = sub(punta, raizP); let dist = len(d);
    const max = (l1 + l2) * 0.999; if (dist > max) { punta = add(raizP, mul(norm(d), max)); dist = max; }
    const dir = norm(sub(punta, raizP));
    const a = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist);
    const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
    let perp = sub(haciaDonde, mul(dir, dot(haciaDonde, dir)));
    if (len(perp) < 1e-6) perp = cross(dir, [1, 0, 0]);
    perp = norm(perp);
    return { medio: add(add(raizP, mul(dir, a)), mul(perp, h)), punta };
  }

  /* Altura de cadera que logra un ángulo de rodilla dado (ley del coseno) */
  function alturaPierna(l1, l2, angRod) { const a = angRod * Math.PI / 180; return Math.sqrt(l1 * l1 + l2 * l2 - 2 * l1 * l2 * Math.cos(a)); }

  function campana(i, centro, ancho) { const x = (i - centro) / Math.max(1, ancho); return Math.exp(-x * x * 2); }
  function rampa(i, a, c, b) { /* 0 al inicio, 1 en el impacto, 1 al final */ if (i <= a) return 0; if (i >= c) return 1; return (i - a) / Math.max(1, c - a); }

  const SUPERIOR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22];
  const MANO = { 16: [18, 20, 22], 15: [17, 19, 21] };

  /* Postura de toda la grabación (no solo durante el golpe): rodillas, separación de pies e inclinación del tronco.
     postura: { rodillas: {dir:'alto'|'bajo', meta}, apoyo: {...}, tronco: {...} } */
  function corregirPostura(salida, postura, mano) {
    const prom = (a, b) => media(salida.map(c => len(sub(c.P[a], c.P[b]))));
    const muslo = (prom(23, 25) + prom(24, 26)) / 2, pierna = (prom(25, 27) + prom(26, 28)) / 2;
    const L = lados(mano);
    for (const c of salida) {
      const P = c.P, mk = marco(P);
      let cambio = false;
      const ap = postura.apoyo;
      if (ap) { const v = apoyo(P); if ((ap.dir === 'bajo' && v < ap.meta) || (ap.dir === 'alto' && v > ap.meta)) {
        const extra = (ap.meta - v) * mk.anchoHombros / 2, eje = norm(horizontal(sub(P[28], P[27])));
        for (const j of [27, 29, 31]) P[j] = add(P[j], mul(eje, -extra)); for (const j of [28, 30, 32]) P[j] = add(P[j], mul(eje, extra));
        cambio = true; c.marcas.push('apoyo'); } }
      const ro = postura.rodillas;
      if (ro) { const v = rodilla(P); if ((ro.dir === 'alto' && v > ro.meta) || (ro.dir === 'bajo' && v < ro.meta)) {
        const baja = alturaPierna(muslo, pierna, v) - alturaPierna(muslo, pierna, ro.meta);
        for (const j of SUPERIOR.concat([23, 24])) P[j] = [P[j][0], P[j][1] - baja, P[j][2]];
        cambio = true; c.marcas.push('rodillas'); } }
      if (cambio) for (const [cc, r, t] of [[23, 25, 27], [24, 26, 28]]) P[r] = ik2(P[cc], P[t], muslo, pierna, add(mk.frente, [0, 0.05, 0])).medio;
      const tr = postura.tronco;
      if (tr) { const v = inclinacion(P); if ((tr.dir === 'bajo' && v < tr.meta) || (tr.dir === 'alto' && v > tr.meta)) {
        const cad = mid(P[23], P[24]), eje = norm(horizontal(sub(P[24], P[23])));
        let ang = (tr.meta - v) * Math.PI / 180;
        if (dot(sub(rotEje(P[0], cad, eje, ang), P[0]), mk.frente) * Math.sign(tr.meta - v) < 0) ang = -ang;
        for (const j of SUPERIOR) P[j] = rotEje(P[j], cad, eje, ang);
        c.marcas.push('tronco'); } }
    }
  }

  /* correcciones: [{golpe:{inicio,impacto,fin}, metas:{rodillas,apoyo,codo,giro,terminacion,impacto,brazoLibre,transferencia,cabeza,angulo,amplitud}, medidas}] */
  function corregir(cuadros, correcciones, mano, postura) {
    const L = lados(mano);
    const salida = cuadros.map(c => ({ t: c.t, P: c.P.map(p => p.slice()), marcas: [] }));
    if (postura && Object.keys(postura).length) corregirPostura(salida, postura, mano);
    /* largos de huesos promedio del jugador */
    const prom = (a, b) => media(cuadros.map(c => len(sub(c.P[a], c.P[b]))));
    const muslo = (prom(23, 25) + prom(24, 26)) / 2, pierna = (prom(25, 27) + prom(26, 28)) / 2;
    const brazo = prom(L.h, L.c), antebrazo = prom(L.c, L.m);
    const brazoL = prom(L.hl, L.cl), antebrazoL = prom(L.cl, L.ml);

    for (const cor of correcciones) {
      const g = cor.golpe, M = cor.metas || {}, med = cor.medidas || {};
      const ancho = Math.max(2, (g.fin - g.inicio) / 2);
      const desde = Math.max(0, g.inicio - 4), hasta = Math.min(cuadros.length - 1, g.fin + 4);
      const mk0 = marco(cuadros[g.inicio].P);
      const der = mul(mk0.der, L.signo), frente = mk0.frente, T = mk0.torso;
      const centroGiro = media(cuadros.slice(g.inicio, g.fin + 1).map(c => yaw(horizontal(sub(c.P[12], c.P[11])))));
      for (let i = desde; i <= hasta; i++) {
        const P = salida[i].P, w = Math.min(1, campana(i, g.impacto, ancho * 1.6) * 1.15);
        /* postura (pies, rodillas, tronco): constante durante el golpe, con entrada y salida suaves */
        const wp = i < g.inicio ? 1 - (g.inicio - i) / 5 : i > g.fin ? 1 - (i - g.fin) / 5 : 1;
        const marcas = salida[i].marcas;
        /* 1. apoyo: abre o cierra los pies */
        if (M.apoyo !== undefined && med.apoyo) {
          const extra = (M.apoyo - med.apoyo) * mk0.anchoHombros / 2 * wp;
          const eje = norm(horizontal(sub(P[28], P[27])));
          for (const j of [27, 29, 31]) P[j] = add(P[j], mul(eje, -extra));
          for (const j of [28, 30, 32]) P[j] = add(P[j], mul(eje, extra));
          marcas.push('apoyo');
        }
        /* 2. rodillas: baja (o sube) la cadera y todo el cuerpo superior */
        if (M.rodillas !== undefined && med.rodillas) {
          const hAct = alturaPierna(muslo, pierna, med.rodillas), hMeta = alturaPierna(muslo, pierna, M.rodillas);
          const baja = (hAct - hMeta) * wp;
          for (const j of SUPERIOR.concat([23, 24])) P[j] = [P[j][0], P[j][1] - baja, P[j][2]];
          marcas.push('rodillas');
        }
        /* 3. traspaso de peso: desplaza el cuerpo hacia el lado del golpe a medida que avanza */
        if (M.transferencia !== undefined && med.transferencia !== undefined) {
          const r = rampa(i, g.inicio, g.fin, g.fin) - 0.5;
          const dir = med.lado === 'reves' ? frente : mul(der, -1);
          const delta = mul(dir, (M.transferencia - med.transferencia) * T * r * 0.8);
          for (const j of SUPERIOR.concat([23, 24])) P[j] = add(P[j], delta);
        }
        /* rehace las piernas con cinemática inversa (conserva el largo de los huesos) */
        for (const [c, r, t] of [[23, 25, 27], [24, 26, 28]]) {
          const hacia = add(frente, [0, 0.05, 0]);
          const k = ik2(P[c], P[t], muslo, pierna, hacia);
          P[r] = k.medio;
        }
        /* 3b. inclinación del tronco: rota el cuerpo superior sobre el eje de las caderas */
        if (M.tronco !== undefined && med.tronco !== undefined) {
          const cad = mid(P[23], P[24]);
          const eje = norm(horizontal(sub(P[24], P[23])));
          let ang = (M.tronco - med.tronco) * Math.PI / 180 * wp;
          const prueba = rotEje(P[0], cad, eje, ang);
          if (dot(sub(prueba, P[0]), frente) * Math.sign(M.tronco - med.tronco) < 0) ang = -ang;
          const manoGolpe = new Set([L.m].concat(MANO[L.m]));
          for (const j of SUPERIOR) if (!manoGolpe.has(j)) P[j] = rotEje(P[j], cad, eje, ang);
          marcas.push('tronco');
        }
        /* 4a. giro de caderas: rota la pelvis y todo lo que está encima */
        if (M.cadera !== undefined && med.cadera !== undefined) {
          const cad = mid(P[23], P[24]);
          const yC = yaw(horizontal(sub(P[24], P[23])));
          const base = cor.centroCadera !== undefined ? cor.centroCadera : (cor.centroCadera = media(cuadros.slice(g.inicio, g.fin + 1).map(c => yaw(horizontal(sub(c.P[24], c.P[23]))))));
          const dev = difAng(yC, base);
          const meta = M.cadera * Math.PI / 180 / 2 * Math.sign(dev || 1) * Math.min(1, Math.abs(dev) / Math.max(1e-3, med.cadera * Math.PI / 360));
          const extra = (meta - dev) * Math.min(1, w * 1.3);
          for (const j of SUPERIOR.concat([23, 24])) P[j] = rotY(P[j], cad, -extra);
          marcas.push('cadera');
        }
        /* 4. giro de tronco: amplifica la rotación de hombros alrededor de la columna */
        if (M.giro !== undefined && med.giro > 1) {
          const factor = clamp(M.giro / med.giro, 0.5, 2.2) - 1;
          const cad = mid(P[23], P[24]);
          const yH = yaw(horizontal(sub(P[12], P[11])));
          const extra = difAng(yH, centroGiro) * factor * Math.min(1, w * 1.3);
          for (const j of SUPERIOR) P[j] = rotY(P[j], cad, -extra);
          marcas.push('giro');
        }
        /* 5. cabeza estable */
        if (M.cabeza !== undefined && med.cabeza > M.cabeza) {
          const ref = salida[g.inicio].P[0], k = (1 - M.cabeza / med.cabeza) * w * 0.8;
          const d = sub(ref, P[0]);
          for (const j of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) P[j] = add(P[j], mul([d[0], 0, d[2]], k));
        }
        /* 6. trayectoria de la mano que golpea */
        const sh = P[L.h];
        let mun = P[L.m].slice();
        const ref = cuadros[g.impacto].P;
        if (M.amplitud !== undefined || M.angulo !== undefined || M.terminacion !== undefined || M.impacto !== undefined) {
          const cOrig = sub(ref[L.m], mid(ref[23], ref[24]));
          const actual = sub(cuadros[i].P[L.m], mid(cuadros[i].P[23], cuadros[i].P[24]));
          let o = sub(actual, cOrig);
          if (M.amplitud !== undefined && med.amplitud) o = mul(o, clamp(M.amplitud / med.amplitud, 0.6, 1.7));
          if (M.angulo !== undefined && med.angulo !== undefined) {
            const h = Math.hypot(dot(o, frente), dot(o, der));
            const s = i < g.impacto ? -1 : 1;
            o = add(o, [0, s * h * Math.tan((M.angulo - med.angulo) * Math.PI / 180) * 0.9, 0]);
          }
          let nuevo = add(add(mid(P[23], P[24]), cOrig), o);
          if (M.impacto !== undefined && med.impacto !== undefined) nuevo = add(nuevo, mul(frente, (M.impacto - med.impacto) * T * w));
          if (M.terminacion !== undefined && med.terminacion !== undefined) {
            const r = i > g.impacto ? rampa(i, g.impacto, g.fin, g.fin) : 0;
            nuevo = add(nuevo, [0, (M.terminacion - med.terminacion) * T * r, 0]);
          }
          mun = lerp(P[L.m], nuevo, Math.min(1, w * 1.4 + (i > g.impacto ? 0.3 : 0)));
          marcas.push('brazo');
        }
        /* 7. codo: ajusta el ángulo en el impacto */
        let doblez = add(frente, [0, -0.6, 0]);
        if (M.codo !== undefined && med.codo) {
          const lMeta = Math.sqrt(brazo * brazo + antebrazo * antebrazo - 2 * brazo * antebrazo * Math.cos(M.codo * Math.PI / 180));
          const lAct = len(sub(mun, sh));
          const lNuevo = lAct + (lMeta - Math.sqrt(brazo * brazo + antebrazo * antebrazo - 2 * brazo * antebrazo * Math.cos(med.codo * Math.PI / 180))) * w;
          mun = add(sh, mul(norm(sub(mun, sh)), Math.max(0.05, lNuevo)));
          marcas.push('codo');
        }
        const ant = P[L.m];
        const kb = ik2(sh, mun, brazo, antebrazo, add(sub(P[L.c], mid(sh, mun)), mul(doblez, 0.05)));
        P[L.c] = kb.medio; P[L.m] = kb.punta;
        const dm = sub(P[L.m], ant);
        for (const j of MANO[L.m]) P[j] = add(P[j], dm);
        /* 8. brazo libre: lo sube a la altura del pecho para equilibrar */
        if (M.brazoLibre !== undefined && med.brazoLibre !== undefined && med.brazoLibre < M.brazoLibre) {
          const cad = mid(P[23], P[24]);
          const meta = [P[L.ml][0], cad[1] + M.brazoLibre * T, P[L.ml][2]];
          const pos = lerp(P[L.ml], add(meta, mul(frente, 0.12)), Math.min(1, w + 0.25));
          const antL = P[L.ml];
          const kl = ik2(P[L.hl], pos, brazoL, antebrazoL, add(sub(P[L.cl], P[L.hl]), [0, -0.1, 0]));
          P[L.cl] = kl.medio; P[L.ml] = kl.punta;
          const dl = sub(P[L.ml], antL);
          for (const j of MANO[L.ml]) P[j] = add(P[j], dl);
          marcas.push('brazoLibre');
        }
      }
    }
    return salida;
  }

  /* ---------- jugador de demostración ---------- */
  /* Genera un esqueleto sintético golpeando derechos (con fallas a elección), para probar la app sin cámara. */
  function sintetico(opc) {
    const o = Object.assign({ golpes: 8, fps: 30, intervalo: 1.0, rodillas: 165, codo: 165, giro: 18, terminacion: -0.6, brazoLibre: -0.1, mano: 'D', ruido: 0.004, tipo: 'topspin' }, opc || {});
    const cuadros = []; const total = o.golpes * o.intervalo + 0.8;
    let semilla = 7; const azar = () => { semilla = (semilla * 16807) % 2147483647; return semilla / 2147483647 - 0.5; };
    const s = o.mano === 'Z' ? -1 : 1;
    for (let k = 0; k * (1 / o.fps) < total; k++) {
      const t = k / o.fps;
      const fase = ((t - 0.4) % o.intervalo + o.intervalo) % o.intervalo / o.intervalo; // 0..1
      /* golpe: preparación 0.15–0.45, impacto ~0.5, terminación 0.5–0.65 */
      let g = 0; if (fase > 0.15 && fase < 0.45) g = -(fase - 0.15) / 0.3; else if (fase >= 0.45 && fase < 0.65) g = -1 + (fase - 0.45) / 0.2 * 2; else if (fase >= 0.65 && fase < 0.85) g = 1 - (fase - 0.65) / 0.2;
      const rodA = o.rodillas * Math.PI / 180;
      const muslo = 0.45, pier = 0.45;
      const hCad = Math.sqrt(muslo * muslo + pier * pier - 2 * muslo * pier * Math.cos(rodA));
      const giro = g * o.giro * Math.PI / 180 * s;
      const P = new Array(33).fill(0).map(() => [0, 0, 0]);
      const cad = [0, 0, 0];
      const pies = 0.3;
      P[27] = [-pies, -hCad, 0]; P[28] = [pies, -hCad, 0];
      P[29] = [-pies, -hCad - 0.03, 0.06]; P[30] = [pies, -hCad - 0.03, 0.06];
      P[31] = [-pies, -hCad - 0.05, -0.15]; P[32] = [pies, -hCad - 0.05, -0.15];
      P[23] = [-0.12, 0, 0]; P[24] = [0.12, 0, 0];
      for (const [c, r, tb] of [[23, 25, 27], [24, 26, 28]]) P[r] = ik2(P[c], P[tb], muslo, pier, [0, 0, -1]).medio;
      const hom = [0, 0.5, -0.13]; /* tronco levemente inclinado hacia adelante, como un deportista */
      const rot = p => rotY(p, cad, giro);
      P[11] = rot(add(hom, [-0.19, 0, 0])); P[12] = rot(add(hom, [0.19, 0, 0]));
      P[0] = rot(add(hom, [0, 0.25, -0.12]));
      P[2] = rot(add(P[0], [-0.03, 0.03, 0.02])); P[5] = rot(add(P[0], [0.03, 0.03, 0.02]));
      P[7] = rot(add(P[0], [-0.07, 0.01, 0.08])); P[8] = rot(add(P[0], [0.07, 0.01, 0.08]));
      for (const j of [1, 3, 4, 6, 9, 10]) P[j] = P[0].slice();
      const hD = s > 0 ? 12 : 11, cD = s > 0 ? 14 : 13, mD = s > 0 ? 16 : 15, hL = s > 0 ? 11 : 12, cL = s > 0 ? 13 : 14, mL = s > 0 ? 15 : 16;
      /* mano que golpea: abajo-atrás-al lado en la preparación, arriba-adelante en la terminación */
      const lat = 0.42 * s;
      const top = o.tipo === 'topspin';
      const y = g < 0 ? -0.15 + g * (top ? 0.25 : 0.08) : -0.15 + g * (0.52 + 0.45 + o.terminacion * 0.52) * (top ? 1 : 0.7);
      const z = g < 0 ? 0.05 - g * 0.25 : -0.25 - g * 0.3;
      const x = g < 0 ? lat - g * 0.2 * s : lat - g * 0.5 * s;
      const mano = rot([x, y + 0.52 * 0.5, z]);
      const lb = 0.3, la = 0.27;
      const lmeta = Math.sqrt(lb * lb + la * la - 2 * lb * la * Math.cos(o.codo * Math.PI / 180));
      const dirM = norm(sub(mano, P[hD]));
      const kb = ik2(P[hD], add(P[hD], mul(dirM, lmeta)), lb, la, [0, -1, 0.3]);
      P[cD] = kb.medio; P[mD] = kb.punta;
      P[s > 0 ? 20 : 19] = add(P[mD], mul(norm(sub(P[mD], P[cD])), 0.08));
      P[s > 0 ? 18 : 17] = add(P[mD], [0.02, -0.02, -0.05]); P[s > 0 ? 22 : 21] = add(P[mD], [0, 0.03, -0.04]);
      const libre = rot([-0.3 * s, o.brazoLibre * 0.52, -0.25]);
      const kl = ik2(P[hL], libre, lb, la, [0, -1, 0.2]);
      P[cL] = kl.medio; P[mL] = kl.punta;
      P[s > 0 ? 19 : 20] = add(P[mL], [0, -0.05, -0.03]); P[s > 0 ? 17 : 18] = add(P[mL], [0, -0.05, 0]); P[s > 0 ? 21 : 22] = add(P[mL], [0.02, -0.03, -0.03]);
      for (let j = 0; j < 33; j++) P[j] = [P[j][0] + azar() * o.ruido, P[j][1] + azar() * o.ruido, P[j][2] + azar() * o.ruido];
      cuadros.push({ t, P });
    }
    return cuadros;
  }

  return { J, HUESOS, lados, angulo, marco, inclinacion, vistaCamara, corregirPostura, desdeMediaPipe, medidasEnVivo, velocidades, detectarGolpes, medirGolpe, clasificar, regularidad, corregir, sintetico, ik2, media, desv, len, sub };
});

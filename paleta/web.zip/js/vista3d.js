/* Paleta — animación 3D lado a lado: el jugador tal como se grabó (errores en rojo)
   y el mismo jugador con los golpes corregidos (cambios en verde). Sincronizadas. */
"use strict";
const Vista3D = (() => {
  let THREE = null;
  async function cargarThree() { if (!THREE) THREE = await import('../vendor/three/three.module.min.js'); return THREE; }

  async function crear(contenedor, datos) {
    await cargarThree();
    const { original, corregido, errores, mano, golpes, cambios } = datos;
    const pelota = datos.pelota || null;
    contenedor.innerHTML = `
      <div class="v3d">
        <div class="v3d-lienzo"><canvas></canvas>
          <div class="v3d-tit izq"><b>Tu golpe</b><span class="v3d-err"></span></div>
          <div class="v3d-tit der"><b>Golpe corregido</b><span class="v3d-ok"></span></div>
        </div>
        <div class="v3d-linea"><div class="v3d-marcas"></div><input type="range" min="0" max="${original.length - 1}" value="0" step="1"></div>
        <div class="v3d-ctrl">
          <button class="btn sm" data-v="prev" aria-label="Golpe anterior">⏮</button>
          <button class="btn sm pri" data-v="play">⏸</button>
          <button class="btn sm" data-v="next" aria-label="Golpe siguiente">⏭</button>
          <select data-v="vel"><option value="1">1×</option><option value="0.5" selected>0,5×</option><option value="0.25">0,25×</option></select>
          <select data-v="cam"><option value="lado">Vista lateral</option><option value="frente">De frente</option><option value="atras">Desde atrás</option><option value="arriba">Desde arriba</option></select>
        </div>
        <p class="note v3d-ayuda">Arrastra para girar las vistas. Rojo: articulación con falla. Verde: lo que cambia en la versión corregida.</p>
      </div>`;
    const lienzo = contenedor.querySelector('canvas');
    const renderer = new THREE.WebGLRenderer({ canvas: lienzo, antialias: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setScissorTest(true);
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    /* geometría del lugar: piso, mesa reglamentaria (2,74 × 1,525 m, 76 cm de alto) */
    const todos = original.concat(corregido);
    const piso = Math.min(...original.map(c => Math.min(c.P[29][1], c.P[30][1], c.P[31][1], c.P[32][1]))) - 0.01;
    const M = Bio.marco(original[0].P);
    const cadMedia = [0, 0, 0]; original.forEach(c => { const h = [(c.P[23][0] + c.P[24][0]) / 2, 0, (c.P[23][2] + c.P[24][2]) / 2]; cadMedia[0] += h[0] / original.length; cadMedia[2] += h[2] / original.length; });

    /* ---------- figura humana ---------- */
    const PIEL = 0xd9a07a, PELO = 0x2a1c14, SHORT = 0x1b1f2a, ZAPA = 0xf2f2f2, SUELA = 0x30343c;
    function crearFigura(sc, camiseta) {
      const mat = c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.65, metalness: 0.02 });
      const M = { piel: mat(PIEL), camiseta: mat(camiseta), short: mat(SHORT), zapa: mat(ZAPA), suela: mat(SUELA), pelo: mat(PELO) };
      const cil = new THREE.CylinderGeometry(1, 1, 1, 18, 1, true), esf = new THREE.SphereGeometry(1, 22, 16);
      const partes = [];
      const sombra = m => { m.castShadow = true; m.receiveShadow = false; sc.add(m); return m; };
      /* segmento: de a hacia b (puede cortarse en una fracción para mangas y short) */
      function seg(a, b, r1, r2, material, desde, hasta) {
        const g = new THREE.CylinderGeometry(r2, r1, 1, 18, 1, true);
        const m = sombra(new THREE.Mesh(g, material.clone()));
        const parte = { tipo: 'seg', a, b, m, desde: desde || 0, hasta: hasta || 1, base: material };
        partes.push(parte); return parte;
      }
      function junta(j, r, material) { const m = sombra(new THREE.Mesh(esf, material.clone())); m.scale.setScalar(r); const p = { tipo: 'junta', j, m, base: material }; partes.push(p); return p; }
      const L = Bio.lados(mano);
      /* brazos: manga hasta la mitad del brazo, luego piel */
      for (const [h, c, mu] of [[11, 13, 15], [12, 14, 16]]) {
        seg(h, c, 0.05, 0.046, M.camiseta, 0, 0.5); seg(h, c, 0.044, 0.04, M.piel, 0.5, 1);
        seg(c, mu, 0.038, 0.03, M.piel); junta(c, 0.04, M.piel); junta(h, 0.058, M.camiseta);
      }
      /* piernas: short hasta 45 % del muslo */
      for (const [c, r, t] of [[23, 25, 27], [24, 26, 28]]) {
        seg(c, r, 0.082, 0.076, M.short, 0, 0.45); seg(c, r, 0.072, 0.056, M.piel, 0.45, 1);
        seg(r, t, 0.054, 0.036, M.piel); junta(r, 0.056, M.piel); junta(t, 0.04, M.piel);
      }
      /* manos */
      const manos = [15, 16].map(j => { const m = sombra(new THREE.Mesh(esf, M.piel.clone())); m.scale.set(0.04, 0.05, 0.03); return { j, m }; });
      /* zapatillas: del talón a la punta */
      const zapas = [[29, 31], [30, 32]].map(([t, p]) => {
        const g = new THREE.Group(); const cuerpo = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.075, 1), M.zapa.clone()); cuerpo.position.y = 0.01;
        const suela = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.025, 1.04), M.suela.clone()); suela.position.y = -0.035;
        cuerpo.castShadow = suela.castShadow = true; g.add(cuerpo, suela); sc.add(g); return { t, p, g, cuerpo };
      });
      /* tronco: pecho, abdomen y pelvis como elipsoides orientados con el cuerpo */
      const pecho = sombra(new THREE.Mesh(esf, M.camiseta.clone())), abdomen = sombra(new THREE.Mesh(esf, M.camiseta.clone())), pelvis = sombra(new THREE.Mesh(esf, M.short.clone()));
      const cuello = sombra(new THREE.Mesh(cil, M.piel.clone()));
      const cabeza = sombra(new THREE.Mesh(esf, M.piel.clone()));
      const pelo = sombra(new THREE.Mesh(new THREE.SphereGeometry(1, 22, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), M.pelo.clone()));
      const nariz = sombra(new THREE.Mesh(esf, M.piel.clone()));
      const tronco = { pecho, abdomen, pelvis };
      return { partes, manos, zapas, tronco, cuello, cabeza, pelo, nariz, M };
    }
    const v3 = (P, j) => new THREE.Vector3(P[j][0], P[j][1], P[j][2]);
    const Y = new THREE.Vector3(0, 1, 0), Z = new THREE.Vector3(0, 0, 1);
    function orientar(m, a, b) { const d = new THREE.Vector3().subVectors(b, a); const l = d.length(); m.position.copy(a).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(Y, d.normalize()); return l; }
    function base(m, x, y, z, ox, oy, oz) { const B = new THREE.Matrix4().makeBasis(x, y, z); m.quaternion.setFromRotationMatrix(B); m.scale.set(ox, oy, oz); }
    function tinte(m, estado) {
      if (estado === 'rojo') { m.material.emissive.setHex(0x7a0606); }
      else if (estado === 'verde') { m.material.emissive.setHex(0x05261a); }
      else m.material.emissive.setHex(0x000000);
    }
    function ponerFigura(F, P, rojos, verdes) {
      const est = (...js) => js.every(j => rojos.has(j)) ? 'rojo' : js.every(j => verdes.has(j)) ? 'verde' : '';
      for (const p of F.partes) {
        if (p.tipo === 'seg') {
          const a = v3(P, p.a), b = v3(P, p.b), A = a.clone().lerp(b, p.desde), B = a.clone().lerp(b, p.hasta);
          const l = orientar(p.m, A, B); p.m.scale.set(1, Math.max(0.001, l), 1);
          if (est(p.a, p.b) !== 'rojo') p.m.material.color.copy(p.base.color);
          tinte(p.m, est(p.a, p.b));
        } else { p.m.position.copy(v3(P, p.j)); if (!rojos.has(p.j)) p.m.material.color.copy(p.base.color); tinte(p.m, rojos.has(p.j) ? 'rojo' : verdes.has(p.j) ? 'verde' : ''); }
      }
      for (const h of F.manos) { const w = v3(P, h.j), ix = v3(P, h.j === 16 ? 20 : 19); h.m.position.copy(w).lerp(ix, 0.45); h.m.quaternion.setFromUnitVectors(Y, ix.clone().sub(w).normalize()); tinte(h.m, rojos.has(h.j) ? 'rojo' : verdes.has(h.j) ? 'verde' : ''); }
      for (const z of F.zapas) {
        const t = v3(P, z.t), p = v3(P, z.p), d = new THREE.Vector3().subVectors(p, t); const l = Math.max(0.2, d.length() * 1.15);
        d.y = 0; d.normalize(); const x = new THREE.Vector3().crossVectors(Y, d).normalize();
        z.g.position.copy(t).lerp(p, 0.5); z.g.position.y = Math.min(t.y, p.y) + 0.035;
        z.g.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, Y, d)); z.g.scale.set(1, 1, l);
        tinte(z.cuerpo, rojos.has(z.t) || rojos.has(z.p) ? 'rojo' : verdes.has(z.t) ? 'verde' : '');
      }
      /* tronco */
      const hI = v3(P, 11), hD = v3(P, 12), cI = v3(P, 23), cD = v3(P, 24);
      const hom = hI.clone().add(hD).multiplyScalar(0.5), cad = cI.clone().add(cD).multiplyScalar(0.5);
      const arriba = hom.clone().sub(cad), largo = arriba.length(); arriba.normalize();
      let der = hD.clone().sub(hI); der.addScaledVector(arriba, -der.dot(arriba)); const anchoH = der.length(); der.normalize();
      const frente = new THREE.Vector3().crossVectors(der, arriba).normalize();
      const derC = cD.clone().sub(cI); derC.addScaledVector(arriba, -derC.dot(arriba)); const anchoC = derC.length(); derC.normalize();
      const frenteC = new THREE.Vector3().crossVectors(derC, arriba).normalize();
      const T = F.tronco;
      T.pecho.position.copy(cad).addScaledVector(arriba, largo * 0.72).addScaledVector(frente, 0.01);
      base(T.pecho, der, arriba, frente, Math.max(0.13, anchoH * 0.62), largo * 0.36, 0.115);
      const torsoGiro = der.clone().lerp(derC, 0.5).normalize(), frenteM = new THREE.Vector3().crossVectors(torsoGiro, arriba).normalize();
      T.abdomen.position.copy(cad).addScaledVector(arriba, largo * 0.38);
      base(T.abdomen, torsoGiro, arriba, frenteM, Math.max(0.11, anchoC * 0.85), largo * 0.33, 0.1);
      T.pelvis.position.copy(cad).addScaledVector(arriba, 0.02);
      base(T.pelvis, derC, arriba, frenteC, Math.max(0.12, anchoC * 0.9), 0.12, 0.11);
      const tTronco = est(11, 12, 23, 24) || (rojos.has(23) && rojos.has(24) ? 'rojo' : '');
      for (const m of [T.pecho, T.abdomen]) { if (tTronco !== 'rojo') m.material.color.copy(F.M.camiseta.color); tinte(m, tTronco); }
      if (!(rojos.has(23) && rojos.has(24))) T.pelvis.material.color.copy(F.M.short.color);
      tinte(T.pelvis, rojos.has(23) && rojos.has(24) ? 'rojo' : verdes.has(23) && verdes.has(24) ? 'verde' : '');
      /* cuello y cabeza: centro entre las orejas, mirando hacia la nariz */
      const oI = v3(P, 7), oD = v3(P, 8), nar = v3(P, 0);
      const centroCab = oI.clone().add(oD).multiplyScalar(0.5).lerp(nar, 0.25).addScaledVector(arriba, 0.02);
      const cuelloBase = hom.clone().addScaledVector(arriba, 0.02);
      const cuelloTope = cuelloBase.clone().lerp(centroCab, 0.6);
      const lc = orientar(F.cuello, cuelloBase, cuelloTope); F.cuello.scale.set(0.05, Math.max(0.01, lc), 0.05);
      F.cabeza.position.copy(centroCab); F.cabeza.scale.set(0.095, 0.115, 0.105);
      const arribaCab = centroCab.clone().sub(cuelloBase).normalize();
      let mira = nar.clone().sub(centroCab); mira.addScaledVector(arribaCab, -mira.dot(arribaCab)); if (mira.length() < 1e-4) mira.copy(frente); mira.normalize();
      const xCab = new THREE.Vector3().crossVectors(arribaCab, mira).normalize();
      F.cabeza.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(xCab, arribaCab, mira));
      F.pelo.position.copy(centroCab).addScaledVector(mira, -0.012).addScaledVector(arribaCab, 0.008); F.pelo.quaternion.copy(F.cabeza.quaternion); F.pelo.scale.set(0.102, 0.122, 0.112);
      F.nariz.position.copy(centroCab).addScaledVector(mira, 0.1).addScaledVector(arribaCab, -0.01); F.nariz.scale.setScalar(0.018);
      tinte(F.cabeza, rojos.has(0) ? 'rojo' : verdes.has(0) ? 'verde' : '');
    }

    function escena(colorBase, colorMarca) {
      const s = new THREE.Scene();
      s.background = new THREE.Color(0x101a17);
      s.fog = new THREE.Fog(0x101a17, 7, 14);
      s.add(new THREE.HemisphereLight(0xfff6ea, 0x2a2420, 0.95));
      const sol = new THREE.DirectionalLight(0xffffff, 1.6); sol.position.set(cadMedia[0] + 2.5, piso + 5, cadMedia[2] + 2); sol.target.position.set(cadMedia[0], piso, cadMedia[2]);
      sol.castShadow = true; sol.shadow.mapSize.set(1024, 1024); sol.shadow.camera.left = -3; sol.shadow.camera.right = 3; sol.shadow.camera.top = 3; sol.shadow.camera.bottom = -3; sol.shadow.bias = -0.0005;
      s.add(sol, sol.target);
      const relleno = new THREE.DirectionalLight(0xcfe3ff, 0.45); relleno.position.set(cadMedia[0] - 3, piso + 2, cadMedia[2] - 2); s.add(relleno);
      /* piso deportivo */
      const suelo = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), new THREE.MeshStandardMaterial({ color: 0x7a2e26, roughness: 0.85 }));
      suelo.rotation.x = -Math.PI / 2; suelo.position.set(cadMedia[0], piso, cadMedia[2]); suelo.receiveShadow = true; s.add(suelo);
      const grid = new THREE.GridHelper(14, 14, 0x8f4036, 0x84392f); grid.position.set(cadMedia[0], piso + 0.002, cadMedia[2]); s.add(grid);
      /* mesa */
      const mesa = new THREE.Group();
      const tablero = new THREE.Mesh(new THREE.BoxGeometry(1.525, 0.03, 2.74), new THREE.MeshStandardMaterial({ color: 0x1f5fa8, roughness: 0.6 }));
      tablero.position.y = 0.745; mesa.add(tablero);
      const linea = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.032, 2.74), new THREE.MeshBasicMaterial({ color: 0xffffff })); linea.position.y = 0.746; mesa.add(linea);
      for (const z of [-1.36, 1.36]) { const b = new THREE.Mesh(new THREE.BoxGeometry(1.525, 0.032, 0.02), new THREE.MeshBasicMaterial({ color: 0xffffff })); b.position.set(0, 0.746, z); mesa.add(b); }
      const red = new THREE.Mesh(new THREE.BoxGeometry(1.83, 0.1525, 0.01), new THREE.MeshStandardMaterial({ color: 0xdddddd, transparent: true, opacity: 0.55 })); red.position.y = 0.76 + 0.076; mesa.add(red);
      for (const x of [-0.6, 0.6]) for (const z of [-1.2, 1.2]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.73, 0.05), new THREE.MeshStandardMaterial({ color: 0x333333 })); p.position.set(x, 0.365, z); mesa.add(p); }
      /* la mesa queda delante del jugador, con su lado corto frente a él */
      const frente = new THREE.Vector3(M.frente[0], 0, M.frente[2]).normalize();
      const centro = new THREE.Vector3(cadMedia[0], piso, cadMedia[2]).add(frente.clone().multiplyScalar(0.45 + 1.37));
      mesa.position.copy(centro);
      mesa.rotation.y = Math.atan2(frente.x, frente.z);
      mesa.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      s.add(mesa);
      /* deportista: cuerpo con volumen (tronco, extremidades ahusadas, cabeza, manos y zapatillas) */
      const fig = crearFigura(s, colorBase);
      /* paleta */
      const paleta = new THREE.Group();
      const cara1 = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.006, 28), new THREE.MeshStandardMaterial({ color: 0xc0262d }));
      const cara2 = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.006, 28), new THREE.MeshStandardMaterial({ color: 0x111111 })); cara2.position.y = -0.007;
      const mango = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.012, 0.1), new THREE.MeshStandardMaterial({ color: 0xc89a5b })); mango.position.z = -0.11;
      const cabeza = new THREE.Group(); cabeza.add(cara1, cara2); cabeza.position.z = 0.02;
      paleta.add(cabeza, mango); paleta.traverse(o => { if (o.isMesh) o.castShadow = true; }); s.add(paleta);
      /* pelota con estela */
      const matPel = new THREE.MeshStandardMaterial({ color: 0xff8a1f, emissive: 0x552200 });
      const bola = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 12), matPel); bola.visible = false; s.add(bola);
      const estela = []; for (let k = 0; k < 8; k++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.016, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: 0.5 - k * 0.055 })); m.visible = false; s.add(m); estela.push(m); }
      return { s, fig, paleta, bola, estela };
    }
    const izq = escena(0x2f6fd6, 0x36d17a), der = escena(0x2f6fd6, 0x36d17a);
    const L = Bio.lados(mano);
    const arriba = new THREE.Vector3(0, 1, 0), tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
    function poner(E, P, rojos, verdes) {
      const v = j => new THREE.Vector3(P[j][0], P[j][1], P[j][2]);
      ponerFigura(E.fig, P, rojos, verdes);
      /* paleta: sigue la mano (muñeca → índice) */
      const w = v(L.m), i = v(L.i), c = v(L.c);
      const dir = tmp2.subVectors(i, w); if (dir.length() < 1e-4) dir.subVectors(w, c);
      dir.normalize();
      E.paleta.position.copy(w).addScaledVector(dir, 0.05);
      const normal = new THREE.Vector3().subVectors(v(L.p), w).cross(dir).normalize();
      const m4 = new THREE.Matrix4(); const x = new THREE.Vector3().crossVectors(normal, dir).normalize();
      m4.makeBasis(x, normal, dir); E.paleta.quaternion.setFromRotationMatrix(m4);
    }

    /* cámaras */
    const camI = new THREE.PerspectiveCamera(40, 1, 0.05, 50), camD = new THREE.PerspectiveCamera(40, 1, 0.05, 50);
    const objetivo = new THREE.Vector3(cadMedia[0], piso + 0.95, cadMedia[2]);
    const yawFrente = Math.atan2(M.frente[0], M.frente[2]);
    const signoLado = mano === 'Z' ? -1 : 1;
    let az = yawFrente + Math.PI / 2 * signoLado + 0.35, el = 0.18, dist = 3.6;
    const vistas = { lado: () => [yawFrente + Math.PI / 2 * signoLado + 0.35, 0.18], frente: () => [yawFrente, 0.12], atras: () => [yawFrente + Math.PI, 0.25], arriba: () => [yawFrente + Math.PI + 0.01, 1.25] };
    function ubicar(cam) { cam.position.set(objetivo.x + dist * Math.cos(el) * Math.sin(az), objetivo.y + dist * Math.sin(el), objetivo.z + dist * Math.cos(el) * Math.cos(az)); cam.lookAt(objetivo); }

    /* marcas de golpes en la línea de tiempo */
    const marcasEl = contenedor.querySelector('.v3d-marcas');
    marcasEl.innerHTML = golpes.map(g => `<i style="left:${(g.impacto / Math.max(1, original.length - 1) * 100).toFixed(2)}%;background:${g.puntaje >= 80 ? '#38e8a0' : g.puntaje >= 60 ? '#ffb020' : '#ff4d4d'}" title="Golpe ${g.n}"></i>`).join('');

    let i = 0, play = true, vel = 0.5, ultimo = performance.now(), acum = 0, vivo = true;
    const barra = contenedor.querySelector('input[type=range]'), txtE = contenedor.querySelector('.v3d-err'), txtO = contenedor.querySelector('.v3d-ok');
    const dt = original.length > 1 ? (original[original.length - 1].t - original[0].t) / (original.length - 1) : 1 / 30;
    function cuadro(k) {
      i = Math.max(0, Math.min(original.length - 1, k));
      const e = errores[i] || { j: [], textos: [] };
      poner(izq, original[i].P, new Set(e.j), new Set());
      const ver = new Set(); (corregido[i].marcas || []).forEach(z => Evz(z).forEach(j => ver.add(j)));
      poner(der, corregido[i].P, new Set(), ver);
      for (const E of [izq, der]) {
        const b = pelota && pelota[i]; E.bola.visible = !!b; if (b) E.bola.position.set(b[0], b[1], b[2]);
        E.estela.forEach((m, k) => { const q = pelota && pelota[i - (k + 1) * 2]; m.visible = !!q; if (q) m.position.set(q[0], q[1], q[2]); });
      }
      const g = golpes.find(g => i >= g.inicio && i <= g.fin);
      txtE.textContent = [g && g.info, e.textos.slice(0, 2).join(' · ')].filter(Boolean).join(' — ');
      txtO.textContent = g && cambios[g.n] ? cambios[g.n] : '';
      barra.value = i;
    }
    function Evz(z) {
      const mapa = { apoyo: 'pies', rodillas: 'piernas', giro: 'tronco', cadera: 'cadera', brazo: 'mano', codo: 'codo', brazoLibre: 'brazoLibre' };
      return Ev.articulacionesZona(mapa[z] || z, mano);
    }
    function tam() {
      const W = lienzo.clientWidth, H = lienzo.clientHeight;
      renderer.setSize(W, H, false);
    }
    function dibujar() {
      const W = lienzo.clientWidth, H = lienzo.clientHeight, vertical = H > W * 1.1;
      const pares = vertical ? [[0, H / 2, W, H / 2], [0, 0, W, H / 2]] : [[0, 0, W / 2, H], [W / 2, 0, W / 2, H]];
      contenedor.querySelector('.v3d').classList.toggle('vertical', vertical);
      ubicar(camI); ubicar(camD);
      [[izq, camI, pares[0]], [der, camD, pares[1]]].forEach(([E, cam, r]) => {
        cam.aspect = r[2] / r[3]; cam.updateProjectionMatrix();
        renderer.setViewport(r[0], r[1], r[2], r[3]); renderer.setScissor(r[0], r[1], r[2], r[3]);
        renderer.render(E.s, cam);
      });
    }
    function bucle(ahora) {
      if (!vivo) return;
      const d = (ahora - ultimo) / 1000; ultimo = ahora;
      if (play) { acum += d * vel; while (acum >= dt) { acum -= dt; cuadro(i + 1 >= original.length ? 0 : i + 1); } }
      dibujar();
      requestAnimationFrame(bucle);
    }
    /* controles */
    contenedor.addEventListener('click', ev => {
      const b = ev.target.closest('[data-v]'); if (!b || b.tagName === 'SELECT') return;
      const k = b.dataset.v;
      if (k === 'play') { play = !play; b.textContent = play ? '⏸' : '▶'; }
      if (k === 'next' || k === 'prev') {
        const lista = k === 'next' ? golpes.filter(g => g.inicio > i + 1) : golpes.filter(g => g.inicio < i - 1).reverse();
        const g = lista[0] || (k === 'next' ? golpes[0] : golpes[golpes.length - 1]);
        if (g) { cuadro(Math.max(0, g.inicio - 6)); }
      }
    });
    contenedor.querySelector('[data-v=vel]').onchange = e => vel = +e.target.value;
    contenedor.querySelector('[data-v=cam]').onchange = e => { [az, el] = vistas[e.target.value](); };
    barra.oninput = () => { cuadro(+barra.value); };
    let arr = null;
    lienzo.addEventListener('pointerdown', e => { arr = [e.clientX, e.clientY, az, el]; lienzo.setPointerCapture(e.pointerId); });
    lienzo.addEventListener('pointermove', e => { if (!arr) return; az = arr[2] - (e.clientX - arr[0]) * 0.01; el = Math.max(-0.1, Math.min(1.4, arr[3] + (e.clientY - arr[1]) * 0.006)); });
    lienzo.addEventListener('pointerup', () => arr = null);
    lienzo.addEventListener('wheel', e => { dist = Math.max(1.5, Math.min(8, dist * (e.deltaY > 0 ? 1.08 : 0.93))); e.preventDefault(); }, { passive: false });
    const ro = new ResizeObserver(tam); ro.observe(lienzo); tam();
    cuadro(golpes[0] ? Math.max(0, golpes[0].inicio - 6) : 0);
    requestAnimationFrame(bucle);
    return { destruir() { vivo = false; ro.disconnect(); renderer.dispose(); }, ir(k) { cuadro(k); } };
  }
  return { crear };
})();

/* Paleta — animación 3D lado a lado: el jugador tal como se grabó (errores en rojo)
   y el mismo jugador con los golpes corregidos (cambios en verde). Sincronizadas. */
"use strict";
const Vista3D = (() => {
  let THREE = null;
  async function cargarThree() { if (!THREE) THREE = await import('../vendor/three/three.module.min.js'); return THREE; }

  async function crear(contenedor, datos) {
    await cargarThree();
    const { original, corregido, errores, mano, golpes, cambios } = datos;
    const pelota = datos.pelota || null;
    contenedor.innerHTML = `
      <div class="v3d">
        <div class="v3d-lienzo"><canvas></canvas>
          <div class="v3d-tit izq"><b>Tu golpe</b><span class="v3d-err"></span></div>
          <div class="v3d-tit der"><b>Golpe corregido</b><span class="v3d-ok"></span></div>
        </div>
        <div class="v3d-linea"><div class="v3d-marcas"></div><input type="range" min="0" max="${original.length - 1}" value="0" step="1"></div>
        <div class="v3d-ctrl">
          <button class="btn sm" data-v="prev" aria-label="Golpe anterior">⏮</button>
          <button class="btn sm pri" data-v="play">⏸</button>
          <button class="btn sm" data-v="next" aria-label="Golpe siguiente">⏭</button>
          <select data-v="vel"><option value="1">1×</option><option value="0.5" selected>0,5×</option><option value="0.25">0,25×</option></select>
          <select data-v="cam"><option value="lado">Vista lateral</option><option value="frente">De frente</option><option value="atras">Desde atrás</option><option value="arriba">Desde arriba</option></select>
        </div>
        <p class="note v3d-ayuda">Arrastra para girar las vistas. Rojo: articulación con falla. Verde: lo que cambia en la versión corregida.</p>
      </div>`;
    const lienzo = contenedor.querySelector('canvas');
    const renderer = new THREE.WebGLRenderer({ canvas: lienzo, antialias: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setScissorTest(true);

    /* geometría del lugar: piso, mesa reglamentaria (2,74 × 1,525 m, 76 cm de alto) */
    const todos = original.concat(corregido);
    const piso = Math.min(...original.map(c => Math.min(c.P[29][1], c.P[30][1], c.P[31][1], c.P[32][1]))) - 0.01;
    const M = Bio.marco(original[0].P);
    const cadMedia = [0, 0, 0]; original.forEach(c => { const h = [(c.P[23][0] + c.P[24][0]) / 2, 0, (c.P[23][2] + c.P[24][2]) / 2]; cadMedia[0] += h[0] / original.length; cadMedia[2] += h[2] / original.length; });

    function escena(colorBase, colorMarca) {
      const s = new THREE.Scene();
      s.background = new THREE.Color(0x0d1714);
      s.add(new THREE.HemisphereLight(0xffffff, 0x223322, 1.1));
      const sol = new THREE.DirectionalLight(0xffffff, 1.2); sol.position.set(2, 4, 3); s.add(sol);
      const grid = new THREE.GridHelper(8, 16, 0x2f5a4b, 0x1b3029); grid.position.y = piso; s.add(grid);
      /* mesa */
      const mesa = new THREE.Group();
      const tablero = new THREE.Mesh(new THREE.BoxGeometry(1.525, 0.03, 2.74), new THREE.MeshStandardMaterial({ color: 0x1f5fa8, roughness: 0.6 }));
      tablero.position.y = 0.745; mesa.add(tablero);
      const linea = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.032, 2.74), new THREE.MeshBasicMaterial({ color: 0xffffff })); linea.position.y = 0.746; mesa.add(linea);
      for (const z of [-1.36, 1.36]) { const b = new THREE.Mesh(new THREE.BoxGeometry(1.525, 0.032, 0.02), new THREE.MeshBasicMaterial({ color: 0xffffff })); b.position.set(0, 0.746, z); mesa.add(b); }
      const red = new THREE.Mesh(new THREE.BoxGeometry(1.83, 0.1525, 0.01), new THREE.MeshStandardMaterial({ color: 0xdddddd, transparent: true, opacity: 0.55 })); red.position.y = 0.76 + 0.076; mesa.add(red);
      for (const x of [-0.6, 0.6]) for (const z of [-1.2, 1.2]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.73, 0.05), new THREE.MeshStandardMaterial({ color: 0x333333 })); p.position.set(x, 0.365, z); mesa.add(p); }
      /* la mesa queda delante del jugador, con su lado corto frente a él */
      const frente = new THREE.Vector3(M.frente[0], 0, M.frente[2]).normalize();
      const centro = new THREE.Vector3(cadMedia[0], piso, cadMedia[2]).add(frente.clone().multiplyScalar(0.45 + 1.37));
      mesa.position.copy(centro);
      mesa.rotation.y = Math.atan2(frente.x, frente.z);
      s.add(mesa);
      /* esqueleto */
      const matHueso = new THREE.MeshStandardMaterial({ color: colorBase, roughness: 0.4 });
      const matJunta = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
      const matRojo = new THREE.MeshStandardMaterial({ color: 0xff3b3b, emissive: 0x551010 });
      const matMarca = new THREE.MeshStandardMaterial({ color: colorMarca, emissive: 0x0a3a20 });
      const cil = new THREE.CylinderGeometry(0.022, 0.022, 1, 10);
      const esf = new THREE.SphereGeometry(0.032, 14, 10);
      const huesos = Bio.HUESOS.filter(([a, b]) => a >= 11 || b >= 11 ? true : false).map(([a, b]) => { const m = new THREE.Mesh(cil, matHueso); s.add(m); return { a, b, m }; });
      const juntas = []; for (let j = 0; j < 33; j++) { if (j > 0 && j < 11) { juntas.push(null); continue; } const m = new THREE.Mesh(j === 0 ? new THREE.SphereGeometry(0.1, 20, 14) : esf, matJunta); s.add(m); juntas.push(m); }
      /* paleta */
      const paleta = new THREE.Group();
      const cara1 = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.006, 28), new THREE.MeshStandardMaterial({ color: 0xc0262d }));
      const cara2 = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.006, 28), new THREE.MeshStandardMaterial({ color: 0x111111 })); cara2.position.y = -0.007;
      const mango = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.012, 0.1), new THREE.MeshStandardMaterial({ color: 0xc89a5b })); mango.position.z = -0.11;
      const cabeza = new THREE.Group(); cabeza.add(cara1, cara2); cabeza.position.z = 0.02;
      paleta.add(cabeza, mango); s.add(paleta);
      /* pelota con estela */
      const matPel = new THREE.MeshStandardMaterial({ color: 0xff8a1f, emissive: 0x552200 });
      const bola = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 12), matPel); bola.visible = false; s.add(bola);
      const estela = []; for (let k = 0; k < 8; k++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.016, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: 0.5 - k * 0.055 })); m.visible = false; s.add(m); estela.push(m); }
      return { s, huesos, juntas, paleta, matHueso, matJunta, matRojo, matMarca, bola, estela };
    }
    const izq = escena(0x9fb7ad, 0x36d17a), der = escena(0x7fd6a8, 0x36d17a);
    const L = Bio.lados(mano);
    const arriba = new THREE.Vector3(0, 1, 0), tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
    function poner(E, P, rojos, verdes) {
      const v = j => new THREE.Vector3(P[j][0], P[j][1], P[j][2]);
      for (const h of E.huesos) {
        const a = v(h.a), b = v(h.b), d = tmp.subVectors(b, a), l = d.length();
        h.m.position.copy(a).addScaledVector(d, 0.5); h.m.scale.set(1, Math.max(0.001, l), 1);
        h.m.quaternion.setFromUnitVectors(arriba, d.normalize());
        h.m.material = (rojos.has(h.a) && rojos.has(h.b)) ? E.matRojo : (verdes.has(h.a) && verdes.has(h.b)) ? E.matMarca : E.matHueso;
      }
      for (let j = 0; j < 33; j++) { const m = E.juntas[j]; if (!m) continue; m.position.copy(v(j)); m.material = rojos.has(j) ? E.matRojo : verdes.has(j) ? E.matMarca : E.matJunta; }
      /* paleta: sigue la mano (muñeca → índice) */
      const w = v(L.m), i = v(L.i), c = v(L.c);
      const dir = tmp2.subVectors(i, w); if (dir.length() < 1e-4) dir.subVectors(w, c);
      dir.normalize();
      E.paleta.position.copy(w).addScaledVector(dir, 0.05);
      const normal = new THREE.Vector3().subVectors(v(L.p), w).cross(dir).normalize();
      const m4 = new THREE.Matrix4(); const x = new THREE.Vector3().crossVectors(normal, dir).normalize();
      m4.makeBasis(x, normal, dir); E.paleta.quaternion.setFromRotationMatrix(m4);
    }

    /* cámaras */
    const camI = new THREE.PerspectiveCamera(40, 1, 0.05, 50), camD = new THREE.PerspectiveCamera(40, 1, 0.05, 50);
    const objetivo = new THREE.Vector3(cadMedia[0], piso + 0.95, cadMedia[2]);
    const yawFrente = Math.atan2(M.frente[0], M.frente[2]);
    const signoLado = mano === 'Z' ? -1 : 1;
    let az = yawFrente + Math.PI / 2 * signoLado + 0.35, el = 0.18, dist = 3.6;
    const vistas = { lado: () => [yawFrente + Math.PI / 2 * signoLado + 0.35, 0.18], frente: () => [yawFrente, 0.12], atras: () => [yawFrente + Math.PI, 0.25], arriba: () => [yawFrente + Math.PI + 0.01, 1.25] };
    function ubicar(cam) { cam.position.set(objetivo.x + dist * Math.cos(el) * Math.sin(az), objetivo.y + dist * Math.sin(el), objetivo.z + dist * Math.cos(el) * Math.cos(az)); cam.lookAt(objetivo); }

    /* marcas de golpes en la línea de tiempo */
    const marcasEl = contenedor.querySelector('.v3d-marcas');
    marcasEl.innerHTML = golpes.map(g => `<i style="left:${(g.impacto / Math.max(1, original.length - 1) * 100).toFixed(2)}%;background:${g.puntaje >= 80 ? '#38e8a0' : g.puntaje >= 60 ? '#ffb020' : '#ff4d4d'}" title="Golpe ${g.n}"></i>`).join('');

    let i = 0, play = true, vel = 0.5, ultimo = performance.now(), acum = 0, vivo = true;
    const barra = contenedor.querySelector('input[type=range]'), txtE = contenedor.querySelector('.v3d-err'), txtO = contenedor.querySelector('.v3d-ok');
    const dt = original.length > 1 ? (original[original.length - 1].t - original[0].t) / (original.length - 1) : 1 / 30;
    function cuadro(k) {
      i = Math.max(0, Math.min(original.length - 1, k));
      const e = errores[i] || { j: [], textos: [] };
      poner(izq, original[i].P, new Set(e.j), new Set());
      const ver = new Set(); (corregido[i].marcas || []).forEach(z => Evz(z).forEach(j => ver.add(j)));
      poner(der, corregido[i].P, new Set(), ver);
      for (const E of [izq, der]) {
        const b = pelota && pelota[i]; E.bola.visible = !!b; if (b) E.bola.position.set(b[0], b[1], b[2]);
        E.estela.forEach((m, k) => { const q = pelota && pelota[i - (k + 1) * 2]; m.visible = !!q; if (q) m.position.set(q[0], q[1], q[2]); });
      }
      const g = golpes.find(g => i >= g.inicio && i <= g.fin);
      txtE.textContent = [g && g.info, e.textos.slice(0, 2).join(' · ')].filter(Boolean).join(' — ');
      txtO.textContent = g && cambios[g.n] ? cambios[g.n] : '';
      barra.value = i;
    }
    function Evz(z) {
      const mapa = { apoyo: 'pies', rodillas: 'piernas', giro: 'tronco', cadera: 'cadera', brazo: 'mano', codo: 'codo', brazoLibre: 'brazoLibre' };
      return Ev.articulacionesZona(mapa[z] || z, mano);
    }
    function tam() {
      const W = lienzo.clientWidth, H = lienzo.clientHeight;
      renderer.setSize(W, H, false);
    }
    function dibujar() {
      const W = lienzo.clientWidth, H = lienzo.clientHeight, vertical = H > W * 1.1;
      const pares = vertical ? [[0, H / 2, W, H / 2], [0, 0, W, H / 2]] : [[0, 0, W / 2, H], [W / 2, 0, W / 2, H]];
      contenedor.querySelector('.v3d').classList.toggle('vertical', vertical);
      ubicar(camI); ubicar(camD);
      [[izq, camI, pares[0]], [der, camD, pares[1]]].forEach(([E, cam, r]) => {
        cam.aspect = r[2] / r[3]; cam.updateProjectionMatrix();
        renderer.setViewport(r[0], r[1], r[2], r[3]); renderer.setScissor(r[0], r[1], r[2], r[3]);
        renderer.render(E.s, cam);
      });
    }
    function bucle(ahora) {
      if (!vivo) return;
      const d = (ahora - ultimo) / 1000; ultimo = ahora;
      if (play) { acum += d * vel; while (acum >= dt) { acum -= dt; cuadro(i + 1 >= original.length ? 0 : i + 1); } }
      dibujar();
      requestAnimationFrame(bucle);
    }
    /* controles */
    contenedor.addEventListener('click', ev => {
      const b = ev.target.closest('[data-v]'); if (!b || b.tagName === 'SELECT') return;
      const k = b.dataset.v;
      if (k === 'play') { play = !play; b.textContent = play ? '⏸' : '▶'; }
      if (k === 'next' || k === 'prev') {
        const lista = k === 'next' ? golpes.filter(g => g.inicio > i + 1) : golpes.filter(g => g.inicio < i - 1).reverse();
        const g = lista[0] || (k === 'next' ? golpes[0] : golpes[golpes.length - 1]);
        if (g) { cuadro(Math.max(0, g.inicio - 6)); }
      }
    });
    contenedor.querySelector('[data-v=vel]').onchange = e => vel = +e.target.value;
    contenedor.querySelector('[data-v=cam]').onchange = e => { [az, el] = vistas[e.target.value](); };
    barra.oninput = () => { cuadro(+barra.value); };
    let arr = null;
    lienzo.addEventListener('pointerdown', e => { arr = [e.clientX, e.clientY, az, el]; lienzo.setPointerCapture(e.pointerId); });
    lienzo.addEventListener('pointermove', e => { if (!arr) return; az = arr[2] - (e.clientX - arr[0]) * 0.01; el = Math.max(-0.1, Math.min(1.4, arr[3] + (e.clientY - arr[1]) * 0.006)); });
    lienzo.addEventListener('pointerup', () => arr = null);
    lienzo.addEventListener('wheel', e => { dist = Math.max(1.5, Math.min(8, dist * (e.deltaY > 0 ? 1.08 : 0.93))); e.preventDefault(); }, { passive: false });
    const ro = new ResizeObserver(tam); ro.observe(lienzo); tam();
    cuadro(golpes[0] ? Math.max(0, golpes[0].inicio - 6) : 0);
    requestAnimationFrame(bucle);
    return { destruir() { vivo = false; ro.disconnect(); renderer.dispose(); }, ir(k) { cuadro(k); } };
  }
  return { crear };
})();

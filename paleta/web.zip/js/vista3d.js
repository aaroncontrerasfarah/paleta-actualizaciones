/* Paleta — animación 3D lado a lado, en un pabellón de tenis de mesa:
   el jugador tal como se grabó (zonas con falla en rojo) y el mismo jugador con los golpes corregidos (cambios en verde).
   Sobre cada figura se dibujan las mediciones: ángulo de rodilla y codo, inclinación del tronco, separación de pies,
   giro de hombros, trayectoria de la mano y punto de impacto, con su valor (verde dentro del rango, rojo fuera). */
"use strict";
const Vista3D = (() => {
  let THREE = null;
  async function cargarThree() { if (!THREE) THREE = await import('../vendor/three/three.module.min.js'); return THREE; }

  async function crear(contenedor, datos) {
    await cargarThree();
    const { original, corregido, errores, mano, golpes, cambios } = datos;
    const pelota = datos.pelota || null, refs = datos.refs || {};
    contenedor.innerHTML = `
      <div class="v3d">
        <div class="v3d-lienzo"><canvas></canvas><div class="v3d-etiquetas"></div>
          <div class="v3d-tit izq"><b>Tu golpe</b><span class="v3d-err"></span></div>
          <div class="v3d-tit der"><b>Golpe corregido</b><span class="v3d-ok"></span></div>
        </div>
        <div class="v3d-linea"><div class="v3d-marcas"></div><input type="range" min="0" max="${original.length - 1}" value="0" step="1"></div>
        <div class="v3d-ctrl">
          <button class="btn sm" data-v="prev" aria-label="Golpe anterior">⏮</button>
          <button class="btn sm pri" data-v="play">⏸</button>
          <button class="btn sm" data-v="next" aria-label="Golpe siguiente">⏭</button>
          <select data-v="vel"><option value="1">1×</option><option value="0.5" selected>0,5×</option><option value="0.25">0,25×</option></select>
          <select data-v="cam"><option value="lado">Lateral</option><option value="tv">Transmisión (TV)</option><option value="frente">De frente</option><option value="atras">Desde atrás</option><option value="arriba">Desde arriba</option></select>
          <button class="btn sm on" data-v="med" aria-pressed="true">📐 Mediciones</button>
        </div>
        <p class="note v3d-ayuda">Arrastra para girar y pellizca o usa la rueda para acercar. Rojo: zona con falla. Verde: lo que cambia en la versión corregida. Las cifras se ponen rojas cuando están fuera del rango esperado.</p>
      </div>`;
    const lienzo = contenedor.querySelector('canvas'), capaEt = contenedor.querySelector('.v3d-etiquetas');
    const renderer = new THREE.WebGLRenderer({ canvas: lienzo, antialias: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setScissorTest(true);
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;

    const L = Bio.lados(mano);
    const piso = Math.min(...original.map(c => Math.min(c.P[29][1], c.P[30][1], c.P[31][1], c.P[32][1]))) - 0.005;
    const M0 = Bio.marco(original[0].P);
    const cadMedia = [0, 0, 0]; original.forEach(c => { cadMedia[0] += (c.P[23][0] + c.P[24][0]) / 2 / original.length; cadMedia[2] += (c.P[23][2] + c.P[24][2]) / 2 / original.length; });
    const V = (x, y, z) => new THREE.Vector3(x, y, z);
    const frenteMesa = V(M0.frente[0], 0, M0.frente[2]).normalize();
    const centroMesa = V(cadMedia[0], piso, cadMedia[2]).add(frenteMesa.clone().multiplyScalar(0.5 + 1.37));
    const giroMesa = Math.atan2(frenteMesa.x, frenteMesa.z);

    /* ---------- texturas generadas ---------- */
    function texturaPiso() {
      const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
      g.fillStyle = '#7a2a22'; g.fillRect(0, 0, 256, 256);
      for (let k = 0; k < 5000; k++) { const v = Math.random() * 28 - 14; g.fillStyle = `rgba(${120 + v},${40 + v / 2},${32 + v / 2},0.35)`; g.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5); }
      const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(10, 10); t.colorSpace = THREE.SRGBColorSpace; return t;
    }
    function texturaValla() {
      const c = document.createElement('canvas'); c.width = 512; c.height = 64; const g = c.getContext('2d');
      g.fillStyle = '#16305e'; g.fillRect(0, 0, 512, 64); g.fillStyle = '#ffffff'; g.font = 'bold 34px sans-serif'; g.textAlign = 'center'; g.fillText('PALETA', 256, 44);
      g.fillStyle = '#ff8a1f'; g.fillRect(0, 0, 512, 5);
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
    }
    const TEX = { piso: texturaPiso(), valla: texturaValla() };

    /* ---------- figura humana ---------- */
    const PIEL = 0xc98f6b, PELO = 0x1d140e, SHORT = 0x15181f, ZAPA = 0xf4f4f4, SUELA = 0x2c3038;
    function crearFigura(sc, camiseta, opacidad) {
      const tr = opacidad < 1;
      const mat = (c, r) => new THREE.MeshStandardMaterial({ color: c, roughness: r ?? 0.7, metalness: 0, transparent: tr, opacity: opacidad });
      const M = { piel: mat(PIEL, 0.55), camiseta: mat(camiseta, 0.85), short: mat(SHORT, 0.8), zapa: mat(ZAPA, 0.5), suela: mat(SUELA, 0.6), pelo: mat(PELO, 0.9), ojo: mat(0x111111, 0.3) };
      const esf = new THREE.SphereGeometry(1, 24, 18);
      const partes = [];
      const poner = m => { m.castShadow = !tr; sc.add(m); return m; };
      function seg(a, b, r1, r2, material, desde, hasta) {
        const m = poner(new THREE.Mesh(new THREE.CylinderGeometry(r2, r1, 1, 22, 1, true), material.clone()));
        partes.push({ tipo: 'seg', a, b, m, desde: desde || 0, hasta: hasta || 1, base: material }); }
      function junta(j, r, material) { const m = poner(new THREE.Mesh(esf, material.clone())); m.scale.setScalar(r); partes.push({ tipo: 'junta', j, m, base: material }); }
      function bulto(a, b, f, rx, ry, rz, material) { const m = poner(new THREE.Mesh(esf, material.clone())); partes.push({ tipo: 'bulto', a, b, f, rx, ry, rz, m, base: material }); }
      for (const [h, c, mu] of [[11, 13, 15], [12, 14, 16]]) {
        seg(h, c, 0.054, 0.047, M.camiseta, 0, 0.48); seg(h, c, 0.044, 0.04, M.piel, 0.48, 1);
        seg(c, mu, 0.039, 0.028, M.piel); bulto(c, mu, 0.3, 0.045, 0.09, 0.042, M.piel);
        junta(c, 0.041, M.piel); junta(h, 0.064, M.camiseta); junta(mu, 0.029, M.piel);
      }
      for (const [c, r, t] of [[23, 25, 27], [24, 26, 28]]) {
        seg(c, r, 0.088, 0.08, M.short, 0, 0.42); seg(c, r, 0.075, 0.056, M.piel, 0.42, 1); bulto(c, r, 0.55, 0.074, 0.15, 0.078, M.piel);
        seg(r, t, 0.055, 0.034, M.piel); bulto(r, t, 0.3, 0.06, 0.12, 0.066, M.piel);
        junta(r, 0.057, M.piel); junta(t, 0.037, M.piel); junta(c, 0.085, M.short);
      }
      const manos = [15, 16].map(j => { const m = poner(new THREE.Mesh(esf, M.piel.clone())); return { j, m }; });
      const zapas = [[29, 31, 27], [30, 32, 28]].map(([t, p]) => {
        const g = new THREE.Group();
        const cuerpo = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.16, 6, 14), M.zapa.clone()); cuerpo.rotation.x = Math.PI / 2; cuerpo.scale.set(1.05, 1, 0.8); cuerpo.position.y = 0.035;
        const suela = new THREE.Mesh(new THREE.BoxGeometry(0.098, 0.022, 0.27), M.suela.clone()); suela.position.y = 0.011;
        const franja = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.012, 0.12), new THREE.MeshStandardMaterial({ color: 0xff8a1f, transparent: tr, opacity: opacidad })); franja.position.set(0, 0.045, -0.02);
        [cuerpo, suela, franja].forEach(o => { o.castShadow = !tr; g.add(o); }); sc.add(g); return { t, p, g, cuerpo };
      });
      const tronco = { pecho: poner(new THREE.Mesh(esf, M.camiseta.clone())), abdomen: poner(new THREE.Mesh(esf, M.camiseta.clone())), pelvis: poner(new THREE.Mesh(esf, M.short.clone())), cuello: poner(new THREE.Mesh(new THREE.CylinderGeometry(1, 1.1, 1, 16), M.piel.clone())) };
      const cab = { cabeza: poner(new THREE.Mesh(esf, M.piel.clone())), pelo: poner(new THREE.Mesh(new THREE.SphereGeometry(1, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.56), M.pelo.clone())),
        nariz: poner(new THREE.Mesh(esf, M.piel.clone())), ojoI: poner(new THREE.Mesh(esf, M.ojo)), ojoD: poner(new THREE.Mesh(esf, M.ojo)), orejaI: poner(new THREE.Mesh(esf, M.piel.clone())), orejaD: poner(new THREE.Mesh(esf, M.piel.clone())) };
      return { partes, manos, zapas, tronco, cab, M };
    }
    const Y = V(0, 1, 0);
    const v3 = (P, j) => V(P[j][0], P[j][1], P[j][2]);
    function orientar(m, a, b) { const d = b.clone().sub(a); const l = d.length(); m.position.copy(a).addScaledVector(d, 0.5); if (l > 1e-6) m.quaternion.setFromUnitVectors(Y, d.normalize()); return l; }
    function base(m, x, y, z, sx, sy, sz) { m.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, z)); m.scale.set(sx, sy, sz); }
    function tinte(m, estado) { m.material.emissive.setHex(estado === 'rojo' ? 0x7a0606 : estado === 'verde' ? 0x05261a : 0x000000); }
    function ponerFigura(F, P, rojos, verdes) {
      const est = (...js) => js.every(j => rojos.has(j)) ? 'rojo' : js.every(j => verdes.has(j)) ? 'verde' : '';
      for (const p of F.partes) {
        if (p.tipo === 'seg') { const a = v3(P, p.a), b = v3(P, p.b); const l = orientar(p.m, a.clone().lerp(b, p.desde), a.clone().lerp(b, p.hasta)); p.m.scale.set(1, Math.max(0.001, l), 1); tinte(p.m, est(p.a, p.b)); }
        else if (p.tipo === 'bulto') { const a = v3(P, p.a), b = v3(P, p.b); p.m.position.copy(a).lerp(b, p.f); p.m.quaternion.setFromUnitVectors(Y, b.clone().sub(a).normalize()); p.m.scale.set(p.rx, p.ry, p.rz); tinte(p.m, est(p.a, p.b)); }
        else { p.m.position.copy(v3(P, p.j)); tinte(p.m, rojos.has(p.j) ? 'rojo' : verdes.has(p.j) ? 'verde' : ''); }
      }
      for (const h of F.manos) { const w = v3(P, h.j), ix = v3(P, h.j === 16 ? 20 : 19); h.m.position.copy(w).lerp(ix, 0.5); h.m.quaternion.setFromUnitVectors(Y, ix.clone().sub(w).normalize()); h.m.scale.set(0.038, 0.052, 0.024); tinte(h.m, rojos.has(h.j) ? 'rojo' : verdes.has(h.j) ? 'verde' : ''); }
      for (const z of F.zapas) {
        const t = v3(P, z.t), p = v3(P, z.p); const d = p.clone().sub(t); d.y = 0; if (d.length() < 1e-4) d.set(0, 0, 1); d.normalize();
        const x = V(0, 0, 0).crossVectors(Y, d).normalize();
        z.g.position.copy(t).lerp(p, 0.45); z.g.position.y = Math.min(t.y, p.y) - 0.01;
        z.g.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, Y, d));
        tinte(z.cuerpo, rojos.has(z.t) || rojos.has(z.p) ? 'rojo' : verdes.has(z.t) ? 'verde' : '');
      }
      const hI = v3(P, 11), hD = v3(P, 12), cI = v3(P, 23), cD = v3(P, 24);
      const hom = hI.clone().add(hD).multiplyScalar(0.5), cad = cI.clone().add(cD).multiplyScalar(0.5);
      const arriba = hom.clone().sub(cad), largo = arriba.length(); arriba.normalize();
      const der = hD.clone().sub(hI); der.addScaledVector(arriba, -der.dot(arriba)); const anchoH = der.length(); der.normalize();
      const frente = V(0, 0, 0).crossVectors(der, arriba).normalize();
      const derC = cD.clone().sub(cI); derC.addScaledVector(arriba, -derC.dot(arriba)); const anchoC = derC.length(); derC.normalize();
      const frenteC = V(0, 0, 0).crossVectors(derC, arriba).normalize();
      const T = F.tronco;
      T.pecho.position.copy(cad).addScaledVector(arriba, largo * 0.73).addScaledVector(frente, 0.012);
      base(T.pecho, der, arriba, frente, Math.max(0.14, anchoH * 0.64), largo * 0.37, 0.12);
      const medio = der.clone().lerp(derC, 0.5).normalize(), frenteM = V(0, 0, 0).crossVectors(medio, arriba).normalize();
      T.abdomen.position.copy(cad).addScaledVector(arriba, largo * 0.38);
      base(T.abdomen, medio, arriba, frenteM, Math.max(0.115, anchoC * 0.82), largo * 0.34, 0.1);
      T.pelvis.position.copy(cad).addScaledVector(arriba, 0.03);
      base(T.pelvis, derC, arriba, frenteC, Math.max(0.13, anchoC * 0.92), 0.125, 0.115);
      const eT = est(11, 12, 23, 24); [T.pecho, T.abdomen].forEach(m => tinte(m, eT)); tinte(T.pelvis, est(23, 24));
      const oI = v3(P, 7), oD = v3(P, 8), nar = v3(P, 0);
      const centro = oI.clone().add(oD).multiplyScalar(0.5).lerp(nar, 0.22).addScaledVector(arriba, 0.025);
      const cuelloBase = hom.clone().addScaledVector(arriba, 0.015), cuelloTope = cuelloBase.clone().lerp(centro, 0.62);
      const lc = orientar(T.cuello, cuelloBase, cuelloTope); T.cuello.scale.set(0.048, Math.max(0.01, lc), 0.048);
      const arribaC = centro.clone().sub(cuelloBase).normalize();
      let mira = nar.clone().sub(centro); mira.addScaledVector(arribaC, -mira.dot(arribaC)); if (mira.length() < 1e-4) mira.copy(frente); mira.normalize();
      const xC = V(0, 0, 0).crossVectors(arribaC, mira).normalize();
      const q = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(xC, arribaC, mira));
      const C = F.cab;
      C.cabeza.position.copy(centro); C.cabeza.quaternion.copy(q); C.cabeza.scale.set(0.092, 0.112, 0.104);
      C.pelo.position.copy(centro).addScaledVector(mira, -0.014).addScaledVector(arribaC, 0.012); C.pelo.quaternion.copy(q); C.pelo.scale.set(0.099, 0.118, 0.11);
      C.nariz.position.copy(centro).addScaledVector(mira, 0.1).addScaledVector(arribaC, -0.012); C.nariz.scale.set(0.014, 0.022, 0.016); C.nariz.quaternion.copy(q);
      for (const [o, s] of [[C.ojoI, -1], [C.ojoD, 1]]) { o.position.copy(centro).addScaledVector(mira, 0.088).addScaledVector(arribaC, 0.018).addScaledVector(xC, 0.032 * s); o.scale.setScalar(0.011); }
      for (const [o, s] of [[C.orejaI, -1], [C.orejaD, 1]]) { o.position.copy(centro).addScaledVector(xC, 0.09 * s).addScaledVector(mira, -0.005); o.quaternion.copy(q); o.scale.set(0.014, 0.03, 0.02); }
      tinte(C.cabeza, rojos.has(0) ? 'rojo' : verdes.has(0) ? 'verde' : '');
    }

    /* ---------- escenario: pabellón ---------- */
    function crearMesa() {
      const g = new THREE.Group();
      const azul = new THREE.MeshStandardMaterial({ color: 0x1a4a86, roughness: 0.38, metalness: 0.05 });
      const blanco = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
      const metal = new THREE.MeshStandardMaterial({ color: 0x40444c, roughness: 0.45, metalness: 0.6 });
      const tablero = new THREE.Mesh(new THREE.BoxGeometry(1.525, 0.025, 2.74), azul); tablero.position.y = 0.7475; g.add(tablero);
      const sup = 0.7605;
      const linea = (w, d, x, z) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.002, d), blanco); m.position.set(x, sup, z); g.add(m); };
      linea(0.02, 2.74, -0.7525, 0); linea(0.02, 2.74, 0.7525, 0); linea(1.525, 0.02, 0, -1.36); linea(1.525, 0.02, 0, 1.36); linea(0.003, 2.74, 0, 0);
      const faldon = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.06, 2.66), metal); faldon.position.y = 0.705; g.add(faldon);
      for (const z of [-0.95, 0.95]) {
        for (const x of [-0.62, 0.62]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.69, 0.045), metal); p.position.set(x, 0.345, z); g.add(p);
          const r = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.025, 14), new THREE.MeshStandardMaterial({ color: 0x111111 })); r.rotation.z = Math.PI / 2; r.position.set(x, 0.03, z); g.add(r); }
        const tr = new THREE.Mesh(new THREE.BoxGeometry(1.24, 0.035, 0.035), metal); tr.position.set(0, 0.18, z); g.add(tr);
      }
      /* red y postes: 15,25 cm de alto, sobresale 15,25 cm por lado */
      const red = new THREE.Mesh(new THREE.PlaneGeometry(1.83, 0.1525), new THREE.MeshStandardMaterial({ color: 0x0b0f17, transparent: true, opacity: 0.55, side: THREE.DoubleSide }));
      red.position.set(0, sup + 0.076, 0); red.rotation.y = Math.PI / 2; red.rotation.y = 0; red.rotation.x = 0; red.lookAt(V(0, sup + 0.076, 1)); g.add(red);
      const banda = new THREE.Mesh(new THREE.BoxGeometry(1.83, 0.015, 0.006), blanco); banda.position.set(0, sup + 0.148, 0); g.add(banda);
      for (const x of [-0.915, 0.915]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.16, 10), metal); p.position.set(x, sup + 0.08, 0); g.add(p); }
      g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      return g;
    }
    function escena(camiseta) {
      const s = new THREE.Scene();
      s.background = new THREE.Color(0x1a2026);
      s.fog = new THREE.Fog(0x1a2026, 10, 24);
      s.add(new THREE.HemisphereLight(0xf4f1ea, 0x3a2a24, 0.75));
      const sol = new THREE.DirectionalLight(0xffffff, 1.7);
      sol.position.set(cadMedia[0] + 2, piso + 6, cadMedia[2] + 1.5); sol.target.position.set(cadMedia[0], piso, cadMedia[2]);
      sol.castShadow = true; sol.shadow.mapSize.set(1024, 1024); Object.assign(sol.shadow.camera, { left: -3.5, right: 3.5, top: 3.5, bottom: -3.5 }); sol.shadow.bias = -0.0004; sol.shadow.radius = 4;
      s.add(sol, sol.target);
      const rel = new THREE.DirectionalLight(0xd6e6ff, 0.5); rel.position.set(cadMedia[0] - 4, piso + 3, cadMedia[2] - 3); s.add(rel);
      /* recinto alineado con la mesa */
      const recinto = new THREE.Group(); recinto.position.copy(centroMesa); recinto.rotation.y = giroMesa; s.add(recinto);
      const suelo = new THREE.Mesh(new THREE.PlaneGeometry(26, 34), new THREE.MeshStandardMaterial({ map: TEX.piso, roughness: 0.8 }));
      suelo.rotation.x = -Math.PI / 2; suelo.receiveShadow = true; recinto.add(suelo);
      /* cancha de 7 × 14 m con vallas de 75 cm */
      const vallaMat = new THREE.MeshStandardMaterial({ map: TEX.valla, roughness: 0.6 });
      const valla = (largo, x, z, rot) => { for (let k = 0; k < Math.round(largo / 2); k++) { const v = new THREE.Mesh(new THREE.BoxGeometry(1.96, 0.72, 0.03), vallaMat); v.position.set(x, 0.36, z); v.rotation.y = rot; v.translateX(-largo / 2 + 1 + k * 2); v.castShadow = true; v.receiveShadow = true; recinto.add(v); } };
      valla(14, 3.5, 0, Math.PI / 2); valla(14, -3.5, 0, -Math.PI / 2); valla(6, 0, 7, 0); valla(6, 0, -7, Math.PI);
      /* paredes y luces del techo */
      /* paredes (solo los costados, sin piso ni techo) con una franja azul */
      const matPared = new THREE.MeshStandardMaterial({ color: 0x2f3842, roughness: 1 }), matFranja = new THREE.MeshStandardMaterial({ color: 0x16305e, roughness: 0.9 });
      for (const [w, x, z, ry] of [[26, 0, -17, 0], [26, 0, 17, Math.PI], [34, -13, 0, Math.PI / 2], [34, 13, 0, -Math.PI / 2]]) {
        const pa = new THREE.Mesh(new THREE.PlaneGeometry(w, 9), matPared); pa.position.set(x, 4.5, z); pa.rotation.y = ry; recinto.add(pa);
        const fr = new THREE.Mesh(new THREE.PlaneGeometry(w, 1.4), matFranja); fr.position.set(x, 1.0, z); fr.rotation.y = ry; fr.translateZ(0.01); recinto.add(fr);
      }
      for (const x of [-2.5, 2.5]) for (const z of [-4, 0, 4]) { const l = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.3), new THREE.MeshBasicMaterial({ color: 0xfffbe8 })); l.position.set(x, 7.5, z); recinto.add(l); }
      const mesa = crearMesa(); recinto.add(mesa);
      /* rival al otro lado, quieto en posición de espera */
      const rival = crearFigura(s, 0xb3262d, 0.85);
      const Pr = original[0].P.map(p => { const v = V(p[0], p[1], p[2]); const d = v.clone().sub(centroMesa); d.x = -d.x; d.z = -d.z; const w = centroMesa.clone().add(d); w.y = p[1]; return [w.x, w.y, w.z]; });
      ponerFigura(rival, Pr, new Set(), new Set());
      const fig = crearFigura(s, camiseta, 1);
      /* paleta */
      const paleta = new THREE.Group();
      const hoja = new THREE.Group();
      const madera = new THREE.Mesh(new THREE.CylinderGeometry(0.079, 0.079, 0.006, 32), new THREE.MeshStandardMaterial({ color: 0xc89a5b, roughness: 0.6 }));
      const roja = new THREE.Mesh(new THREE.CylinderGeometry(0.077, 0.077, 0.003, 32), new THREE.MeshStandardMaterial({ color: 0xc0262d, roughness: 0.45 })); roja.position.y = 0.0045;
      const negra = new THREE.Mesh(new THREE.CylinderGeometry(0.077, 0.077, 0.003, 32), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.45 })); negra.position.y = -0.0045;
      hoja.add(madera, roja, negra); hoja.scale.set(1, 1, 1.08); hoja.position.z = 0.045;
      const mango = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.022, 0.1), new THREE.MeshStandardMaterial({ color: 0xa8743d, roughness: 0.7 })); mango.position.z = -0.06;
      paleta.add(hoja, mango); paleta.traverse(o => { if (o.isMesh) o.castShadow = true; }); s.add(paleta);
      /* pelota con estela */
      const bola = new THREE.Mesh(new THREE.SphereGeometry(0.03, 16, 12), new THREE.MeshStandardMaterial({ color: 0xff8a1f, emissive: 0x6a2a00 })); bola.visible = false; bola.castShadow = true; s.add(bola);
      const estela = []; for (let k = 0; k < 10; k++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.013, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: 0.55 - k * 0.05 })); m.visible = false; s.add(m); estela.push(m); }
      /* mediciones */
      const med = crearMediciones(s);
      return { s, fig, paleta, bola, estela, med };
    }

    /* ---------- mediciones dibujadas ---------- */
    const COL = { ok: 0x38e8a0, mal: 0xff4d4d, neutro: 0xffd400, mano: 0xff8a1f, ref: 0xffffff };
    function crearMediciones(s) {
      const g = new THREE.Group(); s.add(g);
      const linea = (n, color, dashed) => {
        const geo = new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
        const mat = dashed ? new THREE.LineDashedMaterial({ color, dashSize: 0.04, gapSize: 0.03, depthTest: false, transparent: true, opacity: 0.9 }) : new THREE.LineBasicMaterial({ color, depthTest: false, transparent: true, opacity: 0.95 });
        const l = new THREE.Line(geo, mat); l.renderOrder = 10; l.frustumCulled = false; g.add(l); return l;
      };
      const tubo = (color) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 1, 8), new THREE.MeshBasicMaterial({ color, depthTest: false, transparent: true, opacity: 0.9 })); m.renderOrder = 11; g.add(m); return m; };
      const disco = (color) => { const m = new THREE.Mesh(new THREE.CircleGeometry(1, 32), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthTest: false })); m.renderOrder = 9; g.add(m); return m; };
      return {
        g,
        arcoRod: linea(24, COL.ok), arcoCodo: linea(24, COL.ok), sectorRod: disco(COL.ok), sectorCodo: disco(COL.ok),
        columna: tubo(COL.ok), vertical: linea(2, COL.ref, true), arcoTronco: linea(16, COL.ok),
        pies: tubo(COL.ok), hombros: linea(2, COL.neutro), caderas: linea(2, COL.ref, true),
        mano: linea(40, COL.mano), impacto: (() => { const m = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.008, 8, 28), new THREE.MeshBasicMaterial({ color: COL.mano, depthTest: false })); m.renderOrder = 12; g.add(m); return m; })(),
        anclas: {}
      };
    }
    function setLinea(l, pts) {
      const a = l.geometry.attributes.position; const n = a.count;
      for (let k = 0; k < n; k++) { const p = pts[Math.min(k, pts.length - 1)] || pts[0]; a.setXYZ(k, p.x, p.y, p.z); }
      a.needsUpdate = true; l.geometry.computeBoundingSphere(); if (l.material.isLineDashedMaterial) l.computeLineDistances();
    }
    function setTubo(m, a, b) { const l = orientar(m, a, b); m.scale.set(1, Math.max(0.001, l), 1); }
    function arco(centro, a, b, r, n) {
      const u = a.clone().sub(centro).normalize(), w = b.clone().sub(centro).normalize();
      const ang = Math.acos(Math.max(-1, Math.min(1, u.dot(w)))), eje = V(0, 0, 0).crossVectors(u, w).normalize();
      const pts = []; for (let k = 0; k < n; k++) { const q = new THREE.Quaternion().setFromAxisAngle(eje, ang * k / (n - 1)); pts.push(centro.clone().add(u.clone().applyQuaternion(q).multiplyScalar(r))); }
      return { pts, ang: ang * 180 / Math.PI, eje, u };
    }
    const enRango = (k, v) => { const r = refs[k]; if (!r || !isFinite(v)) return 'neutro'; return v >= r[0] && v <= r[1] ? 'ok' : 'mal'; };
    function colorear(obj, estado) { obj.material.color.setHex(COL[estado] || COL.neutro); }
    function ponerMediciones(E, cuadros, i, impacto) {
      const P = cuadros[i].P, m = E.med;
      const rod = [L.signo > 0 ? 24 : 23, L.signo > 0 ? 26 : 25, L.signo > 0 ? 28 : 27];
      /* rodilla del lado que golpea */
      const k = v3(P, rod[1]), arR = arco(k, v3(P, rod[0]), v3(P, rod[2]), 0.11, 24);
      setLinea(m.arcoRod, arR.pts);
      const vRod = Bio.angulo(P[23], P[25], P[27]) / 2 + Bio.angulo(P[24], P[26], P[28]) / 2;
      const eRod = enRango('rodillas', vRod); colorear(m.arcoRod, eRod);
      m.sectorRod.position.copy(k); m.sectorRod.scale.setScalar(0.11); m.sectorRod.lookAt(k.clone().add(arR.eje)); colorear(m.sectorRod, eRod);
      /* codo */
      const c = v3(P, L.c), arC = arco(c, v3(P, L.h), v3(P, L.m), 0.09, 24);
      setLinea(m.arcoCodo, arC.pts); const eCodo = enRango('codo', arC.ang); colorear(m.arcoCodo, eCodo);
      m.sectorCodo.position.copy(c); m.sectorCodo.scale.setScalar(0.09); m.sectorCodo.lookAt(c.clone().add(arC.eje)); colorear(m.sectorCodo, eCodo);
      /* tronco: columna, vertical de referencia y ángulo */
      const cad = v3(P, 23).add(v3(P, 24)).multiplyScalar(0.5), hom = v3(P, 11).add(v3(P, 12)).multiplyScalar(0.5);
      setTubo(m.columna, cad, hom);
      const largo = hom.distanceTo(cad), top = cad.clone().add(V(0, largo, 0));
      setLinea(m.vertical, [cad, top]);
      const vTr = Bio.inclinacion(P), eTr = enRango('tronco', vTr); colorear(m.columna, eTr);
      setLinea(m.arcoTronco, arco(cad, top, hom, largo * 0.45, 16).pts); colorear(m.arcoTronco, eTr);
      /* pies */
      const tI = v3(P, 27), tD = v3(P, 28); tI.y = tD.y = piso + 0.01;
      setTubo(m.pies, tI, tD); const vAp = Bio.marco ? (V(P[28][0] - P[27][0], 0, P[28][2] - P[27][2]).length() / Math.max(0.2, V(P[12][0] - P[11][0], 0, P[12][2] - P[11][2]).length())) : 0;
      const eAp = enRango('apoyo', vAp); colorear(m.pies, eAp);
      /* hombros y caderas vistos desde arriba: giro relativo */
      const hI = v3(P, 11), hD = v3(P, 12), ext = hD.clone().sub(hI).multiplyScalar(0.35);
      setLinea(m.hombros, [hI.clone().sub(ext), hD.clone().add(ext)]);
      const cI = v3(P, 23), cD = v3(P, 24), extC = cD.clone().sub(cI).multiplyScalar(0.6);
      setLinea(m.caderas, [cI.clone().sub(extC), cD.clone().add(extC)]);
      const yawH = Math.atan2(P[12][2] - P[11][2], P[12][0] - P[11][0]), yawC = Math.atan2(P[24][2] - P[23][2], P[24][0] - P[23][0]);
      let giro = (yawH - yawC) * 180 / Math.PI; while (giro > 180) giro -= 360; while (giro < -180) giro += 360;
      /* trayectoria de la mano (últimos cuadros) y punto de impacto */
      const desde = Math.max(0, i - 39), pts = []; for (let k2 = desde; k2 <= i; k2++) pts.push(v3(cuadros[k2].P, L.m));
      setLinea(m.mano, pts);
      if (impacto !== null && impacto !== undefined) { m.impacto.visible = true; m.impacto.position.copy(v3(cuadros[impacto].P, L.m)); m.impacto.lookAt(V(0, 0, 0).copy(m.impacto.position).add(frenteMesa)); }
      else m.impacto.visible = false;
      const fmt = v => Math.round(v);
      return [
        { p: k.clone().add(V(0, 0.02, 0)), t: `Rodillas ${fmt(vRod)}°`, e: eRod },
        { p: c.clone().add(V(0, 0.03, 0)), t: `Codo ${fmt(arC.ang)}°`, e: eCodo },
        { p: cad.clone().lerp(hom, 0.6), t: `Tronco ${fmt(vTr)}°`, e: eTr },
        { p: tI.clone().lerp(tD, 0.5), t: `Pies ${vAp.toFixed(1).replace('.', ',')}×`, e: eAp },
        { p: hD.clone().add(ext).add(V(0, 0.05, 0)), t: `Giro hombros ${fmt(Math.abs(giro))}°`, e: 'neutro' },
        impacto !== null && impacto !== undefined ? { p: m.impacto.position.clone().add(V(0, 0.08, 0)), t: 'Impacto', e: 'mano' } : null
      ].filter(Boolean);
    }

    const izq = escena(0x2f6fd6), der = escena(0x2f6fd6);
    function ponerPaleta(E, P) {
      const w = v3(P, L.m), ix = v3(P, L.i), c = v3(P, L.c), pul = v3(P, L.p);
      const dir = ix.clone().sub(w); if (dir.length() < 1e-4) dir.copy(w.clone().sub(c)); dir.normalize();
      E.paleta.position.copy(w).addScaledVector(dir, 0.07);
      const normal = pul.clone().sub(w).cross(dir).normalize(); const x = V(0, 0, 0).crossVectors(normal, dir).normalize();
      E.paleta.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, normal, dir));
    }

    /* ---------- cámaras ---------- */
    const camI = new THREE.PerspectiveCamera(38, 1, 0.05, 60), camD = new THREE.PerspectiveCamera(38, 1, 0.05, 60);
    const objetivo = V(cadMedia[0], piso + 0.9, cadMedia[2]).addScaledVector(frenteMesa, 0.35);
    const yawF = Math.atan2(M0.frente[0], M0.frente[2]), sL = mano === 'Z' ? -1 : 1;
    const VISTAS = { lado: [yawF + Math.PI / 2 * sL + 0.4, 0.22, 4.1], tv: [yawF + Math.PI + 0.35 * sL, 0.42, 5.2], frente: [yawF, 0.15, 3.4], atras: [yawF + Math.PI, 0.28, 3.4], arriba: [yawF + Math.PI + 0.01, 1.3, 4.2] };
    let [az, el, dist] = VISTAS.lado;
    function ubicar(cam) { cam.position.set(objetivo.x + dist * Math.cos(el) * Math.sin(az), objetivo.y + dist * Math.sin(el), objetivo.z + dist * Math.cos(el) * Math.cos(az)); cam.lookAt(objetivo); }

    /* ---------- etiquetas HTML proyectadas ---------- */
    let verMed = true;
    function etiquetas(lista, cam, r, W, H) {
      const puestas = [];
      return lista.map(x => {
        const v = x.p.clone().project(cam); if (v.z > 1) return '';
        let sx = r[0] + (v.x + 1) / 2 * r[2], sy = H - (r[1] + (v.y + 1) / 2 * r[3]);
        if (sx < r[0] || sx > r[0] + r[2] || sy < H - r[1] - r[3] || sy > H - r[1]) return '';
        /* evita que se tapen: corre hacia abajo la que choca con otra */
        const ancho = x.t.length * 6.2 + 14;
        for (let k = 0; k < 6; k++) { const choca = puestas.find(p => Math.abs(p[0] - sx) < (p[2] + ancho) / 2 && Math.abs(p[1] - sy) < 20); if (!choca) break; sy = choca[1] + 21; }
        puestas.push([sx, sy, ancho]);
        return `<span class="et ${x.e}" style="left:${sx.toFixed(0)}px;top:${sy.toFixed(0)}px">${x.t}</span>`;
      }).join('');
    }

    const marcasEl = contenedor.querySelector('.v3d-marcas');
    marcasEl.innerHTML = golpes.map(g => `<i style="left:${(g.impacto / Math.max(1, original.length - 1) * 100).toFixed(2)}%;background:${g.puntaje >= 80 ? '#38e8a0' : g.puntaje >= 60 ? '#ffb020' : '#ff4d4d'}" title="Golpe ${g.n}"></i>`).join('');
    let i = 0, play = true, vel = 0.5, ultimo = performance.now(), acum = 0, vivo = true, etI = [], etD = [];
    const barra = contenedor.querySelector('input[type=range]'), txtE = contenedor.querySelector('.v3d-err'), txtO = contenedor.querySelector('.v3d-ok');
    const dt = original.length > 1 ? (original[original.length - 1].t - original[0].t) / (original.length - 1) : 1 / 30;
    function Evz(z) { const mapa = { apoyo: 'pies', rodillas: 'piernas', giro: 'tronco', cadera: 'cadera', brazo: 'mano', codo: 'codo', brazoLibre: 'brazoLibre', tronco: 'tronco' }; return Ev.articulacionesZona(mapa[z] || z, mano); }
    function cuadro(k) {
      i = Math.max(0, Math.min(original.length - 1, k));
      const e = errores[i] || { j: [], textos: [] };
      const ver = new Set(); (corregido[i].marcas || []).forEach(z => Evz(z).forEach(j => ver.add(j)));
      ponerFigura(izq.fig, original[i].P, new Set(e.j), new Set()); ponerPaleta(izq, original[i].P);
      ponerFigura(der.fig, corregido[i].P, new Set(), ver); ponerPaleta(der, corregido[i].P);
      const g = golpes.find(g => i >= g.inicio && i <= g.fin + 6);
      etI = ponerMediciones(izq, original, i, g ? g.impacto : null);
      etD = ponerMediciones(der, corregido, i, g ? g.impacto : null);
      for (const E of [izq, der]) {
        E.med.g.visible = verMed;
        const b = pelota && pelota[i]; E.bola.visible = !!b; if (b) E.bola.position.set(b[0], b[1], b[2]);
        E.estela.forEach((m, k2) => { const q = pelota && pelota[i - (k2 + 1) * 2]; m.visible = !!q; if (q) m.position.set(q[0], q[1], q[2]); });
      }
      txtE.textContent = [g && g.info, e.textos.slice(0, 2).join(' · ')].filter(Boolean).join(' — ');
      txtO.textContent = g && cambios[g.n] ? cambios[g.n] : '';
      barra.value = i;
    }
    function tam() { renderer.setSize(lienzo.clientWidth, lienzo.clientHeight, false); }
    function dibujar() {
      const W = lienzo.clientWidth, H = lienzo.clientHeight, vertical = H > W * 1.1;
      const pares = vertical ? [[0, H / 2, W, H / 2], [0, 0, W, H / 2]] : [[0, 0, W / 2, H], [W / 2, 0, W / 2, H]];
      contenedor.querySelector('.v3d').classList.toggle('vertical', vertical);
      ubicar(camI); ubicar(camD);
      [[izq, camI, pares[0]], [der, camD, pares[1]]].forEach(([E, cam, r]) => {
        cam.aspect = r[2] / r[3]; cam.updateProjectionMatrix();
        renderer.setViewport(r[0], r[1], r[2], r[3]); renderer.setScissor(r[0], r[1], r[2], r[3]);
        renderer.render(E.s, cam);
      });
      capaEt.innerHTML = verMed ? etiquetas(etI, camI, pares[0], W, H) + etiquetas(etD, camD, pares[1], W, H) : '';
    }
    function bucle(ahora) {
      if (!vivo) return;
      const d = (ahora - ultimo) / 1000; ultimo = ahora;
      if (play) { acum += d * vel; let paso = false; while (acum >= dt) { acum -= dt; i = i + 1 >= original.length ? 0 : i + 1; paso = true; } if (paso) cuadro(i); }
      dibujar(); requestAnimationFrame(bucle);
    }
    contenedor.addEventListener('click', ev => {
      const b = ev.target.closest('[data-v]'); if (!b || b.tagName === 'SELECT') return;
      const k = b.dataset.v;
      if (k === 'play') { play = !play; b.textContent = play ? '⏸' : '▶'; }
      if (k === 'med') { verMed = !verMed; b.classList.toggle('on', verMed); b.setAttribute('aria-pressed', verMed); cuadro(i); }
      if (k === 'next' || k === 'prev') {
        const lista = k === 'next' ? golpes.filter(g => g.inicio > i + 1) : golpes.filter(g => g.inicio < i - 1).reverse();
        const g = lista[0] || (k === 'next' ? golpes[0] : golpes[golpes.length - 1]);
        if (g) cuadro(Math.max(0, g.inicio - 6));
      }
    });
    contenedor.querySelector('[data-v=vel]').onchange = ev => vel = +ev.target.value;
    contenedor.querySelector('[data-v=cam]').onchange = ev => { [az, el, dist] = VISTAS[ev.target.value]; };
    barra.oninput = () => cuadro(+barra.value);
    /* gestos: arrastrar para girar, pellizcar o rueda para acercar */
    const punteros = new Map(); let ini = null, distIni = 0;
    lienzo.addEventListener('pointerdown', ev => { punteros.set(ev.pointerId, [ev.clientX, ev.clientY]); lienzo.setPointerCapture(ev.pointerId); ini = [ev.clientX, ev.clientY, az, el]; if (punteros.size === 2) { const [a, b] = [...punteros.values()]; distIni = Math.hypot(a[0] - b[0], a[1] - b[1]); } });
    lienzo.addEventListener('pointermove', ev => {
      if (!punteros.has(ev.pointerId)) return; punteros.set(ev.pointerId, [ev.clientX, ev.clientY]);
      if (punteros.size === 2) { const [a, b] = [...punteros.values()]; const d2 = Math.hypot(a[0] - b[0], a[1] - b[1]); if (distIni) { dist = Math.max(1.4, Math.min(9, dist * distIni / d2)); distIni = d2; } return; }
      if (ini) { az = ini[2] - (ev.clientX - ini[0]) * 0.01; el = Math.max(-0.05, Math.min(1.4, ini[3] + (ev.clientY - ini[1]) * 0.006)); }
    });
    const soltar = ev => { punteros.delete(ev.pointerId); if (!punteros.size) ini = null; };
    lienzo.addEventListener('pointerup', soltar); lienzo.addEventListener('pointercancel', soltar);
    lienzo.addEventListener('wheel', ev => { dist = Math.max(1.4, Math.min(9, dist * (ev.deltaY > 0 ? 1.08 : 0.93))); ev.preventDefault(); }, { passive: false });
    const ro = new ResizeObserver(tam); ro.observe(lienzo); tam();
    cuadro(golpes[0] ? Math.max(0, golpes[0].inicio - 6) : 0);
    requestAnimationFrame(bucle);
    return { destruir() { vivo = false; ro.disconnect(); renderer.dispose(); }, ir(k) { cuadro(k); } };
  }
  return { crear };
})();

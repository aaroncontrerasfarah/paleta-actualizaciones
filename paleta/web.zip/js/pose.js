/* Paleta — detección del esqueleto con MediaPipe Pose (en el teléfono, sin internet).
   Graba con la cámara (análisis en vivo) o procesa un video de la galería. */
"use strict";
const Pose = (() => {
  const MODELO_REMOTO = t => `https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_${t}/float16/latest/pose_landmarker_${t}.task`;
  const cache = {};
  let vision = null;

  async function cargar(tipo) {
    tipo = tipo || 'lite';
    if (cache[tipo]) return cache[tipo];
    if (!vision) vision = await import('../vendor/mediapipe/vision_bundle.mjs');
    const fileset = await vision.FilesetResolver.forVisionTasks(new URL('vendor/mediapipe/wasm', location.href).href);
    let ruta = `modelos/pose_landmarker_${tipo}.task`;
    try { const r = await fetch(ruta, { method: 'HEAD' }); if (!r.ok) throw 0; } catch (e) { ruta = MODELO_REMOTO(tipo); }
    const crear = delegate => vision.PoseLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: ruta, delegate },
      runningMode: 'VIDEO', numPoses: 1,
      minPoseDetectionConfidence: 0.5, minPosePresenceConfidence: 0.5, minTrackingConfidence: 0.5
    });
    let lm;
    try { lm = await crear('GPU'); } catch (e) { lm = await crear('CPU'); }
    cache[tipo] = lm;
    return lm;
  }

  /* Convierte un resultado de MediaPipe en un cuadro: esqueleto 3D en metros (Y hacia arriba)
     más el desplazamiento del cuerpo en la imagen, para conservar el trabajo de pies. */
  function crearConversor(ancho, alto) {
    let escala = null, origen = null; const escalas = [];
    return function (res, t) {
      const w = res && res.worldLandmarks && res.worldLandmarks[0], n = res && res.landmarks && res.landmarks[0];
      if (!w || !n) return null;
      const P = w.map(p => [p.x, -p.y, -p.z]); // Y y Z invertidos: sistema diestro con Y hacia arriba
      const px = p => [p.x * ancho, p.y * alto];
      const cadN = [(px(n[23])[0] + px(n[24])[0]) / 2, (px(n[23])[1] + px(n[24])[1]) / 2];
      const homN = [(px(n[11])[0] + px(n[12])[0]) / 2, (px(n[11])[1] + px(n[12])[1]) / 2];
      const torsoPx = Math.hypot(homN[0] - cadN[0], homN[1] - cadN[1]);
      const cadW = [(P[23][0] + P[24][0]) / 2, (P[23][1] + P[24][1]) / 2, (P[23][2] + P[24][2]) / 2];
      const homW = [(P[11][0] + P[12][0]) / 2, (P[11][1] + P[12][1]) / 2, (P[11][2] + P[12][2]) / 2];
      const torsoM = Math.hypot(homW[0] - cadW[0], homW[1] - cadW[1]);
      if (torsoPx > 10) { escalas.push(torsoM / torsoPx); if (escalas.length > 60) escalas.shift(); escala = escalas.slice().sort((a, b) => a - b)[escalas.length >> 1]; }
      if (!origen) origen = cadN;
      const dx = (cadN[0] - origen[0]) * (escala || 0), dy = -(cadN[1] - origen[1]) * (escala || 0);
      const r3 = x => Math.round(x * 1000) / 1000;
      const visible = Math.min(n[27].visibility ?? 1, n[28].visibility ?? 1, n[11].visibility ?? 1, n[12].visibility ?? 1);
      return {
        t,
        P: P.map(p => [r3(p[0] + dx), r3(p[1] + dy), r3(p[2])]),
        n: n.map(p => [Math.round(p.x * 1000) / 1000, Math.round(p.y * 1000) / 1000]),
        vis: Math.round(visible * 100) / 100,
        vista: Bio.vistaCamara(n, ancho, alto)
      };
    };
  }

  /* Dibuja el esqueleto 2D sobre un canvas */
  function dibujar(ctx, n, ancho, alto, opc) {
    const o = Object.assign({ color: '#38e8a0', grosor: 4, rojo: [] }, opc || {});
    if (!n) return;
    const rojo = new Set(o.rojo);
    ctx.lineCap = 'round';
    for (const [a, b] of Bio.HUESOS) {
      if (a < 11 && b < 11) continue;
      ctx.strokeStyle = (rojo.has(a) || rojo.has(b)) ? '#ff4d4d' : o.color; ctx.lineWidth = o.grosor;
      ctx.beginPath(); ctx.moveTo(n[a][0] * ancho, n[a][1] * alto); ctx.lineTo(n[b][0] * ancho, n[b][1] * alto); ctx.stroke();
    }
    for (let j = 0; j < 33; j++) {
      if (j > 0 && j < 11) continue;
      ctx.fillStyle = rojo.has(j) ? '#ff4d4d' : '#fff';
      ctx.beginPath(); ctx.arc(n[j][0] * ancho, n[j][1] * alto, o.grosor * (j === 0 ? 1.6 : 0.9), 0, Math.PI * 2); ctx.fill();
    }
  }

  /* ---------- grabación con la cámara ---------- */
  let flujo = null;
  async function abrirCamara(video, frontal) {
    cerrarCamara();
    flujo = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: frontal ? 'user' : 'environment', width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } } });
    video.srcObject = flujo; video.muted = true; video.playsInline = true;
    await video.play();
    return flujo;
  }
  function cerrarCamara() { if (flujo) { flujo.getTracks().forEach(t => t.stop()); flujo = null; } }

  /* Analiza en vivo: llama onCuadro(cuadro) por cada cuadro con esqueleto. Devuelve un control con detener(). */
  async function enVivo(video, lienzo, opc) {
    const lm = await cargar('lite');
    const ctx = lienzo.getContext('2d');
    let activo = true, grabando = false, t0 = 0, conv = null, ultimo = -1;
    const cuadros = [], miniaturas = [];
    let grabador = null, trozos = [];
    const mini = document.createElement('canvas'); const mctx = mini.getContext('2d');
    function paso() {
      if (!activo) return;
      const ahora = performance.now();
      if (video.readyState >= 2 && ahora > ultimo) {
        ultimo = ahora;
        const W = video.videoWidth, H = video.videoHeight;
        if (lienzo.width !== W) { lienzo.width = W; lienzo.height = H; }
        let res = null; try { res = lm.detectForVideo(video, ahora); } catch (e) { }
        ctx.clearRect(0, 0, W, H);
        const n = res && res.landmarks && res.landmarks[0];
        if (n) dibujar(ctx, n.map(p => [p.x, p.y]), W, H, { grosor: Math.max(3, W / 250) });
        if (!conv) conv = crearConversor(W, H);
        const c = conv(res, (ahora - t0) / 1000);
        opc.onCuadro && opc.onCuadro(c, grabando);
        if (grabando && c) {
          cuadros.push(c);
          if (cuadros.length % 3 === 0) {
            const mw = 320, mh = Math.round(H * mw / W); mini.width = mw; mini.height = mh;
            mctx.drawImage(video, 0, 0, mw, mh);
            miniaturas.push({ t: c.t, img: mini.toDataURL('image/jpeg', 0.6) });
          }
        }
      }
      if (video.requestVideoFrameCallback) video.requestVideoFrameCallback(paso); else requestAnimationFrame(paso);
    }
    paso();
    return {
      empezar() {
        cuadros.length = 0; miniaturas.length = 0; t0 = performance.now(); conv = null; grabando = true;
        try {
          const tipos = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
          const mt = tipos.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
          grabador = new MediaRecorder(video.srcObject, mt ? { mimeType: mt, videoBitsPerSecond: 2500000 } : undefined);
          trozos = []; grabador.ondataavailable = e => e.data && e.data.size && trozos.push(e.data); grabador.start(1000);
        } catch (e) { grabador = null; }
      },
      async terminar() {
        grabando = false;
        let blob = null;
        if (grabador && grabador.state !== 'inactive') {
          await new Promise(r => { grabador.onstop = r; grabador.stop(); });
          blob = new Blob(trozos, { type: grabador.mimeType || 'video/webm' });
        }
        return { cuadros: cuadros.slice(), miniaturas: miniaturas.slice(), video: blob, ancho: video.videoWidth, alto: video.videoHeight };
      },
      detener() { activo = false; grabando = false; }
    };
  }

  /* ---------- video de la galería ---------- */
  async function procesarArchivo(archivo, onProgreso) {
    const lm = await cargar('full').catch(() => cargar('lite'));
    const video = document.createElement('video');
    video.muted = true; video.playsInline = true; video.preload = 'auto';
    video.src = URL.createObjectURL(archivo);
    await new Promise((ok, mal) => { video.onloadedmetadata = ok; video.onerror = () => mal(new Error('No se pudo abrir el video.')); });
    if (!isFinite(video.duration)) { video.currentTime = 1e9; await new Promise(r => video.onseeked = r); }
    const dur = Math.min(video.duration || 0, 120), paso = 1 / 20;
    const W = video.videoWidth, H = video.videoHeight, conv = crearConversor(W, H);
    const cuadros = [], miniaturas = [];
    const mini = document.createElement('canvas'), mctx = mini.getContext('2d');
    let ts = 1;
    for (let t = 0; t < dur; t += paso) {
      video.currentTime = t;
      await new Promise(r => { const f = () => { video.removeEventListener('seeked', f); r(); }; video.addEventListener('seeked', f); });
      let res = null; try { res = lm.detectForVideo(video, ts); } catch (e) { }
      ts += Math.round(paso * 1000);
      const c = conv(res, t);
      if (c) {
        cuadros.push(c);
        if (cuadros.length % 3 === 0) { const mw = 320, mh = Math.round(H * mw / W); mini.width = mw; mini.height = mh; mctx.drawImage(video, 0, 0, mw, mh); miniaturas.push({ t, img: mini.toDataURL('image/jpeg', 0.6) }); }
      }
      onProgreso && onProgreso(t / dur);
    }
    URL.revokeObjectURL(video.src);
    return { cuadros, miniaturas, video: archivo, ancho: W, alto: H };
  }

  return { cargar, abrirCamara, cerrarCamara, enVivo, procesarArchivo, dibujar };
})();

/* Paleta — visión de la pelota y de la paleta, y análisis del timing.
   Detección en cada cuadro (imagen reducida, ~480 px de ancho):
   - Pelota: píxeles del color de la pelota que además se movieron respecto del cuadro anterior; manchas del tamaño esperado.
   - Paleta: píxeles del color de las gomas alrededor de la mano que golpea; orientación por momentos de la mancha.
   Análisis: seguimiento de la pelota, bote, punto más alto, fase en que se golpea (subida, punto alto, bajada),
   ángulo de la cara de la paleta en el impacto y velocidad de salida. Funciona en el navegador y en Node. */
(function (raiz, fabrica) {
  const m = fabrica();
  if (typeof module === 'object' && module.exports) module.exports = m; else raiz.Pel = m;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function hsv(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return [h, mx ? d / mx : 0, mx / 255];
  }
  const COLOR_PELOTA = {
    naranja: (h, s, v) => h >= 8 && h <= 42 && s >= 0.5 && v >= 0.45,
    blanca: (h, s, v) => s <= 0.2 && v >= 0.8
  };
  const COLOR_GOMA = {
    Roja: (h, s, v) => (h <= 14 || h >= 340) && s >= 0.45 && v >= 0.22,
    Rosada: (h, s, v) => h >= 295 && h < 340 && s >= 0.3 && v >= 0.4,
    Verde: (h, s, v) => h >= 75 && h <= 170 && s >= 0.35 && v >= 0.22,
    Azul: (h, s, v) => h >= 190 && h <= 250 && s >= 0.35 && v >= 0.22,
    Morada: (h, s, v) => h > 250 && h < 295 && s >= 0.3 && v >= 0.22,
    Negra: (h, s, v) => v <= 0.2 && s <= 0.6
  };

  /* Componentes conexas de una máscara (vecindad 4) */
  function manchas(mask, w, h, minArea, maxArea) {
    const lab = new Int32Array(w * h), out = [], pila = new Int32Array(w * h);
    let id = 0;
    for (let i = 0; i < w * h; i++) {
      if (!mask[i] || lab[i]) continue;
      id++; let top = 0; pila[top++] = i; lab[i] = id;
      let n = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, x0 = w, x1 = 0, y0 = h, y1 = 0;
      while (top) {
        const p = pila[--top], x = p % w, y = (p / w) | 0;
        n++; sx += x; sy += y; sxx += x * x; syy += y * y; sxy += x * y;
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        if (n > maxArea * 3) continue;
        if (x > 0 && mask[p - 1] && !lab[p - 1]) { lab[p - 1] = id; pila[top++] = p - 1; }
        if (x < w - 1 && mask[p + 1] && !lab[p + 1]) { lab[p + 1] = id; pila[top++] = p + 1; }
        if (y > 0 && mask[p - w] && !lab[p - w]) { lab[p - w] = id; pila[top++] = p - w; }
        if (y < h - 1 && mask[p + w] && !lab[p + w]) { lab[p + w] = id; pila[top++] = p + w; }
      }
      if (n < minArea || n > maxArea) continue;
      const cx = sx / n, cy = sy / n;
      const mu20 = sxx / n - cx * cx, mu02 = syy / n - cy * cy, mu11 = sxy / n - cx * cy;
      const t = Math.sqrt(Math.max(0, (mu20 - mu02) ** 2 + 4 * mu11 * mu11));
      const l1 = (mu20 + mu02 + t) / 2, l2 = Math.max(1e-6, (mu20 + mu02 - t) / 2);
      out.push({ n, cx, cy, x0, x1, y0, y1, ang: 0.5 * Math.atan2(2 * mu11, mu20 - mu02), alargue: Math.sqrt(l1 / l2) });
    }
    return out;
  }

  /* Pelota: color + movimiento. diam: diámetro esperado en píxeles (si se conoce). Devuelve hasta 3 candidatas. */
  function detectarPelota(px, prev, w, h, opc) {
    const o = Object.assign({ color: 'naranja', diam: 0, excluir: null, umbralMov: 22 }, opc || {});
    const es = COLOR_PELOTA[o.color] || COLOR_PELOTA.naranja;
    const mask = new Uint8Array(w * h);
    for (let i = 0, k = 0; i < w * h; i++, k += 4) {
      const r = px[k], g = px[k + 1], b = px[k + 2];
      if (prev) { const d = Math.abs(r - prev[k]) + Math.abs(g - prev[k + 1]) + Math.abs(b - prev[k + 2]); if (d < o.umbralMov * 3) continue; }
      const [hh, s, v] = hsv(r, g, b);
      if (es(hh, s, v)) mask[i] = 1;
    }
    const d = o.diam || Math.max(4, w / 60);
    const minA = Math.max(2, d * d * 0.12), maxA = d * d * 4.5;
    let ms = manchas(mask, w, h, minA, maxA).filter(m => m.alargue < 5);
    if (o.excluir) ms = ms.filter(m => !o.excluir(m.cx, m.cy));
    const esperado = Math.PI * d * d / 4;
    ms.forEach(m => { m.puntaje = 1 / (1 + Math.abs(Math.log(m.n / esperado))) / (1 + (m.alargue - 1) * 0.3); });
    return ms.sort((a, b) => b.puntaje - a.puntaje).slice(0, 3).map(m => [+(m.cx / w).toFixed(4), +(m.cy / h).toFixed(4), m.n]);
  }

  /* Paleta: busca las caras de color de las gomas alrededor de un punto (la mano), en un radio dado (px). */
  function detectarPaleta(px, w, h, centro, radio, colores) {
    const cols = (colores && colores.length ? colores : ['Roja', 'Negra']).filter(c => COLOR_GOMA[c]);
    const x0 = Math.max(0, Math.floor(centro[0] - radio)), x1 = Math.min(w - 1, Math.ceil(centro[0] + radio));
    const y0 = Math.max(0, Math.floor(centro[1] - radio)), y1 = Math.min(h - 1, Math.ceil(centro[1] + radio));
    const ww = x1 - x0 + 1, hh = y1 - y0 + 1; if (ww < 4 || hh < 4) return null;
    let mejor = null;
    for (const c of cols) {
      const es = COLOR_GOMA[c], mask = new Uint8Array(ww * hh);
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        if ((x - centro[0]) ** 2 + (y - centro[1]) ** 2 > radio * radio) continue;
        const k = (y * w + x) * 4, [hu, s, v] = hsv(px[k], px[k + 1], px[k + 2]);
        if (es(hu, s, v)) mask[(y - y0) * ww + (x - x0)] = 1;
      }
      const ms = manchas(mask, ww, hh, Math.max(4, radio * radio * 0.02), radio * radio * 2.5);
      for (const m of ms) {
        const dist = Math.hypot(m.cx + x0 - centro[0], m.cy + y0 - centro[1]) / radio;
        const p = m.n * (1.2 - dist) * (c === 'Negra' ? 0.7 : 1);
        if (!mejor || p > mejor.p) mejor = { p, m, c };
      }
    }
    if (!mejor) return null;
    const m = mejor.m;
    return { x: +((m.cx + x0) / w).toFixed(4), y: +((m.cy + y0) / h).toFixed(4), a: +(m.ang * 180 / Math.PI).toFixed(1), r: +(1 / m.alargue).toFixed(3), cara: mejor.c, n: m.n };
  }

  /* ---------- seguimiento y análisis ---------- */
  /* cuadros: [{t, b:[[x,y,area]...], pl, n:[[x,y]...], esc (m por px de la imagen original), W, H}] */
  function rastrear(cuadros, W, H) {
    const pista = new Array(cuadros.length).fill(null);
    let ult = [], perdidos = 0;
    const gate = i => { const e = cuadros[i].esc || 0.004; return 0.9 / e; }; // ~0,9 m por cuadro como máximo
    for (let i = 0; i < cuadros.length; i++) {
      const cands = (cuadros[i].b || []).map(b => [b[0] * W, b[1] * H]);
      if (!cands.length) { if (++perdidos > 5) ult = []; continue; }
      let elegido = null;
      if (ult.length >= 2) {
        const [a, b] = ult.slice(-2), dt1 = cuadros[b.i].t - cuadros[a.i].t || 1 / 30, dt2 = cuadros[i].t - cuadros[b.i].t || 1 / 30;
        const pred = [b.p[0] + (b.p[0] - a.p[0]) / dt1 * dt2, b.p[1] + (b.p[1] - a.p[1]) / dt1 * dt2];
        let mejor = Infinity; for (const c of cands) { const d = Math.hypot(c[0] - pred[0], c[1] - pred[1]); if (d < mejor) { mejor = d; elegido = c; } }
        if (mejor > gate(i) * Math.max(1, perdidos + 1)) elegido = null;
      } else if (ult.length === 1) {
        const b = ult[0]; let mejor = Infinity; for (const c of cands) { const d = Math.hypot(c[0] - b.p[0], c[1] - b.p[1]); if (d < mejor) { mejor = d; elegido = c; } }
        if (mejor > gate(i) * (perdidos + 1)) { elegido = cands[0]; ult = []; }
      } else elegido = cands[0];
      if (elegido) { pista[i] = elegido; ult.push({ i, p: elegido }); if (ult.length > 3) ult.shift(); perdidos = 0; }
      else if (++perdidos > 5) ult = [];
    }
    /* rellena huecos cortos */
    for (let i = 1; i < pista.length - 1; i++) if (!pista[i]) {
      let a = i - 1, b = i + 1; while (b < pista.length && !pista[b] && b - a <= 3) b++;
      if (pista[a] && pista[b] && b - a <= 3) for (let k = a + 1; k < b; k++) { const f = (k - a) / (b - a); pista[k] = [pista[a][0] + (pista[b][0] - pista[a][0]) * f, pista[a][1] + (pista[b][1] - pista[a][1]) * f]; }
    }
    return pista;
  }

  /* Ajuste de parábola y = a t² + b t + c por mínimos cuadrados */
  function parabola(ts, ys) {
    const n = ts.length; if (n < 3) return null;
    let s0 = n, s1 = 0, s2 = 0, s3 = 0, s4 = 0, y0 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < n; i++) { const t = ts[i], y = ys[i]; s1 += t; s2 += t * t; s3 += t ** 3; s4 += t ** 4; y0 += y; y1 += t * y; y2 += t * t * y; }
    const M = [[s4, s3, s2], [s3, s2, s1], [s2, s1, s0]], V = [y2, y1, y0];
    const det = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    const D = det(M); if (Math.abs(D) < 1e-12) return null;
    const col = (k) => M.map((f, i) => f.map((x, j) => j === k ? V[i] : x));
    return { a: det(col(0)) / D, b: det(col(1)) / D, c: det(col(2)) / D };
  }

  /* Lado hacia el que mira el jugador en la imagen (+1 derecha, -1 izquierda) */
  function haciaMesa(n) {
    if (!n) return 1;
    const orejas = (n[7][0] + n[8][0]) / 2;
    return n[0][0] >= orejas ? 1 : -1;
  }

  /* Analiza la pelota y la paleta en un golpe ya detectado (g: {inicio, impacto, fin}) */
  function analizarGolpe(cuadros, pista, g, W, H, opc) {
    const o = opc || {};
    const tI = cuadros[g.impacto].t, res = { pelota: false };
    const esc = cuadros[g.impacto].esc || 0.004;
    const iD = o.mano === 'Z' ? 15 : 16, idx = o.mano === 'Z' ? 19 : 20;
    const manoPx = i => { const n = cuadros[i].n; if (!n) return null; const pl = cuadros[i].pl; return pl ? [pl.x * W, pl.y * H] : [(n[iD][0] * 0.4 + n[idx][0] * 0.6) * W, (n[iD][1] * 0.4 + n[idx][1] * 0.6) * H]; };
    /* contacto: pelota más cercana a la paleta/mano alrededor del impacto del brazo */
    let iC = -1, dMin = Infinity;
    for (let i = Math.max(0, g.impacto - 9); i <= Math.min(cuadros.length - 1, g.impacto + 6); i++) {
      if (!pista[i]) continue; const m = manoPx(i); if (!m) continue;
      const d = Math.hypot(pista[i][0] - m[0], pista[i][1] - m[1]) * esc;
      if (d < dMin) { dMin = d; iC = i; }
    }
    const dir = haciaMesa(cuadros[g.impacto].n);
    /* paleta en el impacto: promedio de los cuadros vecinos con paleta detectada */
    const iRef = iC >= 0 && dMin < 0.5 ? iC : g.impacto;
    const pls = []; for (let i = Math.max(0, iRef - 2); i <= Math.min(cuadros.length - 1, iRef + 2); i++) if (cuadros[i].pl) pls.push(cuadros[i].pl);
    if (pls.length) {
      /* eje mayor de la mancha, apuntando hacia arriba en la imagen; ángulo respecto de la vertical,
         positivo si el borde superior se inclina hacia la mesa (cara cerrada) */
      let ux = 0, uy = 0;
      for (const p of pls) { const a = p.a * Math.PI / 180; let x = Math.cos(a), y = Math.sin(a); if (y > 0) { x = -x; y = -y; } ux += x; uy += y; }
      res.paleta = +(Math.atan2(ux * dir, -uy) * 180 / Math.PI).toFixed(1);
      res.paletaCara = pls[0].cara; res.paletaAspecto = pls[0].r;
    }
    if (iC < 0 || dMin > 0.5) return res;
    res.pelota = true; res.tContacto = cuadros[iC].t; res.iContacto = iC;
    /* llegada: hasta 0,9 s antes del contacto */
    const ini = (() => { let k = iC; while (k > 0 && cuadros[iC].t - cuadros[k - 1].t < 0.9 && pista[k - 1]) k--; return k; })();
    const seg = []; for (let i = ini; i < iC; i++) if (pista[i]) seg.push({ i, t: cuadros[i].t, x: pista[i][0], y: pista[i][1] });
    /* bote: la pelota bajaba (y crece) y empieza a subir; se toma el último antes del contacto */
    let bote = null;
    for (let k = 1; k < seg.length - 1; k++) {
      const a = seg[k - 1], b = seg[k], c = seg[k + 1];
      if (b.y > a.y && b.y >= c.y && (b.y - Math.min(a.y, c.y)) * esc > 0.006) bote = b;
    }
    if (bote) {
      res.tBote = bote.t;
      const tras = seg.filter(s => s.t >= bote.t);
      tras.push({ t: cuadros[iC].t, y: pista[iC][1] });
      let tApex = null;
      const vertice = tras.reduce((m, s) => s.y < m.y ? s : m, tras[0]);
      if (vertice !== tras[0] && vertice !== tras[tras.length - 1]) tApex = vertice.t;
      else { const p = parabola(tras.map(s => s.t - bote.t), tras.map(s => s.y)); if (p && p.a > 0) { const tv = -p.b / (2 * p.a); if (tv > 0.02 && tv < 1.2) tApex = bote.t + tv; } }
      if (tApex && tApex > bote.t) {
        res.tApex = tApex;
        res.fase = +((cuadros[iC].t - bote.t) / (tApex - bote.t)).toFixed(2);
        res.alturaBote = +((bote.y - vertice.y) * esc).toFixed(2);
      }
    }
    /* salida: velocidad de la pelota después del contacto (proyección en la imagen: es un mínimo) */
    const sal = []; for (let i = iC + 1; i < cuadros.length && cuadros[i].t - cuadros[iC].t <= 0.2; i++) if (pista[i]) sal.push({ t: cuadros[i].t, x: pista[i][0], y: pista[i][1] });
    if (sal.length >= 2) {
      const a = sal[0], b = sal[sal.length - 1], dt = b.t - a.t;
      if (dt > 0.02) {
        const vx = (b.x - a.x) / dt, vy = (b.y - a.y) / dt;
        res.velSalida = +(Math.hypot(vx, vy) * esc * 3.6).toFixed(0); // km/h
        res.anguloSalida = +(Math.atan2(-vy, Math.abs(vx)) * 180 / Math.PI).toFixed(0);
      }
    }
    return res;
  }

  function nombreFase(f) { if (f === undefined || f === null) return ''; return f < 0.75 ? 'en la subida' : f <= 1.2 ? 'en el punto más alto' : f <= 1.7 ? 'en la bajada temprana' : 'en la bajada'; }
  function nombrePaleta(a) { if (a === undefined || a === null) return ''; const v = Math.abs(Math.round(a)); return a > 5 ? `cerrada ${v}°` : a < -5 ? `abierta ${v}°` : 'vertical'; }

  return { hsv, COLOR_PELOTA, COLOR_GOMA, manchas, detectarPelota, detectarPaleta, rastrear, parabola, analizarGolpe, haciaMesa, nombreFase, nombrePaleta };
});

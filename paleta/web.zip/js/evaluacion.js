/* Paleta — evaluación: ajusta las referencias al jugador, evalúa cada golpe, arma el diagnóstico,
   las metas de la versión corregida, los consejos de material y toma, y las jugadas tácticas. */
(function (raiz, fabrica) {
  const m = fabrica(raiz.K || (typeof require === 'function' ? require('./conocimiento.js') : null), raiz.Bio || (typeof require === 'function' ? require('./biomecanica.js') : null));
  if (typeof module === 'object' && module.exports) module.exports = m; else raiz.Ev = m;
})(typeof self !== 'undefined' ? self : this, function (K, Bio) {
  'use strict';

  const PESOS = { rodillas: 1.2, apoyo: 1.0, transferencia: 0.9, giro: 1.2, cadera: 0.7, codo: 1.0, impacto: 1.2, angulo: 1.1, amplitud: 0.9, terminacion: 0.9, muneca: 0.8, brazoLibre: 0.7, cabeza: 0.8, recuperacion: 0.8, lanzamiento: 1.5 };
  const CORREGIBLES = ['rodillas', 'apoyo', 'transferencia', 'cadera', 'giro', 'codo', 'impacto', 'angulo', 'amplitud', 'terminacion', 'brazoLibre', 'cabeza'];

  const golpe = id => K.GOLPES.find(g => g.id === id) || K.GOLPES[0];
  const estilo = id => K.ESTILOS.find(e => e.id === id);
  const num = x => typeof x === 'number' && isFinite(x);
  const r1 = x => Math.round(x * 10) / 10;

  function edadDe(p) { return +p.edad || 0; }
  function nivelIdx(p) { const i = K.NIVELES.indexOf(p.nivel); return i < 0 ? 1 : i; }
  function gomaDe(p, lado) { return (lado === 'reves' ? p.gomaR : p.gomaD) || {}; }
  const esPips = t => /pips largos|antitopspin/i.test(t || '');

  /* Referencias ajustadas a la persona y al lado del golpe */
  function referencias(base, perfil, lado, tipo) {
    const p = perfil || {};
    const ref = {};
    for (const k in base) ref[k] = base[k].slice();
    const notas = [];
    const ensanchar = (k, f) => { if (!ref[k]) return; const [a, b] = ref[k], c = (a + b) / 2, h = (b - a) / 2 * f; ref[k] = [c - h, c + h]; };
    const mover = (k, d) => { if (ref[k]) ref[k] = [ref[k][0] + d, ref[k][1] + d]; };
    const escalar = (k, f) => { if (ref[k]) ref[k] = [ref[k][0] * f, ref[k][1] * f]; };
    /* nivel: más tolerancia al principiante, más exigencia al competidor */
    const f = [1.2, 1.0, 0.93, 0.88][nivelIdx(p)];
    for (const k in ref) if (k !== 'lanzamiento') ensanchar(k, f);
    /* edad y físico */
    const edad = edadDe(p);
    if (edad >= 55) { if (ref.rodillas) ref.rodillas[1] += 8; if (ref.giro) ref.giro[0] = Math.max(0, ref.giro[0] - 8); if (ref.recuperacion) ref.recuperacion[1] *= 1.2; notas.push('Rangos de piernas, giro y recuperación ajustados a la edad.'); }
    if (edad && edad <= 12) { escalar('amplitud', 0.9); notas.push('Recorridos ajustados a un jugador infantil.'); }
    const est = +p.estatura || 0;
    if (est >= 185) { mover('rodillas', -5); notas.push('Por la estatura se espera algo más de flexión de rodillas.'); }
    if (est && est <= 150) mover('rodillas', 4);
    if (p.contextura === 'Robusta') { if (ref.recuperacion) ref.recuperacion[1] *= 1.15; if (ref.apoyo) ref.apoyo[0] -= 0.08; }
    /* estilo */
    const es = estilo(p.estilo);
    if (es && es.ajuste) {
      const a = es.ajuste;
      if (a.amplitud) escalar('amplitud', a.amplitud);
      if (a.recuperacion && ref.recuperacion) ref.recuperacion[1] *= a.recuperacion;
      if (a.impacto) mover('impacto', a.impacto);
      if (a.rodillas) mover('rodillas', a.rodillas);
    }
    /* goma de ese lado */
    const goma = gomaDe(p, lado).tipo || '';
    if (/pegajosa|híbrida/i.test(goma) && (tipo === 'topspin' || tipo === 'drive')) {
      mover('angulo', -6); if (ref.giro) ref.giro[0] += 6; if (ref.cadera) ref.cadera[0] += 4;
      notas.push('Con goma pegajosa el golpe va más hacia adelante y exige más giro de tronco y cadera.');
    }
    if (/pips cortos/i.test(goma)) { mover('angulo', -8); escalar('amplitud', 0.88); notas.push('Con pips cortos se esperan golpes más planos y cortos.'); }
    if (esPips(goma)) {
      if (tipo === 'topspin') { delete ref.angulo; delete ref.amplitud; delete ref.terminacion; notas.push('Con pips largos o anti en este lado, el topspin no es el golpe habitual: se evalúan postura y equilibrio, no el recorrido.'); }
      if (ref.muneca) ref.muneca[1] += 15;
    }
    /* lapicero tradicional: el revés se bloquea con la misma cara, con otra mecánica */
    if (p.estilo === 'lapicero_tradicional' && lado === 'reves') { ensanchar('codo', 1.4); if (ref.muneca) ref.muneca[1] += 25; delete ref.giro; }
    return { ref, notas };
  }

  /* Evalúa una medida contra su rango */
  function evaluarValor(v, rango) {
    if (!num(v) || !rango) return null;
    const [a, b] = rango, ancho = Math.max(1e-6, b - a);
    if (v < a) return { dir: 'bajo', dev: (a - v) / ancho, puntaje: Math.max(0, 100 - (a - v) / ancho * 120) };
    if (v > b) return { dir: 'alto', dev: (v - b) / ancho, puntaje: Math.max(0, 100 - (v - b) / ancho * 120) };
    return { dir: 'ok', dev: 0, puntaje: 100 };
  }

  /* Diagnóstico completo de una sesión */
  function diagnosticar(cuadros, perfil, golpeId, opciones) {
    const p = perfil || {}, mano = p.mano || 'D', def = golpe(golpeId);
    const det = Bio.detectarGolpes(cuadros, mano, opciones);
    const medidas = det.map(g => Bio.medirGolpe(cuadros, g, mano));
    const golpes = det.map((g, i) => {
      const m = medidas[i];
      const base = def.libre ? K.refPorTipo(m.tipo, m.lado) : def.ref;
      const { ref, notas } = referencias(base, p, def.libre ? m.lado : (def.lado === 'ambos' ? m.lado : def.lado), m.tipo);
      const ev = {}; let suma = 0, peso = 0;
      for (const k in ref) {
        const e = evaluarValor(m[k], ref[k]); if (!e) continue;
        ev[k] = e; suma += e.puntaje * (PESOS[k] || 1); peso += PESOS[k] || 1;
      }
      const coincide = def.libre || def.saque || ((def.lado === 'ambos' || def.lado === m.lado) && def.tipos.includes(m.tipo));
      const metas = {};
      for (const k of CORREGIBLES) {
        const e = ev[k]; if (!e || e.dir === 'ok' || !ref[k]) continue;
        const [a, b] = ref[k], dentro = (b - a) * 0.2;
        metas[k] = e.dir === 'bajo' ? a + dentro : b - dentro;
      }
      return { n: i + 1, golpe: g, medidas: m, ref, ev, notas, puntaje: peso ? suma / peso : 0, coincide, metas };
    });

    /* fallas repetidas en la sesión */
    const validos = golpes.filter(g => g.coincide);
    const usados = validos.length >= Math.max(2, golpes.length * 0.3) ? validos : golpes;
    const fallas = [];
    const claves = new Set(); usados.forEach(g => Object.keys(g.ev).forEach(k => claves.add(k)));
    for (const k of claves) {
      for (const dir of ['bajo', 'alto']) {
        const malos = usados.filter(g => g.ev[k] && g.ev[k].dir === dir);
        if (!malos.length) continue;
        const frec = malos.length / usados.length;
        if (frec < 0.34) continue;
        const info = (K.FALLAS[k] || {})[dir]; if (!info) continue;
        const devs = malos.map(g => g.ev[k].dev).sort((a, b) => a - b);
        const dev = devs[Math.floor(devs.length / 2)];
        const valores = malos.map(g => g.medidas[k]);
        const rango = malos[0].ref[k];
        fallas.push(Object.assign({ metrica: k, dir, frecuencia: frec, dev, golpes: malos.map(g => g.n),
          valor: Bio.media(valores), rango, prioridad: frec * (1 + Math.min(2, dev)) * (PESOS[k] || 1),
          gravedad: dev > 0.6 ? 'alta' : dev > 0.25 ? 'media' : 'leve', zona: (K.METRICAS[k] || {}).zona }, info));
      }
    }
    const reg = Bio.regularidad(usados.map(g => g.medidas));
    if (reg && (reg.codo > 18 || reg.alturaImpacto > 0.22 || reg.amplitud > 0.35)) {
      fallas.push(Object.assign({ metrica: 'regularidad', dir: 'alto', frecuencia: 1, dev: 0.4, golpes: [], valor: reg.codo, rango: null, prioridad: 1.1, gravedad: 'media', zona: 'mano' }, K.FALLAS.regularidad));
    }
    fallas.sort((a, b) => b.prioridad - a.prioridad);

    /* puntajes por grupo */
    const grupos = {};
    for (const g of usados) for (const k in g.ev) {
      const gr = (K.METRICAS[k] || {}).grupo || 'Otros';
      (grupos[gr] = grupos[gr] || []).push(g.ev[k].puntaje);
    }
    const puntajes = Object.fromEntries(Object.entries(grupos).map(([k, a]) => [k, Math.round(Bio.media(a))]));
    if (reg) puntajes.Regularidad = Math.round(Math.max(0, 100 - reg.codo * 1.6 - reg.alturaImpacto * 120 - reg.amplitud * 60));
    const puntaje = usados.length ? Math.round(Bio.media(usados.map(g => g.puntaje)) * (reg ? 0.85 + 0.15 * (puntajes.Regularidad / 100) : 1)) : 0;

    /* desplazamiento: cuánto se mueve la cadera a lo largo de la mesa */
    let desplazamiento = null;
    if (cuadros.length > 5) {
      const xs = cuadros.map(c => (c.P[23][0] + c.P[24][0]) / 2);
      desplazamiento = { rango: Math.max(...xs) - Math.min(...xs) };
    }
    const tipos = {}; golpes.forEach(g => { const k = g.medidas.lado + ' · ' + K.NOMBRE_TIPO[g.medidas.tipo]; tipos[k] = (tipos[k] || 0) + 1; });
    const mejor = usados.slice().sort((a, b) => b.puntaje - a.puntaje)[0];
    const peor = usados.slice().sort((a, b) => a.puntaje - b.puntaje)[0];
    const promedios = {};
    for (const k of Object.keys(K.METRICAS)) { const a = usados.map(g => g.medidas[k]).filter(num); if (a.length) promedios[k] = r1(Bio.media(a) * (k === 'recuperacion' ? 10 : 1)) / (k === 'recuperacion' ? 10 : 1); }
    const notas = Array.from(new Set(golpes.flatMap(g => g.notas)));
    return { golpeId: def.id, golpeNombre: def.nombre, golpes, usados: usados.length, distintos: golpes.length - validos.length, fallas, puntajes, puntaje, regularidad: reg, desplazamiento, tipos, mejor: mejor && mejor.n, peor: peor && peor.n, promedios, notas, duracion: cuadros.length ? cuadros[cuadros.length - 1].t - cuadros[0].t : 0 };
  }

  /* Correcciones para la animación del movimiento correcto */
  function correcciones(diag) {
    return diag.golpes.map(g => ({ golpe: g.golpe, medidas: g.medidas, metas: g.metas }));
  }

  /* Marcas de error por cuadro para la animación (índices de articulaciones) */
  function articulacionesZona(zona, mano) {
    const L = Bio.lados(mano), J = Bio.J;
    return (K.ZONAS[zona] || []).map(n => {
      if (n.startsWith('D:')) return { codo: L.c, hombro: L.h, muneca: L.m }[n.slice(2)];
      if (n.startsWith('L:')) return { codo: L.cl, hombro: L.hl, muneca: L.ml }[n.slice(2)];
      return J[n];
    }).filter(x => x !== undefined);
  }
  function erroresPorCuadro(diag, total, mano) {
    const marcas = new Array(total).fill(null).map(() => ({ j: new Set(), textos: [] }));
    for (const g of diag.golpes) {
      const malos = Object.entries(g.ev).filter(([, e]) => e.dir !== 'ok' && e.dev > 0.08);
      for (let i = g.golpe.inicio; i <= g.golpe.fin && i < total; i++) {
        for (const [k, e] of malos) {
          articulacionesZona((K.METRICAS[k] || {}).zona, mano).forEach(j => marcas[i].j.add(j));
          const t = ((K.FALLAS[k] || {})[e.dir] || {}).titulo; if (t && !marcas[i].textos.includes(t)) marcas[i].textos.push(t);
        }
      }
    }
    return marcas.map(m => ({ j: Array.from(m.j), textos: m.textos }));
  }

  /* Consejos en vivo durante la grabación */
  function consejoEnVivo(med, golpeId) {
    const def = golpe(golpeId);
    if (med.rodillas > 168 && !def.saque) return 'Flexiona las rodillas';
    if (med.apoyo < 0.95) return 'Separa más los pies';
    if (med.brazoLibre < -0.05 && def.lado !== 'reves') return 'Sube el brazo libre';
    return '';
  }

  /* ---------- material ---------- */
  function asesorMaterial(p) {
    const out = [], niv = nivelIdx(p), edad = edadDe(p);
    const m = p.madero || {}, gd = p.gomaD || {}, gr = p.gomaR || {};
    const ad = (nivel, titulo, texto) => out.push({ nivel, titulo, texto });
    const rapido = /OFF\+|OFF \(/.test(m.velocidad || '') || /Carbono exterior|ALC.*exterior/.test(m.composicion || '');
    if (niv === 0 && rapido) ad('alerta', 'Madero demasiado rápido para el nivel', 'Un madero ofensivo o de carbono exterior castiga los errores de técnica. Para aprender conviene un ALL u OFF- de 5 capas de madera: más control y mejor sensación.');
    const gruesa = s => /2,1|máx|2,0/.test(s || '');
    if (niv === 0 && (gruesa(gd.esponja) || gruesa(gr.esponja))) ad('alerta', 'Esponja muy gruesa', 'Con menos de un año de juego conviene esponja de 1,5 a 1,8 mm: la pelota sale más lenta y se controla mejor.');
    if (niv <= 1 && (/Dura|Muy dura/.test(gd.dureza || '') || /Dura|Muy dura/.test(gr.dureza || ''))) ad('sugerencia', 'Gomas duras', 'Una goma dura necesita golpes muy rápidos para "entrar" en la esponja. Una goma media o blanda ayuda a sentir el efecto mientras se consolida la técnica.');
    for (const [lado, g] of [['derecho', gd], ['revés', gr]]) {
      const meses = +g.meses || 0, ses = +p.sesiones || 0;
      if (meses >= 6 && ses >= 3) ad('alerta', `Goma del ${lado} gastada`, `Con ${ses} sesiones por semana una goma lisa pierde agarre en 3 a 6 meses. Esta tiene ${meses} meses: probablemente ya no da el efecto que debería.`);
      else if (meses >= 10) ad('sugerencia', `Revisa la goma del ${lado}`, `Tiene ${meses} meses. Si la superficie se ve opaca o la pelota "resbala", conviene cambiarla.`);
    }
    if (/pegajosa/i.test(gd.tipo || '') && niv === 0) ad('sugerencia', 'Goma china pegajosa al derecho', 'Es exigente: necesita mucho giro de cuerpo y piernas. Si recién comienzas, una goma lisa con tensor de dureza media es más amable.');
    if (/defensor/.test(p.estilo || '') && rapido) ad('alerta', 'Madero rápido para un defensor', 'Para cortar lejos de la mesa conviene un madero DEF o ALL, más grande y lento, que dé tiempo y control al corte.');
    if (p.estilo === 'atacante_media' && /DEF|ALL/.test(m.velocidad || '')) ad('sugerencia', 'Madero lento para media distancia', 'Lejos de la mesa un madero OFF- u OFF ayuda a que el topspin llegue profundo sin forzar el brazo.');
    if (p.estilo === 'pips_largos' && !esPips(gr.tipo) && !esPips(gd.tipo)) ad('sugerencia', 'Estilo de pips largos sin goma de pips', 'El perfil indica estilo de pips largos, pero ninguna goma registrada es de pips largos o antitopspin.');
    if (esPips(gr.tipo) && /2,0|2,1|máx/.test(gr.esponja || '')) ad('sugerencia', 'Pips largos con esponja gruesa', 'Para bloquear y cortar con pips largos suele funcionar mejor sin esponja (OX) o con 0,5 a 1,0 mm: el efecto invertido es mayor.');
    if (edad && edad <= 12) ad('sugerencia', 'Material para jugador infantil', 'Conviene un madero liviano (bajo 80 g) y gomas blandas de 1,5 a 1,8 mm. Un mango más delgado ayuda a una mano pequeña.');
    if (edad >= 60 && (gruesa(gd.esponja) || /Muy dura/.test(gd.dureza || ''))) ad('sugerencia', 'Cuidar el brazo', 'Una goma más blanda y liviana reduce el esfuerzo del hombro y el codo sin perder efecto.');
    if (+m.peso && +m.peso + 2 * 45 > 195) ad('sugerencia', 'Paleta pesada', 'Con el madero y dos gomas la paleta supera los 190 g, lo que puede cansar el brazo en entrenamientos largos.');
    if (gd.color && gr.color && gd.color === gr.color) ad('alerta', 'Gomas del mismo color', 'El reglamento exige que una cara sea negra y la otra de un color brillante distinto (roja, rosada, verde, azul o morada). Con ambas del mismo color la paleta no es reglamentaria.');
    else if (gd.color && gr.color && gd.color !== 'Negra' && gr.color !== 'Negra') ad('alerta', 'Ninguna goma es negra', 'El reglamento exige que una de las dos caras sea negra.');
    if (!out.length) ad('ok', 'Material acorde', 'El madero y las gomas registrados son coherentes con el nivel y el estilo de juego.');
    return out;
  }

  /* ---------- toma ---------- */
  function asesorToma(p) {
    const t = p.toma || '', r = p.respuestasToma || {}, out = [];
    const ad = (nivel, titulo, texto) => out.push({ nivel, titulo, texto });
    if (+r.presion >= 8) ad('alerta', 'Aprietas demasiado la paleta', 'Una toma muy apretada bloquea la muñeca y el antebrazo, quita sensibilidad y velocidad. Aprieta lo justo, como a 3 o 4 de 10, y solo aumenta la presión en el instante del impacto.');
    if (+r.presion && +r.presion <= 2) ad('sugerencia', 'Toma muy suelta', 'Si la paleta se mueve en la mano al golpear, pierdes precisión. Sujeta con firmeza el pulgar y el índice.');
    if (/centro/.test(r.indice || '')) ad('alerta', 'Índice en el centro de la goma', 'Con el índice en el centro el revés queda limitado y la paleta se inclina. Lleva el índice al borde de la goma, casi paralelo al borde inferior.');
    if (/Muy arriba/.test(r.pulgar || '')) ad('sugerencia', 'Pulgar demasiado arriba', 'Con el pulgar muy arriba sobre la goma, el derecho se vuelve rígido. Bájalo y relájalo junto al mango.');
    if (/bastante/.test(r.cambia || '')) ad('sugerencia', 'Cambias mucho la toma', 'Cambiar la toma entre derecho y revés da tiempo de reacción en intercambios rápidos. Busca una toma neutra que sirva para los dos golpes.');
    if (/pegada/.test(r.espacio || '')) ad('sugerencia', 'Palma pegada al mango', 'Deja un pequeño espacio entre la palma y el mango: la muñeca se mueve más libre.');
    if (/sh_derecho/.test(t)) ad('info', 'Toma cargada al derecho', 'Favorece el derecho pero cierra el revés y dificulta el push y el bloqueo de revés. Revisa el revés en los videos.');
    if (/sh_reves/.test(t)) ad('info', 'Toma cargada al revés', 'Favorece el revés y el flick, pero el derecho tiende a salir abierto. Revisa que la paleta esté cerrada en el topspin de derecho.');
    if (/seemiller/.test(t)) ad('info', 'Toma Seemiller', 'Toma poco común: se bloquea con la misma cara en ambos lados. Muchos jugadores la combinan con pips largos o anti en la otra cara para girar la paleta.');
    if (/pen_/.test(t)) ad('info', 'Toma de lapicero', 'Los tres dedos de atrás deben quedar relajados y apoyados (o doblados en la japonesa) para que la muñeca tenga juego en el derecho y en el revés.');
    if (/Sí, seguido/.test(r.dolor || '')) ad('alerta', 'Molestias frecuentes', 'Las molestias repetidas en muñeca, codo u hombro pueden venir de la toma, del peso de la paleta o de golpear solo con el brazo. Conviene consultarlo con un profesional de la salud y revisarlo con el entrenador.');
    if (!out.length) ad('ok', 'Toma sin observaciones', 'Las respuestas no muestran problemas en la toma.');
    return out;
  }

  /* ---------- táctica ---------- */
  function jugadasPara(perfil, rivalId, diagReciente) {
    const est = perfil.estilo || 'allround';
    let lista = K.JUGADAS.filter(j => j.estilos.includes(est) && (!rivalId || j.contra.includes(rivalId)));
    if (!lista.length) lista = K.JUGADAS.filter(j => !rivalId || j.contra.includes(rivalId));
    const debil = new Set((diagReciente || []).map(x => x));
    return lista.map(j => {
      const aviso = [];
      if (debil.has('reves') && /revés|banana|flick/i.test(j.pasos.join(' '))) aviso.push('Esta jugada usa el revés, que en los últimos videos todavía muestra fallas: entrénala primero en multibola.');
      if (debil.has('piernas') && /desplaz|pivot|lejos|media distancia/i.test(j.objetivo + j.pasos.join(' '))) aviso.push('Exige buen trabajo de piernas.');
      return Object.assign({}, j, { aviso });
    });
  }

  /* Plan sugerido de golpes para practicar según el estilo */
  function golpesSugeridos(perfil) {
    const e = estilo(perfil.estilo) || estilo('allround');
    return e.golpesClave.map(golpe);
  }

  return { referencias, evaluarValor, diagnosticar, correcciones, erroresPorCuadro, articulacionesZona, consejoEnVivo, asesorMaterial, asesorToma, jugadasPara, golpesSugeridos, golpe, PESOS };
});

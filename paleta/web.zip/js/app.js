/* Paleta — interfaz: modo entrenador (varios alumnos) y modo alumno (su propio perfil),
   grabación y análisis, informe con animación 3D, material, toma y táctica. */
"use strict";
const $ = (s, r) => (r || document).querySelector(s);
const e = Informe.e;
let V = { vista: 'inicio', arg: null, tab: 'datos', rival: '' };
let vista3d = null, camara = null;

function toast(t) { const d = $('#toast'); d.textContent = t; d.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => d.hidden = true, 3200); }
window.toast = toast;

/* ---------- navegación ---------- */
function ir(vista, arg, extra) {
  if (vista3d) { vista3d.destruir(); vista3d = null; }
  V = Object.assign({}, V, { vista, arg: arg ?? null }, extra || {});
  pintar(); window.scrollTo(0, 0);
}
function pintar() {
  const c = Datos.cfg();
  if (!c.modo) return pintarBienvenida();
  const nav = $('#nav'); nav.hidden = false;
  nav.innerHTML = [['inicio', '🏓', 'Inicio'], c.modo === 'entrenador' ? ['jugadores', '👥', 'Alumnos'] : ['ficha', '👤', 'Mi perfil'], ['grabar', '🎥', 'Grabar'], ['tactica', '♟️', 'Táctica'], ['mas', '☰', 'Más']]
    .map(([v, i, t]) => `<button data-ir="${v}" class="${V.vista === v || (v === 'jugadores' && V.vista === 'ficha') ? 'on' : ''}"><span>${i}</span>${t}</button>`).join('');
  const f = { inicio: pInicio, jugadores: pJugadores, ficha: pFicha, grabar: pGrabar, sesion: pSesion, tactica: pTactica, mas: pMas }[V.vista] || pInicio;
  f();
}
const main = h => { $('#app').innerHTML = h; };

/* ---------- bienvenida ---------- */
function pintarBienvenida() {
  $('#nav').hidden = true;
  main(`<div class="bienv"><div class="logo">🏓</div><h1>Paleta</h1><p>Graba los golpes con la cámara, recibe un informe de lo que hay que corregir y mira en 3D tu golpe junto al golpe correcto.</p>
    <button class="btn pri grande" data-modo="entrenador">Soy entrenador<small>Registro a mis alumnos y analizo sus golpes</small></button>
    <button class="btn grande" data-modo="alumno">Soy jugador<small>Me grabo y mejoro mi técnica</small></button>
    <p class="note">Podrás cambiar de modo después en Más.</p></div>`);
}

/* ---------- inicio ---------- */
async function pInicio() {
  const c = Datos.cfg(), j = Datos.activo(), lista = Datos.jugadores();
  let h = `<header class="cab"><h1>Paleta</h1><span class="badge">${c.modo === 'entrenador' ? 'Entrenador' : 'Jugador'}</span></header>`;
  if (c.modo === 'entrenador') {
    h += lista.length ? `<div class="card"><label>Alumno<select data-activo>${lista.map(x => `<option value="${x.id}" ${j && j.id === x.id ? 'selected' : ''}>${e(x.nombre)}</option>`).join('')}</select></label></div>`
      : `<div class="card"><p>Aún no registras alumnos.</p><button class="btn pri" data-ir="ficha" data-arg="nuevo">+ Registrar un alumno</button></div>`;
  } else if (!j) h += `<div class="card"><p>Completa tu perfil para que la app sepa qué esperar de tu juego.</p><button class="btn pri" data-ir="ficha" data-arg="nuevo">Crear mi perfil</button></div>`;
  h += `<div class="card acc"><h2>Analizar un golpe</h2><p class="note">Graba 30 segundos practicando un solo golpe. La app detecta cada golpe, lo mide y te muestra qué corregir.</p>
    <div class="row"><button class="btn pri" data-ir="grabar">🎥 Grabar</button><button class="btn" data-demo>Ver demostración</button></div></div>`;
  if (j) {
    const sug = Ev.golpesSugeridos(j);
    h += `<div class="card"><h3>Golpes clave para ${e(j.nombre.split(' ')[0])}</h3><p class="note">${e((K.ESTILOS.find(x => x.id === j.estilo) || {}).nombre || 'Estilo no indicado')}</p><div class="chips">${sug.map(g => `<button class="chip" data-ir="grabar" data-arg="${g.id}">${e(g.nombre)}</button>`).join('')}</div></div>`;
  }
  h += `<h3 class="sec">Últimos análisis</h3><div id="ultimas"><p class="note">Cargando…</p></div>`;
  main(h);
  const s = await Datos.sesiones(c.modo === 'entrenador' ? null : (j && j.id));
  $('#ultimas').innerHTML = s.length ? s.slice(0, 12).map(filaSesion).join('') : '<p class="note">Todavía no hay análisis.</p>';
}
function filaSesion(s) {
  const j = Datos.jugador(s.jugadorId);
  return `<button class="fila" data-ir="sesion" data-arg="${s.id}"><span class="pt ${s.puntaje >= 80 ? 'bien' : s.puntaje >= 60 ? 'regular' : 'mal'}">${s.puntaje ?? '–'}</span>
    <span><b>${e(s.golpeNombre)}</b><small>${e(j ? j.nombre : 'Demostración')} · ${Informe.fecha(s.fecha)}</small><small>${e((s.fallas || []).slice(0, 2).join(' · '))}</small></span></button>`;
}

/* ---------- alumnos ---------- */
function pJugadores() {
  const l = Datos.jugadores();
  main(`<header class="cab"><h1>Alumnos</h1><button class="btn sm pri" data-ir="ficha" data-arg="nuevo">+ Nuevo</button></header>
    ${l.length ? l.map(j => `<button class="fila" data-ir="ficha" data-arg="${j.id}"><span class="pt">${e((j.nombre || '?')[0])}</span><span><b>${e(j.nombre)}</b><small>${e([j.edad ? j.edad + ' años' : '', (K.ESTILOS.find(x => x.id === j.estilo) || {}).nombre, j.nivel].filter(Boolean).join(' · '))}</small></span></button>`).join('') : '<div class="card"><p>Registra a tu primer alumno con sus datos, su estilo y su material.</p></div>'}`);
}

/* ---------- ficha del jugador ---------- */
const opt = (l, v) => '<option value="">—</option>' + l.map(x => { const id = typeof x === 'string' ? x : x.id, n = typeof x === 'string' ? x : x.nombre; return `<option value="${e(id)}" ${v === id ? 'selected' : ''}>${e(n)}</option>`; }).join('');
function campo(n, t, v, tipo, extra) { return `<label>${t}<input name="${n}" type="${tipo || 'text'}" value="${e(v ?? '')}" ${extra || ''}></label>`; }
function sel(n, t, l, v) { return `<label>${t}<select name="${n}">${opt(l, v)}</select></label>`; }
function bloqueGoma(p, t, g) {
  g = g || {};
  return `<fieldset><legend>${t}</legend>${campo(p + '.modelo', 'Marca y modelo', g.modelo, 'text', 'placeholder="Ej.: Tenergy 05, Hurricane 3"')}
    ${sel(p + '.tipo', 'Tipo de goma', K.GOMAS.tipo, g.tipo)}${sel(p + '.esponja', 'Espesor de esponja', K.GOMAS.esponja, g.esponja)}
    ${sel(p + '.dureza', 'Dureza', K.GOMAS.dureza, g.dureza)}${sel(p + '.color', 'Color', K.GOMAS.color, g.color)}
    ${campo(p + '.meses', 'Meses de uso', g.meses, 'number', 'min="0" inputmode="numeric"')}</fieldset>`;
}
function pFicha() {
  const c = Datos.cfg();
  let j = V.arg === 'nuevo' ? null : (V.arg ? Datos.jugador(V.arg) : Datos.activo());
  if (!j && V.arg !== 'nuevo' && c.modo === 'alumno') { V.arg = 'nuevo'; }
  const nuevo = !j; j = j || { mano: 'D', propio: c.modo === 'alumno' };
  const tabs = nuevo ? [] : [['datos', 'Datos'], ['material', 'Material y toma'], ['sesiones', 'Análisis'], ['tactica', 'Táctica']];
  let h = `<header class="cab">${c.modo === 'entrenador' ? '<button class="btn sm ghost" data-ir="jugadores">←</button>' : ''}<h1>${nuevo ? (c.modo === 'entrenador' ? 'Nuevo alumno' : 'Mi perfil') : e(j.nombre)}</h1></header>`;
  if (tabs.length) h += `<div class="tabs">${tabs.map(([k, t]) => `<button data-tab="${k}" class="${V.tab === k ? 'on' : ''}">${t}</button>`).join('')}</div>`;
  const tab = nuevo ? 'datos' : V.tab;
  if (tab === 'datos') {
    const r = j.respuestasToma || {};
    h += `<form id="ficha" class="form" data-id="${j.id || ''}">
      <fieldset class="desc"><legend>✨ Descripción del jugador</legend>
      <p class="note">Escribe con tus palabras cómo es: edad, mano, estilo, toma, madero y gomas (marca y modelo sirven). La IA reconoce el material, completa la ficha y redacta su perfil técnico.</p>
      <textarea name="descripcion" rows="4" placeholder="Ej.: Tomás, diestro de 15 años, delgado, compite hace 3 años. Juega topspin a media distancia. Madero Viscaria, Tenergy 05 roja al derecho y Hurricane 3 negra al revés. Toma clásica.">${e(j.descripcion || '')}</textarea>
      <div class="row"><button type="button" class="btn pri" data-a="perfil-ia">✨ Completar la ficha con IA</button></div><p class="note" id="perfil-estado"></p>
      <label>Perfil técnico (la app lo tiene presente al analizar)<textarea name="perfilIA" rows="6" placeholder="Se genera con el botón de arriba o al guardar.">${e(j.perfilIA || '')}</textarea></label></fieldset>
      <fieldset><legend>Jugador</legend>${campo('nombre', 'Nombre', j.nombre, 'text', 'required')}
      <div class="dos">${campo('edad', 'Edad', j.edad, 'number', 'min="4" max="99" inputmode="numeric"')}${sel('sexo', 'Sexo', ['Femenino', 'Masculino', 'Otro'], j.sexo)}</div>
      <div class="dos">${campo('estatura', 'Estatura (cm)', j.estatura, 'number', 'inputmode="numeric"')}${campo('peso', 'Peso (kg)', j.peso, 'number', 'inputmode="numeric"')}</div>
      ${sel('contextura', 'Contextura física', K.CONTEXTURAS, j.contextura)}
      <label>Mano con la que juega<select name="mano"><option value="D" ${j.mano !== 'Z' ? 'selected' : ''}>Diestro</option><option value="Z" ${j.mano === 'Z' ? 'selected' : ''}>Zurdo</option></select></label>
      ${sel('nivel', 'Nivel', K.NIVELES, j.nivel)}${campo('sesiones', 'Entrenamientos por semana', j.sesiones, 'number', 'min="0" max="14" inputmode="numeric"')}</fieldset>
      <fieldset><legend>Estilo de juego</legend>${sel('estilo', 'Estilo', K.ESTILOS, j.estilo)}<p class="note" id="estilo-desc">${e((K.ESTILOS.find(x => x.id === j.estilo) || {}).descripcion || '')}</p>
      ${sel('toma', 'Toma de la paleta', K.TOMAS, j.toma)}
      ${K.PREGUNTAS_TOMA.map(q => q.tipo === 'rango' ? `<label>${e(q.texto)} <b id="v-${q.id}">${r[q.id] || 5}</b><input type="range" name="toma.${q.id}" min="${q.min}" max="${q.max}" value="${r[q.id] || 5}"></label>` : sel('toma.' + q.id, e(q.texto), q.opciones, r[q.id])).join('')}</fieldset>
      <fieldset><legend>Madero</legend>${campo('madero.modelo', 'Marca y modelo', (j.madero || {}).modelo, 'text', 'placeholder="Ej.: Viscaria, Clipper Wood"')}
      ${sel('madero.composicion', 'Composición', K.MADEROS.composicion, (j.madero || {}).composicion)}${sel('madero.velocidad', 'Velocidad', K.MADEROS.velocidad, (j.madero || {}).velocidad)}
      ${sel('madero.mango', 'Mango', K.MADEROS.mango, (j.madero || {}).mango)}${campo('madero.peso', 'Peso del madero (g)', (j.madero || {}).peso, 'number', 'inputmode="numeric"')}</fieldset>
      ${bloqueGoma('gomaD', 'Goma del derecho', j.gomaD)}${bloqueGoma('gomaR', 'Goma del revés', j.gomaR)}
      <fieldset><legend>Objetivos y notas</legend><label>Objetivos<textarea name="objetivos" rows="2">${e(j.objetivos || '')}</textarea></label>
      ${c.modo === 'entrenador' ? `<label>Notas del entrenador<textarea name="notas" rows="3">${e(j.notas || '')}</textarea></label>` : ''}</fieldset>
      <div class="row"><button class="btn pri" type="submit">Guardar</button>${!nuevo && c.modo === 'entrenador' ? '<button class="btn ghost peligro" type="button" data-borrar-jugador>Borrar alumno</button>' : ''}</div></form>`;
  } else if (tab === 'material') {
    const lista = (titulo, l) => `<h3 class="sec">${titulo}</h3>` + l.map(x => `<div class="card aviso-${x.nivel}"><h4>${e(x.titulo)}</h4><p>${e(x.texto)}</p></div>`).join('');
    h += lista('Material', Ev.asesorMaterial(j)) + lista('Toma', Ev.asesorToma(j));
    h += `<p class="note">Los consejos se basan en los datos del perfil. Edita la pestaña Datos para actualizarlos.</p>`;
  } else if (tab === 'sesiones') {
    h += `<div class="row"><button class="btn pri" data-ir="grabar">🎥 Nuevo análisis</button></div><div id="ses"><p class="note">Cargando…</p></div>`;
  } else if (tab === 'tactica') {
    h += tacticaHTML(j);
  }
  main(h);
  if (tab === 'sesiones') Datos.sesiones(j.id).then(s => { $('#ses').innerHTML = s.length ? resumenSesiones(s) + s.map(filaSesion).join('') : '<p class="note">Sin análisis todavía.</p>'; });
}
function resumenSesiones(s) {
  const por = {}; s.forEach(x => (por[x.golpeNombre] = por[x.golpeNombre] || []).push(x));
  return `<div class="card"><h3>Progreso por golpe</h3>${Object.entries(por).map(([g, l]) => { const ult = l[0].puntaje, pri = l[l.length - 1].puntaje; const d = ult - pri; return `<div class="row sb"><span>${e(g)}</span><span><b>${ult}</b> ${l.length > 1 ? `<small class="${d >= 0 ? 'bien' : 'mal'}">${d >= 0 ? '▲' : '▼'} ${Math.abs(d)}</small>` : ''}</span></div>`; }).join('')}</div>`;
}
function leerFicha(f) {
  const id = f.dataset.id, base = id ? Datos.jugador(id) : { propio: Datos.cfg().modo === 'alumno' };
  const j = Object.assign({}, base, { madero: Object.assign({}, base.madero), gomaD: Object.assign({}, base.gomaD), gomaR: Object.assign({}, base.gomaR), respuestasToma: Object.assign({}, base.respuestasToma) });
  for (const el of f.elements) {
    if (!el.name) continue;
    const [a, b] = el.name.split('.');
    if (b) { const dest = a === 'toma' ? j.respuestasToma : j[a]; dest[b] = el.value; } else j[a] = el.value;
  }
  return j;
}

/* Completa la ficha a partir de la descripción libre: intérprete local + IA */
function rellenarFicha(f, datos) {
  let n = 0;
  for (const el of f.elements) {
    if (!el.name || el.name === 'descripcion' || el.name === 'perfilIA') continue;
    const [a, b] = el.name.split('.');
    const v = b ? (a === 'toma' ? (datos.respuestasToma || {})[b] : (datos[a] || {})[b]) : datos[a];
    if (v === undefined || v === null || v === '' || String(el.value) === String(v)) continue;
    if (el.tagName === 'SELECT' && !Array.from(el.options).some(o => o.value === String(v))) continue;
    el.value = v; el.classList.add('cambiado'); n++;
    if (el.name === 'estilo') { const d = $('#estilo-desc'); if (d) d.textContent = (K.ESTILOS.find(x => x.id === v) || {}).descripcion || ''; }
  }
  return n;
}
async function completarPerfil(boton) {
  const f = $('#ficha'), est = $('#perfil-estado'), texto = f.elements.descripcion.value.trim();
  if (!texto) { est.textContent = 'Escribe primero una descripción del jugador.'; return; }
  boton.disabled = true; est.textContent = 'Leyendo la descripción…';
  let datos = Perfil.combinar(leerFicha(f), Perfil.interpretarLocal(texto));
  let perfil = '', conIA = false;
  try {
    est.textContent = 'Consultando a la IA… (puede tardar hasta un minuto)';
    const { sistema, usuario } = Perfil.pedidoIA(texto, { nombre: datos.nombre, edad: datos.edad, mano: datos.mano });
    const r = Perfil.normalizar(Perfil.extraerJSON(await Informe.llamarIA(sistema, usuario, true)));
    perfil = r.perfil || ''; delete r.perfil;
    datos = Perfil.combinar(datos, r); conIA = true;
  } catch (x) { }
  datos.descripcion = texto;
  if (!f.elements.nombre.value && /^\s*([A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?: [A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)?)[,.]/.test(texto)) datos.nombre = RegExp.$1;
  const n = rellenarFicha(f, datos);
  f.elements.perfilIA.value = perfil || Perfil.describirLocal(datos, Ev);
  est.textContent = (conIA ? `La IA completó ${n} campos` : `Sin conexión con la IA: se completaron ${n} campos con el intérprete del teléfono`) + '. Revisa lo marcado en naranjo y toca Guardar.';
  boton.disabled = false;
}

/* ---------- táctica ---------- */
function tacticaHTML(j) {
  const est = K.ESTILOS.find(x => x.id === j.estilo);
  let h = `<div class="card"><p>Estilo de ${e(j.nombre.split(' ')[0])}: <b>${e(est ? est.nombre : 'sin indicar')}</b></p>${est ? '' : '<p class="note">Indica el estilo en el perfil para jugadas a la medida.</p>'}
    ${j.perfilIA ? `<details><summary class="note">Ver perfil técnico</summary><div class="texto note">${e(j.perfilIA).replace(/\n/g, '<br>')}</div></details>` : ''}
    <label>¿Contra qué tipo de rival?<select data-rival>${'<option value="">Cualquier rival</option>' + K.RIVALES.map(r => `<option value="${r.id}" ${V.rival === r.id ? 'selected' : ''}>${e(r.nombre)}</option>`).join('')}</select></label></div>`;
  const debil = (j._debil || []);
  const l = Ev.jugadasPara(j, V.rival, debil);
  h += l.map(x => `<div class="card jugada"><h4>${e(x.nombre)}</h4><p class="note">${e(x.objetivo)}</p><ol>${x.pasos.map(p => `<li>${e(p)}</li>`).join('')}</ol>${x.aviso.map(a => `<p class="note warn">${e(a)}</p>`).join('')}</div>`).join('') || '<p class="note">No hay jugadas para esa combinación.</p>';
  return h;
}
function pTactica() {
  const c = Datos.cfg(), lista = Datos.jugadores(); let j = Datos.activo();
  let h = `<header class="cab"><h1>Táctica</h1></header>`;
  if (!j) { main(h + '<div class="card"><p>Primero registra un jugador con su estilo de juego.</p></div>'); return; }
  if (c.modo === 'entrenador' && lista.length > 1) h += `<div class="card"><label>Alumno<select data-activo>${lista.map(x => `<option value="${x.id}" ${j.id === x.id ? 'selected' : ''}>${e(x.nombre)}</option>`).join('')}</select></label></div>`;
  main(h + tacticaHTML(j));
}

/* Diagrama visto desde arriba: mesa, jugador y dónde poner la cámara */
function diagramaCamara(golpeId, mano) {
  const cam = K.camaraPara(golpeId), s = 30, px = 160, py = 150;
  const ladoGolpe = mano === 'Z' ? -1 : 1, signo = cam.lado === 'golpe' ? ladoGolpe : -ladoGolpe;
  const d = Math.min(cam.distancia * s, 105);
  let cx = px, cy = py;
  if (cam.vista === 'lado') cx = px + signo * d;
  else if (cam.vista === 'diagonal') { cx = px + signo * d * 0.71; cy = py - d * 0.71; }
  else { cy = py + d; }
  const ang = Math.atan2(py - cy, px - cx) * 180 / Math.PI;
  const mx = (px + cx) / 2, my = (py + cy) / 2;
  const paleta = px + ladoGolpe * 16;
  const lx = px - cx, ly = py - cy, ll = Math.hypot(lx, ly) || 1, nx = -ly / ll * 30, ny = lx / ll * 30;
  const ex = px + lx / ll * 18, ey = py + ly / ll * 18;
  return `<svg viewBox="0 0 320 ${cam.vista === 'atras' ? 290 : 200}" class="diag" role="img" aria-label="Ubicación de la cámara">
    <rect x="${px - 23}" y="30" width="46" height="82" rx="3" fill="#1f5fa8" stroke="#fff" stroke-width="1.5"/><line x1="${px}" y1="30" x2="${px}" y2="112" stroke="#fff" stroke-width="1"/><line x1="${px - 30}" y1="71" x2="${px + 30}" y2="71" stroke="#ddd" stroke-width="2.5"/>
    <text x="${px + 30}" y="52" class="dt">Mesa</text>
    <polygon points="${cx},${cy} ${ex + nx},${ey + ny} ${ex - nx},${ey - ny}" fill="#ff8a1f22"/>
    <line x1="${cx}" y1="${cy}" x2="${px}" y2="${py}" stroke="#ff8a1f" stroke-width="1.5" stroke-dasharray="5 4"/>
    <text x="${mx + 6}" y="${my - 6}" class="dt n">${String(cam.distancia).replace('.', ',')} m</text>
    <circle cx="${px}" cy="${py}" r="13" fill="#38e8a0"/><path d="M${px - 6} ${py - 8} L${px} ${py - 20} L${px + 6} ${py - 8}" fill="#38e8a0"/>
    <circle cx="${paleta}" cy="${py - 4}" r="6" fill="#d62830" stroke="#fff"/>
    <text x="${px}" y="${py + 30}" text-anchor="middle" class="dt">Jugador</text>
    <g transform="translate(${cx},${cy}) rotate(${ang})"><rect x="-13" y="-9" width="22" height="18" rx="3" fill="#ff8a1f"/><circle cx="12" cy="0" r="5" fill="#ff8a1f"/><circle cx="-2" cy="0" r="4.5" fill="#1d0e00"/></g>
    <text x="${cx}" y="${cy + (cam.vista === 'atras' ? 26 : -16)}" text-anchor="middle" class="dt n">Cámara</text>
  </svg>`;
}
function textoCamara(golpeId, mano) {
  const cam = K.camaraPara(golpeId);
  const brazo = mano === 'Z' ? 'izquierdo' : 'derecho', libre = mano === 'Z' ? 'derecho' : 'izquierdo';
  const lado = cam.lado === 'golpe' ? `del lado del brazo que golpea (el ${brazo})` : `del lado del brazo libre (el ${libre})`;
  const donde = cam.vista === 'lado' ? `De lado al jugador, ${lado}, mirando perpendicular a él.`
    : cam.vista === 'diagonal' ? `En diagonal, 45° por delante del jugador, ${lado}.`
    : 'Detrás del jugador, centrada, para ver los dos lados de la mesa.';
  return [donde, `A ${String(cam.distancia).replace('.', ',')} metros de distancia.`, `El teléfono ${K.ALTURA[cam.altura]}, en horizontal y quieto (trípode o apoyado).`, 'Que entre el cuerpo completo, de la cabeza a los pies.', cam.por];
}
function opcionesVision(j) {
  const mapa = { Negra: 'Negra', Roja: 'Roja', Rosada: 'Rosada', Verde: 'Verde', Azul: 'Azul', Morada: 'Morada' };
  const cols = [(j.gomaD || {}).color, (j.gomaR || {}).color].map(c => mapa[c]).filter(Boolean);
  return { colorPelota: Datos.cfg().colorPelota || 'naranja', colores: cols.length ? Array.from(new Set(cols)) : ['Roja', 'Negra'], mano: j.mano || 'D' };
}
function hablar(t) { try { const u = new SpeechSynthesisUtterance(t); u.lang = 'es-CL'; u.rate = 1.05; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (x) { } }

/* ---------- grabar ---------- */
function pGrabar() {
  const j = Datos.activo();
  if (!j) { main(`<header class="cab"><h1>Grabar</h1></header><div class="card"><p>Primero registra ${Datos.cfg().modo === 'entrenador' ? 'al alumno' : 'tu perfil'}: la app necesita la mano, el nivel, el estilo y el material para saber qué esperar.</p><button class="btn pri" data-ir="ficha" data-arg="nuevo">Registrar</button></div>`); return; }
  const grupos = {}; K.GOLPES.forEach(g => (grupos[g.grupo] = grupos[g.grupo] || []).push(g));
  const sug = new Set(Ev.golpesSugeridos(j).map(g => g.id));
  const elegido = V.arg || Ev.golpesSugeridos(j)[0].id;
  main(`<header class="cab"><h1>Grabar</h1><span class="badge">${e(j.nombre)}</span></header>
    <div class="pasos"><span class="on">1 Golpe</span><span>2 Cámara</span><span>3 Postura</span><span>4 Grabar</span></div>
    <div class="card form"><label>¿Qué golpe vas a analizar?<select id="g-golpe">${Object.entries(grupos).map(([gr, l]) => `<optgroup label="${e(gr)}">${l.map(g => `<option value="${g.id}" ${g.id === elegido ? 'selected' : ''}>${sug.has(g.id) ? '★ ' : ''}${e(g.nombre)}</option>`).join('')}</optgroup>`).join('')}</select></label>
      <div class="dos"><label>Duración<select id="g-dur"><option value="30">30 s</option><option value="45">45 s</option><option value="60">60 s</option></select></label>
      <label>Cámara<select id="g-cam"><option value="0">Trasera (otra persona graba)</option><option value="1">Delantera (me grabo solo)</option></select></label></div>
      <label>Color de la pelota<select id="g-pelota"><option value="naranja" ${Datos.cfg().colorPelota !== 'blanca' ? 'selected' : ''}>Naranja</option><option value="blanca" ${Datos.cfg().colorPelota === 'blanca' ? 'selected' : ''}>Blanca</option></select></label></div>
    <div id="g-guia"></div>
    <div class="row"><button class="btn pri grande" data-camara>🎥 Abrir la cámara</button></div>
    <div class="row"><label class="btn">📁 Analizar un video de la galería<input type="file" accept="video/*" id="g-archivo" hidden></label></div>`);
  const guia = () => {
    const g = Ev.golpe($('#g-golpe').value), dur = $('#g-dur').value;
    const toma = K.GUIA_TOMA[j.toma] || K.GUIA_TOMA.sh_neutra;
    $('#g-guia').innerHTML = `
      <div class="card anuncio"><small>Vas a analizar</small><h2>${e(g.nombre)}</h2><p>${e(g.descripcion)}</p>
        <p class="note">Durante ${dur} segundos ${j.propio ? 'haz' : 'el jugador debe hacer'} <b>solo este golpe</b>, sin mezclar otros. Lo ideal es con multibola o con un compañero que bloquee.</p>
        <h4>Así se hace bien</h4><ul>${g.claves.map(c => `<li>${e(c)}</li>`).join('')}</ul></div>
      <div class="card"><h3>📍 Dónde poner la cámara</h3>${diagramaCamara(g.id, j.mano)}<ul class="guia">${textoCamara(g.id, j.mano).map(t => `<li>${e(t)}</li>`).join('')}</ul></div>
      <div class="card"><h3>✋ Revisa la toma${j.toma ? ': ' + e((K.TOMAS.find(x => x.id === j.toma) || {}).nombre || '') : ''}</h3><ul>${toma.map(t => `<li>${e(t)}</li>`).join('')}</ul></div>
      <div class="card"><h3>🧍 Posición de espera</h3><ul><li>Pies algo más separados que los hombros, con el peso adelante.</li><li>Rodillas flexionadas, como para sentarse en un banco alto.</li><li>Tronco levemente inclinado hacia la mesa.</li><li>Paleta delante del cuerpo y brazo libre a la altura del pecho.</li></ul><p class="note">Al abrir la cámara, la app revisa todo esto en vivo y te avisa qué corregir antes de grabar.</p></div>
      <div class="card"><h3>🏓 Para que la app vea la pelota y la paleta</h3><ul><li>Con la pelota y la paleta la app mide el <b>timing</b> (si golpeas en la subida, en el punto más alto o en la bajada), el <b>ángulo de la cara de la paleta</b> en el impacto y la <b>velocidad de salida</b>.</li><li>Usa pelota naranja si el fondo es claro, o blanca con fondo oscuro. Evita objetos del mismo color detrás.</li><li>Que se vean la mesa del lado del jugador y su mano con la paleta. Mucha luz: con poca luz la pelota sale borrosa.</li><li>Si el teléfono lo permite, la app graba a 60 cuadros por segundo para no perder la pelota.</li></ul></div>
      ${j.perfilIA ? `<details class="card"><summary><b>Perfil de ${e(j.nombre.split(' ')[0])}</b></summary><div class="texto">${e(j.perfilIA).replace(/\n/g, '<br>')}</div></details>` : ''}`;
  };
  $('#g-golpe').onchange = guia; $('#g-dur').onchange = guia; guia();
  $('#g-pelota').onchange = ev => Datos.setCfg({ colorPelota: ev.target.value });
}

async function abrirCamara() {
  const j = Datos.activo(), golpeId = $('#g-golpe').value, dur = +$('#g-dur').value, frontal = $('#g-cam').value === '1';
  const g = Ev.golpe(golpeId);
  const capa = document.createElement('div'); capa.className = 'camara';
  capa.innerHTML = `<video playsinline muted></video><canvas></canvas>
    <div class="cam-arriba"><button class="btn sm ghost" data-cerrar>✕</button><span class="cam-golpe">🏓 ${e(g.nombre)}</span><span class="cam-tiempo"></span></div>
    <div class="cam-estado">Iniciando…</div>
    <div class="cam-consejo"></div>
    <div class="cam-panel"><ul class="cam-lista">
      <li data-k="camara"><i>⏳</i><span>Ángulo de la cámara</span></li>
      <li data-k="cuerpo"><i>⏳</i><span>Cuerpo completo</span></li>
      <li data-k="apoyo"><i>⏳</i><span>Piernas</span></li>
      <li data-k="rodillas"><i>⏳</i><span>Qué tan agachado</span></li>
      <li data-k="tronco"><i>⏳</i><span>Tronco</span></li>
      <li data-k="toma" class="toca"><i>✋</i><span>Toca aquí cuando hayas revisado la toma</span></li>
      <li data-k="pelota" class="info"><i>○</i><span>Pelota y paleta: haz un par de golpes de prueba</span></li>
    </ul><div class="cam-vivos" hidden><b class="cam-cuenta-golpes">0 golpes</b><ul></ul></div></div>
    <div class="cam-anuncio" hidden></div>
    <div class="cam-cuenta" hidden></div>
    <div class="cam-abajo"><button class="rec" data-rec aria-label="Grabar"></button><small class="cam-listo">Revisando…</small></div>`;
  document.body.appendChild(capa);
  const video = $('video', capa), lienzo = $('canvas', capa), estado = $('.cam-estado', capa);
  let control = null, sinCuerpo = 0, grabandoYa = false, tomaOk = false;
  const ultimos = [], vivos = [], vistos = [];
  let reportados = [], nGolpe = 0, ultimoAnalisis = 0, ultimoConsejo = 0;
  const estadoItems = {};
  const poner = (k, ok, txt) => { estadoItems[k] = ok; const li = $(`[data-k=${k}]`, capa); if (!li) return; li.className = (ok ? 'ok' : 'mal') + (k === 'toma' ? ' toca' : ''); $('i', li).textContent = ok ? '✓' : '✗'; if (txt) $('span', li).textContent = txt; };
  const cerrar = () => { control && control.detener(); Pose.cerrarCamara(); try { speechSynthesis.cancel(); } catch (x) { } capa.remove(); camara = null; };
  camara = { cerrar };
  $('[data-cerrar]', capa).onclick = cerrar;
  $('[data-k=toma]', capa).onclick = () => {
    if (tomaOk) return;
    const guia = K.GUIA_TOMA[j.toma] || K.GUIA_TOMA.sh_neutra;
    if (confirm('Revisa la toma:\n\n• ' + guia.join('\n• ') + '\n\n¿La toma está bien?')) { tomaOk = true; poner('toma', true, 'Toma revisada'); }
  };
  const mediana = a => { const b = a.slice().sort((x, y) => x - y); return b[b.length >> 1]; };
  function revisar(c) {
    ultimos.push(c); if (ultimos.length > 12) ultimos.shift();
    const v = ultimos[ultimos.length - 1].vista;
    const cc = Ev.chequeoCamara(v, golpeId, j.mano);
    const enCuadro = v && v.alturaCuerpo >= 0.42 && v.alturaCuerpo <= 0.98 && c.vis >= 0.5;
    poner('cuerpo', enCuadro, enCuadro ? 'Cuerpo completo en la imagen' : (c.vis < 0.5 ? 'No se ven los pies: aleja la cámara' : cc.txt));
    poner('camara', cc.ok, cc.ok ? cc.txt : cc.txt);
    const ms = ultimos.map(x => Bio.medidasEnVivo(x.P, j.mano));
    const m = { apoyo: mediana(ms.map(x => x.apoyo)), rodillas: mediana(ms.map(x => x.rodillas)), tronco: mediana(ms.map(x => x.tronco)) };
    const ch = Ev.chequeoPostura(m, golpeId);
    for (const k of ['apoyo', 'rodillas', 'tronco']) poner(k, ch[k].ok, ch[k].txt);
    vistos.push([!!(c.b && c.b.length), !!c.pl]); if (vistos.length > 90) vistos.shift();
    const vp = vistos.some(x => x[0]), vpl = vistos.filter(x => x[1]).length > 10;
    if (vp || vpl) { const li = $('[data-k=pelota]', capa); li.className = vp && vpl ? 'ok info' : 'info'; $('i', li).textContent = vp && vpl ? '✓' : '○'; $('span', li).textContent = vp && vpl ? 'Se ven la pelota y la paleta' : vp ? 'Se ve la pelota; la paleta no se distingue' : 'Se ve la paleta; aún no la pelota'; }
    const todo = ['camara', 'cuerpo', 'apoyo', 'rodillas', 'tronco', 'toma'].every(k => estadoItems[k]);
    $('.cam-listo', capa).textContent = todo ? 'Todo listo: toca para grabar' : 'Corrige lo marcado con ✗ o toca para grabar igual';
    capa.classList.toggle('listo', todo);
    return todo;
  }
  function analizarEnVivo() {
    const ahora = vivos.length ? vivos[vivos.length - 1].t : 0;
    if (ahora - ultimoAnalisis < 0.4) return; ultimoAnalisis = ahora;
    const desde = vivos.findIndex(x => x.t >= ahora - 3.2); if (desde < 0) return;
    const ventana = vivos.slice(desde);
    const det = Bio.detectarGolpes(ventana, j.mano);
    for (const gd of det) {
      const tC = ventana[gd.impacto].t;
      if (reportados.some(t => Math.abs(t - tC) < 0.3) || tC > ahora - 0.15) continue;
      reportados.push(tC);
      const m = Bio.medirGolpe(ventana, gd, j.mano), ev = Ev.evaluarGolpe(m, j, golpeId);
      nGolpe++;
      const ok = ev.coincide && !ev.malas.length;
      const txt = !ev.coincide ? `no parece ${g.nombre.toLowerCase()}` : ok ? 'bien' : ev.malas[0].titulo.toLowerCase();
      const li = document.createElement('li'); li.className = ok ? 'ok' : 'mal'; li.textContent = `${ok ? '✓' : '✗'} Golpe ${nGolpe}: ${txt}`;
      const ul = $('.cam-vivos ul', capa); ul.prepend(li); while (ul.children.length > 4) ul.lastChild.remove();
      $('.cam-cuenta-golpes', capa).textContent = `${nGolpe} golpe${nGolpe === 1 ? '' : 's'}`;
    }
  }
  try {
    estado.textContent = 'Abriendo la cámara…';
    await Pose.abrirCamara(video, frontal);
    estado.textContent = 'Cargando el detector del cuerpo…';
    control = await Pose.enVivo(video, lienzo, Object.assign(opcionesVision(j), {
      onCuadro(c, grabando) {
        if (!c) { if (++sinCuerpo > 15) { estado.textContent = 'No se ve al jugador: ubícalo dentro de la imagen'; ['camara', 'cuerpo'].forEach(k => poner(k, false)); } return; }
        sinCuerpo = 0;
        if (!grabando) { estado.textContent = 'Revisando la ubicación y la postura…'; revisar(c); return; }
        estado.textContent = '● Grabando: haz solo ' + g.nombre.toLowerCase();
        vivos.push(c);
        analizarEnVivo();
        const ahora = performance.now();
        if (ahora - ultimoConsejo > 4000) {
          const t = Ev.consejoEnVivo(Bio.medidasEnVivo(c.P, j.mano), golpeId);
          if (t) { $('.cam-consejo', capa).textContent = t; ultimoConsejo = ahora; setTimeout(() => { const el = $('.cam-consejo', capa); if (el) el.textContent = ''; }, 2200); }
        }
      }
    }));
    hablar(`Vamos a analizar ${g.nombre}. Ubica la cámara ${K.NOMBRE_VISTA[K.camaraPara(golpeId).vista]} y revisa la lista.`);
  } catch (x) {
    estado.textContent = 'No se pudo abrir la cámara o el detector.';
    $('.cam-consejo', capa).textContent = (x && x.message) || '';
    return;
  }
  $('[data-rec]', capa).onclick = async () => {
    const b = $('[data-rec]', capa); if (b.disabled || grabandoYa) return;
    const pendientes = ['camara', 'cuerpo', 'apoyo', 'rodillas', 'tronco', 'toma'].filter(k => !estadoItems[k]);
    if (pendientes.length && !confirm('Todavía hay puntos marcados con ✗. Grabar así puede dar un análisis menos preciso.\n\n¿Grabar igual?')) return;
    b.disabled = true; grabandoYa = true;
    const an = $('.cam-anuncio', capa);
    an.innerHTML = `<small>Haz solo este golpe</small><b>${e(g.nombre)}</b><small>durante ${dur} segundos</small>`; an.hidden = false;
    hablar(`Haz solo ${g.nombre}, durante ${dur} segundos. Empezamos en cinco.`);
    await new Promise(r => setTimeout(r, 2600)); an.hidden = true;
    const cuenta = $('.cam-cuenta', capa); cuenta.hidden = false;
    for (let k = 5; k > 0; k--) { cuenta.textContent = k; await new Promise(r => setTimeout(r, 1000)); }
    cuenta.hidden = true; b.classList.add('on'); hablar('¡Ya!');
    $('.cam-lista', capa).hidden = true; $('.cam-vivos', capa).hidden = false;
    control.empezar();
    const t0 = performance.now();
    await new Promise(r => { const tick = () => { const s = (performance.now() - t0) / 1000; const el = $('.cam-tiempo', capa); if (!el) return r(); el.textContent = Math.max(0, Math.ceil(dur - s)) + ' s'; if (s >= dur) return r(); setTimeout(tick, 200); }; tick(); });
    if (!document.body.contains(capa)) return;
    hablar('Listo. Analizando.');
    estado.textContent = 'Analizando…';
    const res = await control.terminar();
    cerrar();
    await analizar(res, j, golpeId);
  };
}

async function analizarArchivo(archivo) {
  const j = Datos.activo(), golpeId = $('#g-golpe').value;
  const capa = document.createElement('div'); capa.className = 'procesando';
  capa.innerHTML = `<div><div class="spin"></div><p>Analizando el video…</p><div class="prog"><i></i></div><small>Puede tardar un par de minutos. No cierres la app.</small></div>`;
  document.body.appendChild(capa);
  try {
    const res = await Pose.procesarArchivo(archivo, p => { $('.prog i', capa).style.width = Math.round(p * 100) + '%'; }, opcionesVision(j));
    capa.remove();
    await analizar(res, j, golpeId);
  } catch (x) { capa.remove(); toast((x && x.message) || 'No se pudo analizar el video.'); }
}

/* Diagnóstico + guardado de la sesión */
async function analizar(res, j, golpeId, demo) {
  if (!res.cuadros || res.cuadros.length < 20) { toast('Se detectó muy poco del jugador. Revisa que se vea el cuerpo completo.'); return; }
  const diag = Ev.diagnosticar(res.cuadros, j, golpeId, { ancho: res.ancho, alto: res.alto });
  if (!diag.golpes.length) toast('No se detectaron golpes. Revisa la ubicación de la cámara.');
  const s = { jugadorId: demo ? null : j.id, fecha: new Date().toISOString(), golpeId, golpeNombre: diag.golpeNombre, mano: j.mano || 'D', perfil: j, demo: !!demo, ancho: res.ancho, alto: res.alto,
    cuadros: res.cuadros, miniaturas: res.miniaturas || [], video: res.video || null, diag: limpiarDiag(diag),
    resumen: { puntaje: diag.puntaje, fallas: diag.fallas.slice(0, 3).map(f => f.titulo) } };
  await Datos.guardarSesion(s);
  ir('sesion', s.id);
}
function limpiarDiag(d) { return JSON.parse(JSON.stringify(d)); }

/* ---------- resultado ---------- */
async function pSesion() {
  const s = await Datos.sesion(V.arg);
  if (!s) { main('<div class="card"><p>No se encontró el análisis.</p></div>'); return; }
  const perfil = Datos.jugador(s.jugadorId) || s.perfil || {};
  const d = s.diag;
  const hist = s.jugadorId ? (await Datos.sesiones(s.jugadorId)).filter(x => x.golpeId === s.golpeId) : [];
  main(`<header class="cab"><button class="btn sm ghost" data-volver>←</button><h1>Resultado</h1></header>
    <div id="v3d" class="card v3d-caja"><p class="note">Preparando la animación 3D…</p></div>
    ${Informe.html(s, perfil, { conIA: true, historial: hist })}
    <div class="row acciones"><button class="btn" data-compartir>Compartir informe</button>${s.video ? '<button class="btn" data-ver-video>Ver video</button>' : ''}<button class="btn ghost peligro" data-borrar-sesion>Borrar</button></div>
    <div id="video-caja"></div>`);
  /* animación 3D lado a lado */
  try {
    const corr = Bio.corregir(s.cuadros, Ev.correcciones(d), s.mano);
    const errores = Ev.erroresPorCuadro(d, s.cuadros.length, s.mano);
    vista3d = await Vista3D.crear($('#v3d'), { original: s.cuadros, corregido: corr, errores, mano: s.mano, pelota: pelota3D(s),
      golpes: d.golpes.map(g => ({ n: g.n, inicio: g.golpe.inicio, impacto: g.golpe.impacto, fin: g.golpe.fin, puntaje: g.puntaje, info: [Pel.nombreFase(g.medidas.fase), g.medidas.paleta !== undefined ? 'paleta ' + Pel.nombrePaleta(g.medidas.paleta) : ''].filter(Boolean).join(' · ') })), cambios: Informe.cambios(d) });
  } catch (x) { $('#v3d').innerHTML = `<p class="note warn">No se pudo mostrar la animación 3D: ${e(x.message || x)}</p>`; }
  /* fotogramas del mejor y del peor golpe */
  const fotos = [];
  for (const [n, t] of [[d.peor, 'Golpe con más fallas'], [d.mejor, 'Mejor golpe']]) {
    if (!n) continue; const img = await Informe.fotograma(s, n, d).catch(() => null);
    if (img) fotos.push(`<figure><img src="${img}" alt="${t}"><figcaption>${t} (n.º ${n})</figcaption></figure>`);
  }
  const caja = $('#fotos'); if (caja) caja.innerHTML = fotos.join('') || '<p class="note">Sin fotogramas en este análisis.</p>';
  pSesion.fotos = fotos.join('');
}

/* Posición 3D de la pelota en cada cuadro, a partir de su posición en la imagen */
function pelota3D(s) {
  if (!s.ancho || !s.cuadros.some(c => c.b)) return null;
  const pista = Pel.rastrear(s.cuadros, s.ancho, s.alto), L = Bio.lados(s.mano);
  return s.cuadros.map((c, i) => {
    const p = pista[i]; if (!p || !c.esc || !c.n) return null;
    const cx = (c.n[23][0] + c.n[24][0]) / 2 * s.ancho, cy = (c.n[23][1] + c.n[24][1]) / 2 * s.alto;
    const cw = [(c.P[23][0] + c.P[24][0]) / 2, (c.P[23][1] + c.P[24][1]) / 2];
    return [cw[0] + (p[0] - cx) * c.esc, cw[1] - (p[1] - cy) * c.esc, c.P[L.m][2]];
  });
}

async function compartir(s) {
  const perfil = Datos.jugador(s.jugadorId) || s.perfil || {};
  const doc = Informe.documento(s, perfil, pSesion.fotos || '');
  const nombre = `informe-paleta-${(perfil.nombre || 'jugador').replace(/\W+/g, '-').toLowerCase()}-${s.fecha.slice(0, 10)}.html`;
  const C = window.Capacitor;
  if (C && C.isNativePlatform && C.isNativePlatform() && C.Plugins.Filesystem && C.Plugins.Share) {
    try {
      const r = await C.Plugins.Filesystem.writeFile({ path: nombre, data: doc, directory: 'CACHE', encoding: 'utf8' });
      await C.Plugins.Share.share({ title: 'Informe Paleta', files: [r.uri] });
      return;
    } catch (x) { if (/cancel/i.test(x && x.message)) return; }
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([doc], { type: 'text/html' })); a.download = nombre; a.click();
}

/* ---------- más ---------- */
function pMas() {
  const c = Datos.cfg();
  main(`<header class="cab"><h1>Más</h1></header>
    <div class="card"><h3>Modo</h3><p class="note">Ahora: <b>${c.modo === 'entrenador' ? 'Entrenador' : 'Jugador'}</b>. El modo entrenador maneja varios alumnos; el modo jugador, solo tu perfil.</p>
      <button class="btn" data-modo="${c.modo === 'entrenador' ? 'alumno' : 'entrenador'}">Cambiar a modo ${c.modo === 'entrenador' ? 'jugador' : 'entrenador'}</button></div>
    ${Upd.cardHTML()}
    <div class="card"><h3>Respaldo</h3><p class="note">Guarda los jugadores y los análisis (sin videos) para pasarlos a otro teléfono.</p>
      <div class="row"><button class="btn" data-respaldo>Descargar respaldo</button><label class="btn">Importar<input type="file" accept=".json,application/json" id="imp" hidden></label></div></div>
    <div class="card"><h3>Cómo funciona</h3><p>La app detecta 33 puntos del cuerpo en cada cuadro del video con un modelo de visión que corre en el teléfono, sin internet. Además sigue la pelota (por su color y su movimiento) y la paleta (por el color de las gomas junto a la mano): así mide el timing —si se golpea en la subida, en el punto más alto o en la bajada—, el ángulo de la cara de la paleta en el impacto y la velocidad de salida. Con ellos reconstruye el esqueleto en 3D, separa cada golpe por la velocidad de la mano y mide: flexión de rodillas, apoyo, traspaso de peso, giro de cadera y hombros, ángulo del codo, punto de impacto, dirección y largo del recorrido, terminación, brazo libre, estabilidad de la cabeza y recuperación.</p>
      <p>Cada medida se compara con un rango de referencia para ese golpe, ajustado a la edad, la estatura, la contextura, el nivel, el estilo y las gomas del jugador. La animación corregida es el mismo movimiento del jugador con esas medidas llevadas dentro del rango.</p>
      <p class="note">La pelota y la paleta se reconocen por color: con poca luz, pelota borrosa o fondo del mismo color pueden perderse. El ángulo de la paleta se mide en el plano de la cámara (mejor de lado) y el efecto de la pelota no se mide. Los rangos de referencia son orientativos.</p></div>
    <p class="note centro">Paleta · ${window.PALETA_WEB ? 'versión ' + window.PALETA_WEB : 'versión de desarrollo'}</p>`);
}

/* ---------- demostración ---------- */
/* Agrega a la demostración una cámara lateral simulada, la pelota (que se golpea demasiado temprano) y la paleta (algo abierta) */
function demoPelota(cuadros, mano) {
  const W = 1280, H = 720, esc = 0.0035, gr = 9.8, L = Bio.lados(mano);
  /* gira el esqueleto para que la cámara simulada lo vea de lado (el eje X del mundo coincide con el de la imagen, como en MediaPipe) */
  cuadros.forEach(c => { c.P = c.P.map(p => [-p[2], p[1], p[0]]); });
  cuadros.forEach(c => { c.esc = esc; c.n = c.P.map(p => [+((640 + p[0] / esc) / W).toFixed(4), +((420 - p[1] / esc) / H).toFixed(4)]); c.vista = { tipo: 'lado', cerca: mano === 'Z' ? 'I' : 'D', alturaCuerpo: 0.8 }; });
  for (const g of Bio.detectarGolpes(cuadros, mano)) {
    const tI = cuadros[g.impacto].t, w = cuadros[g.impacto].n[L.m];
    const fase = 0.5, tSube = 0.2, v = gr * tSube, dtC = fase * tSube, tB = tI - dtC;
    const cx = w[0] * W + 25, cy = w[1] * H - 10;
    const yB = cy + (v * dtC - 0.5 * gr * dtC * dtC) / esc, xB = cx + 0.3 / esc;
    const pos = t => {
      if (t < tB) { const d = tB - t; return [xB + 1.6 * d / esc, yB - (2.2 * d - 0.5 * gr * d * d) / esc]; }
      if (t <= tI) { const d = t - tB; return [xB + (cx - xB) * d / dtC, yB - (v * d - 0.5 * gr * d * d) / esc]; }
      const d = t - tI; return [cx + 7 * d / esc, cy - (2 * d - 0.5 * gr * d * d) / esc];
    };
    cuadros.forEach((c, i) => {
      if (Math.abs(c.t - tI) < 0.45) { const p = pos(c.t); if (p[0] > 0 && p[0] < W && p[1] > 0 && p[1] < H) c.b = [[+(p[0] / W).toFixed(4), +(p[1] / H).toFixed(4), 30]]; }
      if (Math.abs(i - g.impacto) <= 3) { const th = -8 * Math.PI / 180; c.pl = { x: +(cx / W).toFixed(4), y: +(cy / H).toFixed(4), a: +(Math.atan2(-Math.cos(th), Math.sin(th)) * 180 / Math.PI).toFixed(1), r: 0.3, cara: 'Roja', n: 200 }; }
    });
  }
  return { ancho: W, alto: H };
}
async function demo() {
  const perfil = Datos.activo() || { nombre: 'Jugador de demostración', mano: 'D', nivel: K.NIVELES[1], estilo: 'atacante_media', edad: 25, estatura: 175 };
  const cuadros = Bio.sintetico({ golpes: 10, rodillas: 172, codo: 160, giro: 20, brazoLibre: -0.1, mano: perfil.mano || 'D' });
  const dim = demoPelota(cuadros, perfil.mano || 'D');
  await analizar(Object.assign({ cuadros, miniaturas: [] }, dim), Object.assign({}, perfil, { nombre: perfil.nombre + ' (demostración)' }), 'top_d', true);
}

/* ---------- eventos ---------- */
document.addEventListener('click', async ev => {
  const t = ev.target.closest('[data-ir],[data-modo],[data-tab],[data-demo],[data-camara],[data-volver],[data-compartir],[data-borrar-sesion],[data-borrar-jugador],[data-respaldo],[data-ver-video],[data-a]');
  if (!t) return;
  const d = t.dataset;
  if (d.ir) { if (d.ir === 'ficha' && !d.arg) V.tab = 'datos'; if (d.ir === 'ficha' && d.arg && d.arg !== 'nuevo') V.tab = 'datos'; return ir(d.ir, d.arg); }
  if (d.modo) { Datos.setCfg({ modo: d.modo, activo: null }); return ir(d.modo === 'alumno' && !Datos.activo() ? 'ficha' : 'inicio', d.modo === 'alumno' && !Datos.activo() ? 'nuevo' : null); }
  if (d.tab) { V.tab = d.tab; return pintar(); }
  if ('demo' in d) return demo();
  if ('camara' in d) return abrirCamara();
  if ('volver' in d) return history.length > 1 && V.prev ? ir(V.prev) : ir('inicio');
  if (d.a === 'perfil-ia') return completarPerfil(t);
  const s = V.vista === 'sesion' ? await Datos.sesion(V.arg) : null;
  if ('compartir' in d && s) return compartir(s);
  if ('verVideo' in d && s && s.video) { $('#video-caja').innerHTML = `<video controls playsinline src="${URL.createObjectURL(s.video)}" class="video"></video>`; return; }
  if ('borrarSesion' in d && s) { if (confirm('¿Borrar este análisis?')) { await Datos.borrarSesion(s.id); ir('inicio'); } return; }
  if ('borrarJugador' in d) { const id = $('#ficha').dataset.id; if (id && confirm('¿Borrar al alumno y todos sus análisis?')) { Datos.borrarJugador(id); ir('jugadores'); } return; }
  if ('respaldo' in d) { const txt = await Datos.respaldo(); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'application/json' })); a.download = `respaldo-paleta-${new Date().toISOString().slice(0, 10)}.json`; a.click(); return; }
  if (d.a === 'ia' && s) {
    const est = $('#ia-estado'); t.disabled = true; est.textContent = 'Redactando con IA… (puede tardar hasta un minuto)';
    try { s.resumenIA = await Informe.redactarIA(s, Datos.jugador(s.jugadorId) || s.perfil || {}); await Datos.guardarSesion(s); ir('sesion', s.id); }
    catch (x) { est.textContent = 'No se pudo conectar con la IA (revisa internet). El informe de arriba se generó sin IA y está completo.'; t.disabled = false; }
  }
});
document.addEventListener('submit', ev => {
  if (ev.target.id !== 'ficha') return; ev.preventDefault();
  const datos = leerFicha(ev.target);
  if (!datos.perfilIA || !datos.perfilIA.trim()) datos.perfilIA = Perfil.describirLocal(datos, Ev);
  const j = Datos.guardarJugador(datos);
  Datos.setCfg({ activo: j.id }); toast('Guardado'); V.tab = 'datos'; ir('ficha', j.id);
});
document.addEventListener('change', async ev => {
  const t = ev.target;
  if (t.matches('[data-activo]')) { Datos.setCfg({ activo: t.value }); return pintar(); }
  if (t.matches('[data-rival]')) { V.rival = t.value; return pintar(); }
  if (t.name === 'estilo') { const d = $('#estilo-desc'); if (d) d.textContent = (K.ESTILOS.find(x => x.id === t.value) || {}).descripcion || ''; }
  if (t.id === 'g-archivo' && t.files[0]) return analizarArchivo(t.files[0]);
  if (t.id === 'imp' && t.files[0]) { try { const r = await Datos.importar(await t.files[0].text()); toast(`Importados ${r.jugadores} jugadores y ${r.sesiones} análisis.`); pintar(); } catch (x) { toast(x.message); } }
});
document.addEventListener('input', ev => { const t = ev.target; if (t.type === 'range' && t.name && t.name.startsWith('toma.')) { const b = document.getElementById('v-' + t.name.slice(5)); if (b) b.textContent = t.value; } });

/* botón atrás de Android */
try { window.Capacitor?.Plugins?.App?.addListener('backButton', () => { if (camara) return camara.cerrar(); if (V.vista !== 'inicio') return ir('inicio'); window.Capacitor.Plugins.App.exitApp(); }); } catch (x) { }

pintar();
Upd.init();

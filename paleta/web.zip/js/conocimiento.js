/* Paleta — base de conocimiento técnico del tenis de mesa.
   Golpes, rangos de referencia biomecánicos, fallas típicas con su corrección y ejercicios,
   estilos de juego, tomas, maderos, gomas y jugadas tácticas. Redacción propia.
   Unidades: ángulos en grados; distancias en "largos de torso" (hombros a caderas, unos 50 cm en un adulto). */
(function (raiz, fabrica) {
  const m = fabrica();
  if (typeof module === 'object' && module.exports) module.exports = m; else raiz.K = m;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- medidas que se evalúan ---------- */
  const METRICAS = {
    rodillas: { nombre: 'Flexión de rodillas', unidad: '°', grupo: 'Piernas y apoyo', zona: 'piernas', ayuda: 'Ángulo de la rodilla en el impacto (180° = pierna recta).' },
    apoyo: { nombre: 'Separación de pies', unidad: '× hombros', grupo: 'Piernas y apoyo', zona: 'pies', ayuda: 'Distancia entre tobillos dividida por el ancho de hombros.' },
    transferencia: { nombre: 'Traspaso de peso', unidad: 'torsos', grupo: 'Piernas y apoyo', zona: 'cadera', ayuda: 'Cuánto se desplaza la cadera hacia el golpe.' },
    giro: { nombre: 'Giro de hombros', unidad: '°', grupo: 'Tronco', zona: 'tronco', ayuda: 'Rotación de la línea de hombros durante el golpe.' },
    cadera: { nombre: 'Giro de caderas', unidad: '°', grupo: 'Tronco', zona: 'cadera', ayuda: 'Rotación de la cadera durante el golpe.' },
    codo: { nombre: 'Ángulo del codo', unidad: '°', grupo: 'Brazo', zona: 'codo', ayuda: 'Ángulo hombro-codo-muñeca en el impacto.' },
    impacto: { nombre: 'Punto de impacto', unidad: 'torsos', grupo: 'Brazo', zona: 'mano', ayuda: 'Cuánto por delante del cuerpo se golpea la pelota.' },
    angulo: { nombre: 'Dirección del swing', unidad: '°', grupo: 'Brazo', zona: 'mano', ayuda: 'Inclinación del recorrido: positivo hacia arriba, negativo hacia abajo.' },
    amplitud: { nombre: 'Largo del recorrido', unidad: 'torsos', grupo: 'Brazo', zona: 'mano', ayuda: 'Distancia que recorre la mano desde la preparación a la terminación.' },
    terminacion: { nombre: 'Altura de la terminación', unidad: 'torsos', grupo: 'Brazo', zona: 'mano', ayuda: 'Altura final de la mano respecto de la nariz (0 = altura de la nariz).' },
    muneca: { nombre: 'Uso de la muñeca', unidad: '°', grupo: 'Brazo', zona: 'muneca', ayuda: 'Cuánto se dobla la muñeca durante el golpe.' },
    brazoLibre: { nombre: 'Brazo libre', unidad: 'torsos', grupo: 'Equilibrio', zona: 'brazoLibre', ayuda: 'Altura de la mano libre respecto de la cadera en el impacto.' },
    cabeza: { nombre: 'Estabilidad de la cabeza', unidad: 'torsos', grupo: 'Equilibrio', zona: 'cabeza', ayuda: 'Cuánto se mueve la cabeza durante el golpe (menos es mejor).' },
    recuperacion: { nombre: 'Recuperación', unidad: 's', grupo: 'Recuperación', zona: 'mano', ayuda: 'Tiempo entre el impacto y el fin de la terminación.' },
    lanzamiento: { nombre: 'Altura del lanzamiento', unidad: 'cm', grupo: 'Saque', zona: 'brazoLibre', ayuda: 'Cuánto sube la mano libre al lanzar la pelota (el reglamento exige al menos 16 cm).' }
  };

  /* Articulaciones a marcar en rojo en la animación (D = lado que golpea, L = lado libre) */
  const ZONAS = {
    piernas: ['rodillaI', 'rodillaD', 'caderaI', 'caderaD'],
    pies: ['tobilloI', 'tobilloD', 'pieI', 'pieD'],
    cadera: ['caderaI', 'caderaD'],
    tronco: ['hombroI', 'hombroD', 'caderaI', 'caderaD'],
    codo: ['D:codo', 'D:hombro'],
    mano: ['D:muneca', 'D:codo'],
    muneca: ['D:muneca'],
    brazoLibre: ['L:muneca', 'L:codo'],
    cabeza: ['nariz']
  };

  /* ---------- fallas: título, por qué importa, cómo corregir y ejercicio ---------- */
  const FALLAS = {
    rodillas: {
      alto: { titulo: 'Piernas rígidas', porque: 'Con las rodillas casi estiradas el golpe sale solo del brazo: pierdes potencia, estabilidad y capacidad de llegar a pelotas bajas.', corregir: 'Flexiona las rodillas como si fueras a sentarte en un banco alto, con el peso en la parte delantera de los pies y los talones apenas apoyados.', ejercicio: 'Sombra con banca: 3 series de 20 golpes en el aire tocando con los glúteos el borde de una silla alta entre cada golpe.' },
      bajo: { titulo: 'Demasiado agachado', porque: 'Una flexión exagerada cansa rápido y vuelve lento el desplazamiento.', corregir: 'Sube un poco la cadera: rodillas flexionadas pero cómodas, de modo que puedas saltar hacia los lados con facilidad.', ejercicio: 'Desplazamiento lateral de 2 pasos durante 30 segundos manteniendo una altura constante.' }
    },
    apoyo: {
      bajo: { titulo: 'Pies muy juntos', porque: 'Con una base estrecha el equilibrio es pobre y el tronco no puede girar con fuerza.', corregir: 'Separa los pies un poco más que el ancho de hombros. En el derecho, el pie del lado que golpea queda levemente atrás.', ejercicio: 'Marca en el suelo con cinta la posición de los pies y practica 50 golpes sin salirte de las marcas.' },
      alto: { titulo: 'Apoyo demasiado abierto', porque: 'Con los pies muy separados cuesta moverse y recuperar la posición.', corregir: 'Acerca los pies: un poco más que el ancho de hombros es suficiente.', ejercicio: 'Pasos cortos de ajuste: después de cada golpe, da un pequeño salto de reajuste.' }
    },
    transferencia: {
      bajo: { titulo: 'Sin traspaso de peso', porque: 'Si el peso no pasa de una pierna a la otra, la fuerza de las piernas no llega a la pelota.', corregir: 'En el derecho, carga el peso en la pierna del lado que golpea durante la preparación y pásalo a la otra al golpear. En el revés, avanza levemente el peso hacia la mesa.', ejercicio: 'Sombra lenta exagerando el traspaso: levanta el talón de la pierna de atrás al terminar el golpe.' },
      alto: { titulo: 'Traspaso excesivo', porque: 'Te vas demasiado hacia adelante o al lado y quedas desequilibrado para el siguiente golpe.', corregir: 'Mantén el centro del cuerpo entre los pies al terminar el golpe.', ejercicio: 'Golpe y regreso: después de cada golpe vuelve a la posición de espera antes de que bote la pelota del rival.' }
    },
    giro: {
      bajo: { titulo: 'Poco giro de tronco', porque: 'El tronco es el motor del golpe. Sin giro, el brazo hace todo el trabajo, se cansa y se pierde control y potencia.', corregir: 'En la preparación gira la cintura y los hombros hacia atrás; al golpear, gíralos hacia adelante. El brazo acompaña el giro.', ejercicio: 'Sombra con la paleta pegada al pecho: practica solo el giro de hombros y caderas, 3 series de 20.' },
      alto: { titulo: 'Giro excesivo', porque: 'Un giro exagerado te deja de espaldas a la mesa y retrasa la recuperación.', corregir: 'Acorta la rotación: termina con el pecho mirando la dirección del golpe, sin pasarte.', ejercicio: 'Golpes en serie rápida (multibola) que obligan a recuperar antes.' }
    },
    cadera: {
      bajo: { titulo: 'Las caderas no participan', porque: 'Si solo giran los hombros, el golpe pierde la cadena piernas-cadera-tronco-brazo.', corregir: 'Inicia el golpe con la cadera: primero gira la cadera y luego los hombros.', ejercicio: 'Con una toalla en la cintura, practica sombra intentando que la toalla gire con el golpe.' },
      alto: { titulo: 'Exceso de giro de caderas', porque: 'Pierdes estabilidad y tardas en recuperar.', corregir: 'Mantén los pies firmes y gira lo justo.', ejercicio: 'Golpes alternando derecha e izquierda a ritmo alto.' }
    },
    codo: {
      bajo: { titulo: 'Codo demasiado cerrado', porque: 'Con el brazo muy doblado el golpe queda pegado al cuerpo, corto y sin aceleración.', corregir: 'Abre un poco el ángulo del codo (aproximadamente 90° a 120°) y aleja la pelota del cuerpo.', ejercicio: 'Sombra dejando el espacio de un puño entre el codo y el costado del cuerpo; luego 50 golpes en la mesa manteniendo ese espacio.' },
      alto: { titulo: 'Brazo demasiado estirado', porque: 'Con el brazo estirado pierdes control y la articulación sufre.', corregir: 'Mantén el codo flexionado y la pelota más cerca. Si te estiras, acércate con los pies en vez de estirar el brazo.', ejercicio: 'Multibola a distancia fija: el entrenador lanza siempre al mismo lugar y el jugador ajusta con los pies.' }
    },
    impacto: {
      bajo: { titulo: 'Impacto atrasado', porque: 'Si golpeas al lado o detrás del cuerpo, llegas tarde: menos control, menos potencia y más errores en la red.', corregir: 'Golpea la pelota delante del cuerpo. Adelanta la preparación y espera la pelota con la paleta lista.', ejercicio: 'Pon un cono a 40 cm delante de tu pie: la pelota debe golpearse a la altura del cono.' },
      alto: { titulo: 'Impacto demasiado adelante', porque: 'Al alcanzar la pelota muy lejos estiras el brazo y pierdes la fuerza del tronco.', corregir: 'Deja que la pelota llegue un poco más, o acércate con un paso.', ejercicio: 'Multibola con pausas: el jugador debe ubicarse antes de cada golpe.' }
    },
    angulo: {
      bajo: { titulo: 'Recorrido demasiado plano o hacia abajo', porque: 'Para este golpe la paleta debe subir más; un recorrido plano reduce el efecto y aumenta los errores en la red.', corregir: 'Prepara la paleta más abajo y termina más arriba: el recorrido va de abajo hacia adelante y arriba.', ejercicio: 'Sombra junto a una pared marcando con cinta el punto bajo de inicio y el alto de término.' },
      alto: { titulo: 'Recorrido demasiado vertical', porque: 'Si la paleta solo sube, la pelota sale sin velocidad y alta.', corregir: 'Dirige más el golpe hacia adelante, hacia la mesa del rival.', ejercicio: 'Golpes buscando que la pelota bote en la mitad del campo rival.' }
    },
    amplitud: {
      bajo: { titulo: 'Recorrido corto', porque: 'Sin espacio para acelerar la paleta, el golpe pierde velocidad y efecto.', corregir: 'Prepara un poco más atrás y termina el golpe completo.', ejercicio: 'Sombra con un elástico atado a la muñeca para sentir la preparación completa.' },
      alto: { titulo: 'Recorrido demasiado largo', porque: 'Un golpe largo es lento de preparar y no te deja recuperar a tiempo.', corregir: 'Acorta la preparación y la terminación; la velocidad viene del giro, no del largo del brazo.', ejercicio: 'Peloteo rápido cerca de la mesa (contraataque) 2 minutos sin parar.' }
    },
    terminacion: {
      bajo: { titulo: 'Terminación baja', porque: 'Cortar el golpe antes de tiempo frena la paleta en el impacto.', corregir: 'Termina el golpe arriba: en el derecho, cerca de la frente; en el revés, delante del hombro.', ejercicio: 'Sombra marcando con la mano libre el punto de término del golpe.' },
      alto: { titulo: 'Terminación demasiado alta', porque: 'Una terminación por encima de la cabeza suele indicar que el golpe se fue hacia arriba y no hacia adelante.', corregir: 'Termina a la altura de la frente o los ojos, dirigiendo el golpe hacia adelante.', ejercicio: 'Golpes buscando una trayectoria más tensa sobre la red.' }
    },
    muneca: {
      alto: { titulo: 'Exceso de muñeca', porque: 'Mover mucho la muñeca hace el golpe irregular; en golpes de control y bloqueos genera errores.', corregir: 'Mantén la muñeca firme y que el movimiento salga del antebrazo y del tronco.', ejercicio: 'Peloteo con una muñequera ajustada para sentir la muñeca estable.' },
      bajo: { titulo: 'Muñeca rígida', porque: 'En este golpe la muñeca aporta efecto y sorpresa.', corregir: 'Relaja la mano y deja que la muñeca acompañe al final del golpe.', ejercicio: 'Flicks y saques con pelotas en multibola, buscando el sonido de roce.' }
    },
    brazoLibre: {
      bajo: { titulo: 'Brazo libre caído', porque: 'El brazo libre equilibra el cuerpo y ayuda al giro. Si cuelga, el giro es menor y el equilibrio peor.', corregir: 'Mantén la mano libre delante del cuerpo, a la altura del pecho o del codo, como si sostuvieras una bandeja.', ejercicio: 'Practica sombra sosteniendo una pelota en la mano libre a la altura del pecho.' }
    },
    cabeza: {
      alto: { titulo: 'La cabeza se mueve mucho', porque: 'Si la cabeza sube, baja o se desplaza, la vista pierde la pelota y el golpe se vuelve irregular.', corregir: 'Mantén la cabeza estable y la mirada en la pelota hasta el impacto.', ejercicio: 'Peloteo mirando el logo de la pelota hasta que toque la paleta.' }
    },
    recuperacion: {
      alto: { titulo: 'Recuperación lenta', porque: 'Si tardas en volver a la posición de espera, llegas tarde a la siguiente pelota.', corregir: 'Termina el golpe y vuelve de inmediato a la posición neutral con la paleta delante.', ejercicio: 'Multibola rápida: 20 pelotas seguidas a 1 por segundo.' }
    },
    lanzamiento: {
      bajo: { titulo: 'Lanzamiento demasiado bajo', porque: 'El reglamento exige lanzar la pelota casi vertical y al menos 16 cm. Un árbitro puede marcar falta.', corregir: 'Lanza desde la palma abierta, quieta, y que la pelota suba al menos 16 cm (más o menos el alto de la red sumado a un palmo).', ejercicio: 'Lanza la pelota frente a una pared con una marca a 20 cm por encima de tu mano; 30 lanzamientos sin golpear.' }
    },
    regularidad: {
      alto: { titulo: 'Golpes irregulares', porque: 'Cada golpe sale distinto: el punto de impacto o el ángulo del brazo cambian mucho de un golpe a otro.', corregir: 'Busca repetir el mismo movimiento: misma preparación, mismo punto de impacto delante del cuerpo y misma terminación.', ejercicio: 'Series de 30 golpes al mismo lugar contando cuántos seguidos sin fallar.' }
    }
  };

  /* ---------- golpes ---------- */
  /* ref: rangos para un jugador intermedio. Los ajusta el perfil del jugador (nivel, estilo, edad, gomas). */
  const R = (o) => o;
  const BASE_TOP_D = R({ rodillas: [118, 155], apoyo: [1.25, 2.0], transferencia: [0.06, 0.7], giro: [38, 100], cadera: [15, 75], codo: [95, 145], impacto: [0.35, 1.4], angulo: [28, 68], amplitud: [1.9, 4.4], terminacion: [-0.3, 0.4], muneca: [0, 50], brazoLibre: [0.3, 1.2], cabeza: [0, 0.45], recuperacion: [0, 0.38] });
  const BASE_DRIVE_D = R({ rodillas: [122, 160], apoyo: [1.15, 1.95], transferencia: [0.03, 0.55], giro: [28, 75], cadera: [8, 55], codo: [88, 128], impacto: [0.45, 1.35], angulo: [4, 30], amplitud: [1.2, 3.1], terminacion: [-0.5, 0.12], muneca: [0, 32], brazoLibre: [0.3, 1.2], cabeza: [0, 0.38], recuperacion: [0, 0.32] });
  const BASE_DRIVE_R = R({ rodillas: [122, 160], apoyo: [1.05, 1.9], transferencia: [0.0, 0.45], giro: [8, 42], cadera: [0, 32], codo: [78, 122], impacto: [0.45, 1.3], angulo: [3, 32], amplitud: [0.8, 2.5], terminacion: [-0.7, 0.05], muneca: [0, 40], cabeza: [0, 0.38], recuperacion: [0, 0.3] });
  const BASE_TOP_R = R({ rodillas: [118, 156], apoyo: [1.05, 1.9], transferencia: [0.02, 0.5], giro: [12, 55], cadera: [0, 40], codo: [70, 132], impacto: [0.45, 1.35], angulo: [25, 72], amplitud: [1.2, 3.2], terminacion: [-0.45, 0.3], muneca: [10, 85], cabeza: [0, 0.42], recuperacion: [0, 0.35] });
  const BASE_PUSH = R({ rodillas: [125, 165], apoyo: [0.95, 1.85], giro: [0, 30], codo: [88, 145], impacto: [0.6, 1.6], angulo: [-50, -5], amplitud: [0.4, 1.9], terminacion: [-1.3, -0.35], muneca: [0, 42], cabeza: [0, 0.35], recuperacion: [0, 0.42] });
  const BASE_BLOQUEO = R({ rodillas: [125, 162], apoyo: [1.0, 1.9], giro: [0, 28], codo: [85, 132], impacto: [0.55, 1.4], angulo: [-14, 22], amplitud: [0.15, 1.05], terminacion: [-1.0, -0.15], muneca: [0, 25], cabeza: [0, 0.3], recuperacion: [0, 0.25] });
  const BASE_FLICK = R({ rodillas: [122, 162], apoyo: [0.9, 1.9], giro: [0, 40], codo: [70, 135], impacto: [0.75, 1.7], angulo: [12, 62], amplitud: [0.35, 1.5], terminacion: [-0.9, 0.1], muneca: [15, 95], cabeza: [0, 0.4], recuperacion: [0, 0.35] });
  const BASE_CORTE = R({ rodillas: [112, 152], apoyo: [1.2, 2.1], giro: [10, 60], codo: [95, 165], impacto: [-0.1, 1.0], angulo: [-72, -18], amplitud: [1.4, 3.8], terminacion: [-1.6, -0.45], muneca: [0, 45], cabeza: [0, 0.45], recuperacion: [0, 0.5] });
  const BASE_SAQUE = R({ rodillas: [110, 160], apoyo: [1.0, 2.1], giro: [5, 70], impacto: [0.2, 1.4], amplitud: [0.3, 2.4], muneca: [20, 130], cabeza: [0, 0.45], lanzamiento: [16, 500] });
  const mezcla = (a, b) => Object.assign({}, a, b);

  const GOLPES = [
    /* Ataque */
    { id: 'drive_d', nombre: 'Drive de derecho', grupo: 'Ataque', lado: 'derecho', tipos: ['drive', 'topspin'], ref: BASE_DRIVE_D,
      descripcion: 'Golpe básico de ataque, plano con leve efecto liftado, cerca de la mesa.', claves: ['Pelota en la parte alta del bote', 'Giro de cintura, codo a unos 100°', 'Termina frente a la frente o los ojos', 'Vuelve a la posición de espera'] },
    { id: 'drive_r', nombre: 'Drive de revés', grupo: 'Ataque', lado: 'reves', tipos: ['drive', 'topspin', 'bloqueo'], ref: BASE_DRIVE_R,
      descripcion: 'Golpe de revés activo, delante del cuerpo, con el codo como eje.', claves: ['Paleta delante del abdomen', 'El codo adelantado sirve de bisagra', 'Antebrazo hacia adelante y arriba', 'Termina delante del hombro'] },
    { id: 'top_d', nombre: 'Topspin de derecho contra bloqueo', grupo: 'Ataque', lado: 'derecho', tipos: ['topspin', 'drive'], ref: BASE_TOP_D,
      descripcion: 'Golpe con mucho efecto liftado contra una pelota sin efecto o con efecto liftado.', claves: ['Preparación con el peso en la pierna de atrás', 'Golpe hacia adelante y arriba', 'Roce fino y acelerado', 'Termina a la altura de la frente'] },
    { id: 'top_d_corte', nombre: 'Topspin de derecho contra corte', grupo: 'Ataque', lado: 'derecho', tipos: ['topspin'], ref: mezcla(BASE_TOP_D, { angulo: [40, 78], rodillas: [112, 150], terminacion: [-0.1, 0.6], impacto: [0.2, 1.2] }),
      descripcion: 'Topspin para levantar una pelota cortada (con efecto bajo). El recorrido es más vertical.', claves: ['Baja más el cuerpo y la paleta', 'Golpea en la bajada o el punto alto', 'Recorrido más vertical', 'Usa las piernas para subir'] },
    { id: 'top_r', nombre: 'Topspin de revés', grupo: 'Ataque', lado: 'reves', tipos: ['topspin', 'drive'], ref: BASE_TOP_R,
      descripcion: 'Topspin de revés delante del cuerpo con antebrazo y muñeca.', claves: ['Paleta baja entre las rodillas', 'Codo adelante', 'Antebrazo y muñeca hacia adelante y arriba', 'Piernas ayudan a subir'] },
    { id: 'contra_top_d', nombre: 'Contra-topspin de derecho', grupo: 'Ataque', lado: 'derecho', tipos: ['topspin', 'drive'], ref: mezcla(BASE_TOP_D, { angulo: [14, 50], apoyo: [1.35, 2.2], amplitud: [2.0, 4.8] }),
      descripcion: 'Topspin contra un topspin del rival, normalmente a media distancia.', claves: ['Más distancia de la mesa', 'Golpe más hacia adelante', 'Apoyo amplio y estable', 'Golpea en el punto alto o la bajada temprana'] },
    { id: 'contra_top_r', nombre: 'Contra-topspin de revés', grupo: 'Ataque', lado: 'reves', tipos: ['topspin', 'drive'], ref: mezcla(BASE_TOP_R, { angulo: [10, 50] }),
      descripcion: 'Respuesta de revés con efecto liftado ante un topspin.', claves: ['Cierra la paleta', 'Golpe corto y hacia adelante', 'Codo como eje'] },
    { id: 'remate_d', nombre: 'Remate de derecho', grupo: 'Ataque', lado: 'derecho', tipos: ['remate', 'drive'], ref: mezcla(BASE_DRIVE_D, { codo: [105, 165], giro: [40, 110], angulo: [-28, 12], amplitud: [1.8, 4.8], terminacion: [-0.8, 0.2] }),
      descripcion: 'Golpe plano y potente contra una pelota alta.', claves: ['Espera la pelota en su punto más alto', 'Gira todo el cuerpo', 'Golpe plano hacia adelante y abajo', 'Paleta cerrada'] },
    { id: 'remate_r', nombre: 'Remate de revés', grupo: 'Ataque', lado: 'reves', tipos: ['remate', 'drive'], ref: mezcla(BASE_DRIVE_R, { codo: [95, 160], angulo: [-25, 12], amplitud: [1.0, 3.0] }),
      descripcion: 'Golpe de revés plano contra pelota alta.', claves: ['Codo adelante', 'Extiende el antebrazo con fuerza', 'Golpe plano'] },
    /* Control y mesa corta */
    { id: 'push_d', nombre: 'Corte corto (push) de derecho', grupo: 'Control', lado: 'derecho', tipos: ['push', 'bloqueo'], ref: BASE_PUSH,
      descripcion: 'Devolución con efecto bajo sobre la mesa.', claves: ['Pie del lado que golpea bajo la mesa', 'Paleta abierta', 'Corta por debajo de la pelota hacia adelante', 'Golpe corto y controlado'] },
    { id: 'push_r', nombre: 'Corte corto (push) de revés', grupo: 'Control', lado: 'reves', tipos: ['push', 'bloqueo'], ref: BASE_PUSH,
      descripcion: 'Push de revés sobre la mesa, el más usado en recepción.', claves: ['Paleta abierta delante del cuerpo', 'Codo como eje', 'Corta hacia adelante, no hacia abajo'] },
    { id: 'dejada', nombre: 'Dejada (pelota corta)', grupo: 'Control', lado: 'ambos', tipos: ['bloqueo', 'push'], ref: mezcla(BASE_PUSH, { amplitud: [0.1, 0.9], angulo: [-35, 12], terminacion: [-1.4, -0.4] }),
      descripcion: 'Devolución muy corta que bota dos veces en el campo rival.', claves: ['Toque suave, absorbiendo la velocidad', 'Golpea temprano', 'Casi sin recorrido'] },
    { id: 'bloqueo_d', nombre: 'Bloqueo de derecho', grupo: 'Control', lado: 'derecho', tipos: ['bloqueo', 'drive'], ref: BASE_BLOQUEO,
      descripcion: 'Devolución corta y temprana del ataque rival, usando su velocidad.', claves: ['Paleta cerrada', 'Golpe temprano, justo después del bote', 'Casi sin recorrido', 'Brazo firme'] },
    { id: 'bloqueo_r', nombre: 'Bloqueo de revés', grupo: 'Control', lado: 'reves', tipos: ['bloqueo', 'drive'], ref: BASE_BLOQUEO,
      descripcion: 'Bloqueo de revés delante del cuerpo.', claves: ['Paleta delante del cuerpo', 'Ángulo de paleta según el efecto', 'Empuja levemente hacia adelante'] },
    { id: 'bloqueo_activo', nombre: 'Bloqueo activo / punch', grupo: 'Control', lado: 'ambos', tipos: ['bloqueo', 'drive'], ref: mezcla(BASE_BLOQUEO, { amplitud: [0.5, 1.5], angulo: [-8, 25] }),
      descripcion: 'Bloqueo con empuje hacia adelante para devolver con velocidad.', claves: ['Recorrido corto hacia adelante', 'Golpe en la subida', 'Usa el antebrazo'] },
    { id: 'flick_d', nombre: 'Flick de derecho', grupo: 'Mesa corta', lado: 'derecho', tipos: ['flick', 'drive', 'bloqueo'], ref: BASE_FLICK,
      descripcion: 'Ataque a una pelota corta sobre la mesa.', claves: ['Pie bajo la mesa', 'Pelota en el punto alto', 'Muñeca hacia adelante y arriba'] },
    { id: 'flick_r', nombre: 'Flick de revés / banana flick (chiquita)', grupo: 'Mesa corta', lado: 'reves', tipos: ['flick', 'topspin', 'bloqueo'], ref: BASE_FLICK,
      descripcion: 'Ataque de revés sobre la mesa, con la muñeca envolviendo la pelota.', claves: ['Codo alto y adelante', 'Muñeca doblada hacia ti en la preparación', 'Roza el costado de la pelota', 'Termina hacia adelante'] },
    /* Defensa */
    { id: 'corte_d', nombre: 'Corte defensivo de derecho', grupo: 'Defensa', lado: 'derecho', tipos: ['corte_defensivo', 'push'], ref: BASE_CORTE,
      descripcion: 'Defensa con efecto bajo lejos de la mesa contra un topspin.', claves: ['Lejos de la mesa', 'Paleta alta en la preparación', 'Corta de arriba hacia abajo y adelante', 'Golpea la pelota en la bajada'] },
    { id: 'corte_r', nombre: 'Corte defensivo de revés', grupo: 'Defensa', lado: 'reves', tipos: ['corte_defensivo', 'push'], ref: BASE_CORTE,
      descripcion: 'Corte defensivo de revés lejos de la mesa.', claves: ['Paleta a la altura del hombro', 'Pie del lado del revés atrás', 'Corta hacia abajo y adelante', 'Recupera hacia el centro'] },
    { id: 'globo', nombre: 'Globo (lob) y fish', grupo: 'Defensa', lado: 'ambos', tipos: ['globo', 'topspin'], ref: mezcla(BASE_TOP_D, { angulo: [32, 85], amplitud: [1.8, 4.8], terminacion: [-0.2, 0.9], impacto: [-0.2, 1.0] }),
      descripcion: 'Devolución alta y profunda con efecto liftado lejos de la mesa.', claves: ['Golpe largo hacia arriba', 'Busca el fondo de la mesa', 'Mucho efecto'] },
    /* Saques */
    { id: 'saque_pendular', nombre: 'Saque pendular de derecho', grupo: 'Saque', lado: 'derecho', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: BASE_SAQUE, saque: true,
      descripcion: 'Saque de derecho con movimiento de péndulo de la muñeca, el más usado en competencia.', claves: ['Lanzamiento vertical de al menos 16 cm', 'Contacto bajo, cerca de la altura de la red', 'Muñeca rápida', 'Disimula el efecto con el mismo movimiento'] },
    { id: 'saque_reverso', nombre: 'Saque pendular reverso', grupo: 'Saque', lado: 'derecho', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: BASE_SAQUE, saque: true,
      descripcion: 'Variante del pendular que da efecto lateral contrario.', claves: ['Codo alto', 'La muñeca gira hacia afuera', 'Contacto bajo', 'Lanzamiento reglamentario'] },
    { id: 'saque_tomahawk', nombre: 'Saque tomahawk y tomahawk reverso', grupo: 'Saque', lado: 'derecho', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: BASE_SAQUE, saque: true,
      descripcion: 'Saque con la paleta vertical y la punta hacia arriba.', claves: ['Paleta vertical', 'Contacto en el lado de la pelota', 'Lanzamiento reglamentario'] },
    { id: 'saque_gancho', nombre: 'Saque de gancho', grupo: 'Saque', lado: 'derecho', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: BASE_SAQUE, saque: true,
      descripcion: 'Saque de derecho con el cuerpo de lado y la paleta en forma de gancho.', claves: ['Cuerpo de lado a la mesa', 'Codo alto', 'Lanzamiento reglamentario'] },
    { id: 'saque_cuclillas', nombre: 'Saque en cuclillas', grupo: 'Saque', lado: 'ambos', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: mezcla(BASE_SAQUE, { rodillas: [70, 140] }), saque: true,
      descripcion: 'Saque que se golpea agachándose en el momento del contacto.', claves: ['Se baja rápido en el contacto', 'Paleta vertical', 'Vuelve rápido a la posición'] },
    { id: 'saque_reves', nombre: 'Saque de revés', grupo: 'Saque', lado: 'reves', tipos: ['push', 'drive', 'bloqueo', 'flick', 'topspin'], ref: BASE_SAQUE, saque: true,
      descripcion: 'Saque con el revés desde el centro de la mesa.', claves: ['Cuerpo de frente a la mesa', 'Codo adelante', 'Muñeca rápida', 'Lanzamiento reglamentario'] },
    /* Desplazamientos y ejercicios combinados */
    { id: 'falkenberg', nombre: 'Ejercicio Falkenberg (revés, derecho desde el revés, derecho cruzado)', grupo: 'Desplazamiento', lado: 'ambos', tipos: ['drive', 'topspin', 'bloqueo'], ref: mezcla(BASE_TOP_D, { giro: [20, 100], amplitud: [0.9, 4.4], terminacion: [-0.7, 0.4], angulo: [3, 68] }), desplazamiento: true,
      descripcion: 'Secuencia clásica que obliga a pivotar y cruzar la mesa.', claves: ['Pasos cortos y rápidos', 'Pivote: el pie del derecho va atrás', 'Llega antes que la pelota', 'Siempre vuelve al centro'] },
    { id: 'lateral', nombre: 'Desplazamiento lateral (derecho en dos puntos)', grupo: 'Desplazamiento', lado: 'derecho', tipos: ['drive', 'topspin'], ref: mezcla(BASE_TOP_D, { angulo: [3, 68], amplitud: [1.2, 4.4] }), desplazamiento: true,
      descripcion: 'Derechos alternando dos puntos de la mesa con pasos laterales.', claves: ['Paso lateral sin cruzar los pies', 'Cuerpo bajo durante el desplazamiento', 'Golpe con los pies ya ubicados'] },
    { id: 'libre', nombre: 'Juego libre / peloteo mixto', grupo: 'Desplazamiento', lado: 'ambos', tipos: ['drive', 'topspin', 'bloqueo', 'push', 'flick', 'remate', 'corte_defensivo', 'globo'], ref: {}, libre: true,
      descripcion: 'Graba un peloteo libre: la app identifica cada golpe y lo evalúa según su tipo.', claves: ['Graba al menos 45 segundos', 'Cuerpo completo en la imagen'] }
  ];

  /* Referencias para el juego libre según el tipo detectado y el lado */
  function refPorTipo(tipo, lado) {
    const d = lado !== 'reves';
    switch (tipo) {
      case 'topspin': return d ? BASE_TOP_D : BASE_TOP_R;
      case 'drive': return d ? BASE_DRIVE_D : BASE_DRIVE_R;
      case 'remate': return d ? GOLPES.find(g => g.id === 'remate_d').ref : GOLPES.find(g => g.id === 'remate_r').ref;
      case 'push': return BASE_PUSH;
      case 'bloqueo': return BASE_BLOQUEO;
      case 'flick': return BASE_FLICK;
      case 'corte_defensivo': return BASE_CORTE;
      case 'globo': return GOLPES.find(g => g.id === 'globo').ref;
      default: return d ? BASE_DRIVE_D : BASE_DRIVE_R;
    }
  }
  const NOMBRE_TIPO = { topspin: 'topspin', drive: 'drive', remate: 'remate', push: 'corte corto', bloqueo: 'bloqueo', flick: 'flick', corte_defensivo: 'corte defensivo', globo: 'globo' };

  /* ---------- estilos de juego ---------- */
  const ESTILOS = [
    { id: 'atacante_cerca', nombre: 'Atacante cerca de la mesa', descripcion: 'Juega rápido, en la subida, con golpes cortos y mucha iniciativa (estilo chino moderno).', ajuste: { amplitud: 0.88, recuperacion: 0.85 }, golpesClave: ['top_d', 'drive_r', 'flick_r', 'bloqueo_r', 'saque_pendular'] },
    { id: 'atacante_media', nombre: 'Atacante de media distancia (topspinero)', descripcion: 'Topspin potente a 1–2 m de la mesa, con mucho efecto y contra-topspin.', ajuste: { amplitud: 1.15, impacto: -0.15, rodillas: -4 }, golpesClave: ['top_d', 'contra_top_d', 'top_r', 'top_d_corte', 'lateral'] },
    { id: 'allround', nombre: 'Todo terreno (all-round)', descripcion: 'Combina ataque y control según la situación; cambia el ritmo.', ajuste: {}, golpesClave: ['drive_d', 'drive_r', 'push_r', 'top_d', 'bloqueo_r'] },
    { id: 'contraatacante', nombre: 'Contraatacante / bloqueador', descripcion: 'Juega cerca de la mesa usando la velocidad del rival con bloqueos y contragolpes.', ajuste: { amplitud: 0.85 }, golpesClave: ['bloqueo_r', 'bloqueo_d', 'bloqueo_activo', 'drive_d', 'drive_r'] },
    { id: 'defensor_clasico', nombre: 'Defensor clásico (cortador)', descripcion: 'Juega lejos con cortes defensivos y espera el error del rival.', ajuste: {}, golpesClave: ['corte_d', 'corte_r', 'push_r', 'globo'] },
    { id: 'defensor_moderno', nombre: 'Defensor moderno', descripcion: 'Corta lejos de la mesa pero ataca con topspin cuando aparece la ocasión.', ajuste: {}, golpesClave: ['corte_r', 'corte_d', 'top_d', 'top_d_corte'] },
    { id: 'pips_cortos', nombre: 'Atacante con pips cortos', descripcion: 'Golpes planos y rápidos, golpea en la subida.', ajuste: {}, golpesClave: ['drive_d', 'remate_d', 'bloqueo_activo'] },
    { id: 'pips_largos', nombre: 'Jugador con pips largos o antitopspin', descripcion: 'Usa la goma con pips largos para devolver efectos invertidos y desordenar al rival.', ajuste: {}, golpesClave: ['bloqueo_r', 'push_r', 'corte_r'] },
    { id: 'lapicero_chino', nombre: 'Lapicero (penhold) con revés invertido', descripcion: 'Toma de lapicero con golpes de revés con la otra cara de la paleta.', ajuste: {}, golpesClave: ['top_d', 'top_r', 'flick_r'] },
    { id: 'lapicero_tradicional', nombre: 'Lapicero tradicional (una cara)', descripcion: 'Toma de lapicero bloqueando y empujando de revés con la misma cara.', ajuste: {}, golpesClave: ['drive_d', 'bloqueo_r', 'remate_d'] }
  ];

  /* ---------- tomas ---------- */
  const TOMAS = [
    { id: 'sh_neutra', nombre: 'Clásica (shakehand) neutra' },
    { id: 'sh_derecho', nombre: 'Clásica cargada al derecho (paleta inclinada hacia el derecho)' },
    { id: 'sh_reves', nombre: 'Clásica cargada al revés' },
    { id: 'pen_china', nombre: 'Lapicero china' },
    { id: 'pen_japonesa', nombre: 'Lapicero japonesa / coreana' },
    { id: 'seemiller', nombre: 'Seemiller' }
  ];
  const PREGUNTAS_TOMA = [
    { id: 'indice', texto: '¿Dónde apoyas el dedo índice?', tipo: 'opciones', opciones: ['Sobre la goma del revés, en el borde', 'En el centro de la goma', 'Detrás, envolviendo el mango', 'No sé'] },
    { id: 'pulgar', texto: '¿Dónde queda el pulgar?', tipo: 'opciones', opciones: ['Relajado junto al mango, sobre la goma del derecho', 'Muy arriba, sobre la goma', 'Apretando el costado del mango', 'No sé'] },
    { id: 'presion', texto: '¿Qué tan fuerte aprietas la paleta? (1 = muy suelta, 10 = muy apretada)', tipo: 'rango', min: 1, max: 10 },
    { id: 'cambia', texto: '¿Cambias la toma entre derecho y revés?', tipo: 'opciones', opciones: ['No', 'Un poco', 'Sí, bastante'] },
    { id: 'espacio', texto: '¿Hay espacio entre la palma y el mango?', tipo: 'opciones', opciones: ['Sí, la paleta no toca la palma', 'No, la palma está pegada al mango'] },
    { id: 'dolor', texto: '¿Sientes molestias en muñeca, codo u hombro al jugar?', tipo: 'opciones', opciones: ['No', 'A veces', 'Sí, seguido'] }
  ];

  /* ---------- materiales ---------- */
  const MADEROS = {
    composicion: ['5 capas de madera', '7 capas de madera', 'Carbono exterior', 'Carbono interior', 'Arilato-carbono (ALC/ZLC) exterior', 'Arilato-carbono (ALC/ZLC) interior', 'Otro / no sé'],
    velocidad: ['DEF (defensa)', 'ALL (todo terreno)', 'OFF- (ofensivo lento)', 'OFF (ofensivo)', 'OFF+ (muy ofensivo)', 'No sé'],
    mango: ['Anatómico (AN)', 'Cóncavo (FL)', 'Recto (ST)', 'Lapicero chino (CS)', 'Lapicero japonés (JS)', 'Otro']
  };
  const GOMAS = {
    tipo: ['Lisa tensor (europea/japonesa)', 'Lisa clásica sin tensor', 'China pegajosa (tacky)', 'Híbrida (pegajosa con tensor)', 'Pips cortos', 'Pips medios', 'Pips largos', 'Antitopspin', 'No sé'],
    esponja: ['Sin esponja (OX)', '0,5–1,0 mm', '1,5 mm', '1,8 mm', '2,0 mm', '2,1–2,2 mm / máx', 'No sé'],
    dureza: ['Blanda (menos de 40°)', 'Media (40–45°)', 'Dura (46–50°)', 'Muy dura (más de 50°)', 'No sé'],
    color: ['Negra', 'Roja', 'Rosada', 'Verde', 'Azul', 'Morada', 'Otro']
  };
  const NIVELES = ['Principiante (menos de 1 año)', 'Intermedio (1 a 3 años)', 'Avanzado / competidor', 'Alto rendimiento'];
  const CONTEXTURAS = ['Delgada', 'Media', 'Atlética', 'Robusta'];

  /* ---------- jugadas tácticas ---------- */
  /* estilos: para quién; contra: tipo de rival. */
  const RIVALES = [
    { id: 'topspinero', nombre: 'Topspinero de derecho fuerte' },
    { id: 'revesista', nombre: 'Rival con revés fuerte y derecho débil' },
    { id: 'bloqueador', nombre: 'Bloqueador cerca de la mesa' },
    { id: 'cortador', nombre: 'Defensor cortador' },
    { id: 'pips_largos', nombre: 'Rival con pips largos' },
    { id: 'pips_cortos', nombre: 'Rival con pips cortos (golpes planos)' },
    { id: 'lapicero', nombre: 'Lapicero (penhold)' },
    { id: 'zurdo', nombre: 'Rival zurdo (si tú eres diestro) o diestro (si eres zurdo)' },
    { id: 'alto_lento', nombre: 'Rival alto o de poca movilidad' },
    { id: 'rapido_bajo', nombre: 'Rival rápido y bajo, muy cerca de la mesa' },
    { id: 'principiante', nombre: 'Rival de menor nivel (consistente pero sin ataque)' }
  ];

  const JUGADAS = [
    { id: 'j1', nombre: 'Saque corto cortado al revés + tercera bola al codo', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'lapicero_chino'], contra: ['topspinero', 'bloqueador', 'lapicero', 'alto_lento'],
      objetivo: 'Obligar a un push largo y atacar al punto donde el rival duda entre derecho y revés.', pasos: ['Saca corto y cortado al revés del rival (dos botes si se pudiera).', 'Si devuelve largo, topspin de derecho fuerte al codo del lado del derecho (el "punto de cruce").', 'Si devuelve corto, flick o push corto a su derecho para abrirle la mesa.', 'Cuarta bola: bloqueo activo al lado contrario de donde quedó.'] },
    { id: 'j2', nombre: 'Saque largo rápido sin efecto al revés + bloqueo a la paralela', estilos: ['contraatacante', 'atacante_cerca', 'pips_cortos', 'lapicero_tradicional'], contra: ['cortador', 'pips_largos', 'alto_lento', 'principiante'],
      objetivo: 'Sorprender y forzar una devolución alta o desequilibrada.', pasos: ['Saque rápido y largo, sin efecto, a la esquina del revés.', 'Prepárate para una devolución bloqueada al centro.', 'Golpe plano o bloqueo activo a la paralela del derecho.'] },
    { id: 'j3', nombre: 'Push largo a la esquina del revés y ataque al centro', estilos: ['allround', 'defensor_moderno', 'atacante_media'], contra: ['revesista', 'rapido_bajo'],
      objetivo: 'Negar el revés fuerte del rival y atacar su punto de cruce.', pasos: ['Recibe con push largo, rápido y bajo a la esquina del revés del rival.', 'Si te ataca al centro, bloqueo cruzado a su derecho.', 'Ante la primera pelota alta o lenta, topspin al codo.'] },
    { id: 'j4', nombre: 'Cambio de ritmo: topspin lento con mucho efecto + topspin rápido', estilos: ['atacante_media', 'allround', 'defensor_moderno'], contra: ['bloqueador', 'pips_cortos', 'rapido_bajo'],
      objetivo: 'Quitarle el ritmo al bloqueador, que juega mejor contra pelotas rápidas.', pasos: ['Primer topspin lento, con mucho efecto y profundo.', 'El bloqueo saldrá más alto o más lento.', 'Segundo topspin rápido y plano a la esquina contraria.'] },
    { id: 'j5', nombre: 'Contra cortador: topspin lento al centro y remate', estilos: ['atacante_media', 'atacante_cerca', 'allround', 'lapicero_chino'], contra: ['cortador'],
      objetivo: 'Paciencia: levantar el corte con efecto y rematar la pelota que flota.', pasos: ['Topspin de derecho contra corte, con mucho efecto, al centro del cuerpo del cortador.', 'Alterna con una dejada corta para acercarlo a la mesa.', 'Cuando la pelota venga más alta o sin efecto, remate a los ángulos.', 'No ataques todas: intercala push largos para cambiar el ritmo.'] },
    { id: 'j6', nombre: 'Contra pips largos: pelotas sin efecto y al cuerpo', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'contraatacante', 'pips_cortos', 'lapicero_chino', 'lapicero_tradicional'], contra: ['pips_largos'],
      objetivo: 'Neutralizar el efecto invertido de los pips largos.', pasos: ['Recuerda: los pips largos devuelven tu efecto al revés. Si cortas, la pelota vuelve con efecto liftado.', 'Golpea "sin efecto" (empujes planos) al lado de los pips para recibir pelotas muertas.', 'Ataca fuerte al lado de la goma lisa (normalmente el derecho del rival).', 'Juega al cuerpo: obliga a decidir con qué cara golpear.'] },
    { id: 'j7', nombre: 'Saque corto al derecho + ataque cruzado al revés', estilos: ['atacante_cerca', 'atacante_media', 'allround'], contra: ['revesista', 'lapicero', 'zurdo'],
      objetivo: 'Sacar al rival de su lado fuerte y abrir la mesa.', pasos: ['Saque corto al derecho (cerca de la red).', 'El rival se adelanta: su revés queda descubierto.', 'Tercera bola: topspin o drive largo a la esquina del revés.', 'Cuarta: espera una devolución cruzada y ataca a la paralela.'] },
    { id: 'j8', nombre: 'Recepción agresiva con banana flick (chiquita)', estilos: ['atacante_cerca', 'atacante_media', 'lapicero_chino'], contra: ['topspinero', 'bloqueador', 'lapicero', 'zurdo'],
      objetivo: 'Quitarle al servidor la tercera bola.', pasos: ['Lee el efecto del saque corto.', 'Banana flick de revés a la paralela o al codo.', 'Prepárate para un bloqueo y ataca de nuevo con el derecho.'] },
    { id: 'j9', nombre: 'Defensa con cortes de distinto efecto y contraataque', estilos: ['defensor_clasico', 'defensor_moderno', 'pips_largos'], contra: ['topspinero', 'principiante', 'alto_lento', 'revesista'],
      objetivo: 'Variar el efecto para provocar errores y contraatacar la pelota alta.', pasos: ['Alterna cortes muy cargados con cortes "flotantes" (sin efecto) con el mismo movimiento.', 'Corta profundo, siempre al fondo de la mesa.', 'Cuando el rival levante una pelota débil, topspin o remate de derecho.'] },
    { id: 'j10', nombre: 'Juego al cuerpo (punto de cruce)', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'contraatacante', 'pips_cortos', 'lapicero_chino', 'lapicero_tradicional', 'defensor_moderno'], contra: ['alto_lento', 'topspinero', 'revesista', 'lapicero'],
      objetivo: 'Golpear al codo del brazo que golpea, donde el rival debe decidir derecho o revés.', pasos: ['Busca el bolsillo derecho/codo del rival con golpes rápidos.', 'Fuérzalo a moverse para golpear de derecho.', 'Siguiente golpe al ángulo abierto.'] },
    { id: 'j11', nombre: 'Saque con efecto lateral hacia afuera + bloqueo largo', estilos: ['contraatacante', 'allround', 'pips_largos', 'pips_cortos', 'lapicero_tradicional'], contra: ['topspinero', 'zurdo', 'principiante'],
      objetivo: 'Recibir un ataque predecible y bloquearlo a donde el rival no llega.', pasos: ['Saque medio-largo con efecto lateral hacia el derecho del rival.', 'El rival ataca cruzado casi siempre: anticipa en tu revés.', 'Bloqueo largo a la paralela.'] },
    { id: 'j12', nombre: 'Dejada + ataque largo', estilos: ['allround', 'atacante_cerca', 'atacante_media', 'contraatacante', 'defensor_moderno'], contra: ['cortador', 'alto_lento', 'pips_largos'],
      objetivo: 'Mover al rival hacia adelante y atrás.', pasos: ['Dejada corta al derecho.', 'El rival se acerca: ataque largo y rápido al revés o al cuerpo.'] },
    { id: 'j13', nombre: 'Saque largo con efecto liftado y contra-topspin', estilos: ['atacante_media'], contra: ['bloqueador', 'principiante', 'rapido_bajo'],
      objetivo: 'Llevar el punto a un intercambio de topspin a media distancia, donde estás más cómodo.', pasos: ['Saque largo y rápido con efecto liftado al revés.', 'Retrocede un paso esperando un topspin o bloqueo.', 'Contra-topspin con efecto, buscando profundidad.'] },
    { id: 'j14', nombre: 'Push corto + flick sorpresa', estilos: ['allround', 'atacante_cerca', 'lapicero_chino', 'lapicero_tradicional'], contra: ['cortador', 'lapicero', 'revesista'],
      objetivo: 'Mantener el juego corto y sorprender con velocidad.', pasos: ['Dos o tres push cortos para fijar al rival junto a la mesa.', 'Flick rápido al codo o a la esquina contraria.'] },
    { id: 'j15', nombre: 'Contra lapicero: revés largo y abierto', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'contraatacante'], contra: ['lapicero'],
      objetivo: 'Explotar el revés del jugador de lapicero tradicional, que suele ser más débil y corto.', pasos: ['Pelotas largas y rápidas al revés.', 'Ángulo abierto al revés (sacándolo de la mesa).', 'Ataque al derecho cuando quede descolocado.'] },
    { id: 'j16', nombre: 'Contra zurdo: jugar a su revés desde la diagonal derecha', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'contraatacante', 'defensor_moderno'], contra: ['zurdo'],
      objetivo: 'El ángulo cruzado cambia: tu derecho cruzado va al derecho del zurdo. Juega a la paralela para buscar su revés.', pasos: ['Saque corto al centro o al derecho del zurdo.', 'Tercera bola a la paralela de tu derecho (va al revés del zurdo).', 'Evita el cruzado largo derecho contra derecho si su derecho es mejor.'] },
    { id: 'j17', nombre: 'Contra rival rápido y bajo: pelotas altas con efecto y profundas', estilos: ['atacante_media', 'defensor_moderno', 'defensor_clasico', 'allround'], contra: ['rapido_bajo', 'pips_cortos'],
      objetivo: 'Sacarlo de su distancia ideal.', pasos: ['Topspin con mucho efecto y profundo.', 'Globo con efecto si te ataca fuerte.', 'Alterna cortos para que no se quede atrás.'] },
    { id: 'j18', nombre: 'Para el de menor nivel: consistencia y paciencia', estilos: ['atacante_cerca', 'atacante_media', 'allround', 'contraatacante', 'defensor_clasico', 'defensor_moderno', 'pips_cortos', 'pips_largos', 'lapicero_chino', 'lapicero_tradicional'], contra: ['principiante'],
      objetivo: 'No regalar puntos: el rival fallará antes si la pelota llega profunda y con efecto.', pasos: ['Saques variados pero seguros.', 'Devoluciones largas y con efecto.', 'Ataca solo pelotas claras; no arriesgues.'] }
  ];

  return { METRICAS, ZONAS, FALLAS, GOLPES, refPorTipo, NOMBRE_TIPO, ESTILOS, TOMAS, PREGUNTAS_TOMA, MADEROS, GOMAS, NIVELES, CONTEXTURAS, RIVALES, JUGADAS };
});

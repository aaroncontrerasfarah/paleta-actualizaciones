/* Paleta — perfil del jugador a partir de una descripción libre.
   Un intérprete local reconoce maderos, gomas, estilo, toma, mano, edad, etc. (funciona sin internet);
   la IA mejora la interpretación y redacta el perfil técnico que se usa al analizar al jugador. */
(function (raiz, fabrica) {
  const m = fabrica(raiz.K || (typeof require === 'function' ? require('./conocimiento.js') : null));
  if (typeof module === 'object' && module.exports) module.exports = m; else raiz.Perfil = m;
})(typeof self !== 'undefined' ? self : this, function (K) {
  'use strict';
  const sinTilde = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const opcion = (lista, palabra) => lista.find(x => sinTilde(x).includes(sinTilde(palabra)));

  /* Material conocido: palabra clave → datos */
  const MADEROS = [
    [/viscaria|timo boll alc|fan zhendong alc|zhang jike alc|ma long carbon|hurricane long|harimoto alc|zlc|super alc/, { composicion: 'exterior', velocidad: 'OFF (' }],
    [/innerforce|inner force|fan zhendong super zlc|lin yun-?ju|alc interior|zlc interior|inner/, { composicion: 'interior', velocidad: 'OFF (' }],
    [/primorac carbon|carbonado|carbono exterior|offensive carbon/, { composicion: 'Carbono exterior', velocidad: 'OFF+' }],
    [/clipper|7 capas|7 ply|siete capas/, { composicion: '7 capas', velocidad: 'OFF (' }],
    [/korbel|5 capas|5 ply|cinco capas|ma lin extra offensive|offensive classic/, { composicion: '5 capas', velocidad: 'OFF-' }],
    [/allround|all round|all-round|sweden extra|yasaka extra|todo terreno/, { composicion: '5 capas', velocidad: 'ALL' }],
    [/defens|diode|joo se hyuk|chop|cortador|def\b/, { velocidad: 'DEF' }]
  ];
  const GOMAS = [
    [/hurricane|skyline|neo hurricane|battle|globe 999|pegajosa|tacky/, 'China pegajosa'],
    [/dignics|tenergy|rozena|evolution|mx-?p|el-?p|mx-?s|fx-?p|rasanter|dna|fastarc|vega|omega|tensor|glayzer|hexer|qxr|nittaku fastarc|tibhar|andro|xiom|rakza|v15|bluefire|blue ?star/, 'Lisa tensor'],
    [/mark ?v|sriver|vega asia|clasica sin tensor/, 'Lisa cl'],
    [/pips? largos?|feint|grass|curl|dtecs|d\.tecs|ox long|long pips|picos largos/, 'Pips largos'],
    [/pips? medios?|medium pips/, 'Pips medios'],
    [/pips? cortos?|spinpips|challenger|802|729 ?super|picos cortos|short pips/, 'Pips cortos'],
    [/\banti\b|antitop|antitopspin/, 'Antitopspin'],
    [/hibrida|hybrid|k3|k5|dhs neo|cyclone|tg2|tg3/, 'Híbrida']
  ];
  const ESPONJAS = [[/\bmax\b|maxima|2[.,]2|2[.,]1/, '2,1'], [/2[.,]0/, '2,0'], [/1[.,]8/, '1,8'], [/1[.,]5/, '1,5'], [/\box\b|sin esponja/, 'OX'], [/0[.,]5|1[.,]0/, '0,5']];
  const COLORES = ['negra', 'roja', 'rosada', 'verde', 'azul', 'morada'];

  function detectarGoma(t) {
    const g = {};
    for (const [re, tipo] of GOMAS) if (re.test(t)) { g.tipo = opcion(K.GOMAS.tipo, tipo); break; }
    for (const [re, esp] of ESPONJAS) if (re.test(t)) { g.esponja = opcion(K.GOMAS.esponja, esp); break; }
    for (const c of COLORES) if (new RegExp('\\b' + c).test(t)) { g.color = opcion(K.GOMAS.color, c); break; }
    if (/\bdura\b|hard/.test(t)) g.dureza = opcion(K.GOMAS.dureza, 'Dura');
    else if (/blanda|soft/.test(t)) g.dureza = opcion(K.GOMAS.dureza, 'Blanda');
    const mm = t.match(/(\d{1,2})\s*mes/); if (mm) g.meses = +mm[1];
    const mod = t.match(/(dignics \d+\w*|tenergy \d+\w*(?: fx)?|rozena|evolution [a-z-]+|hurricane ?\d+(?: neo)?|neo hurricane ?\d*|rasanter \w+|fastarc \w+|vega \w+|omega \w+|feint long \w*|mark ?v|sriver|729 \w+|glayzer|hexer \w+|rakza \w+|mx-?p|el-?p|mx-?s|fx-?p|skyline \w*|dna \w+)/);
    if (mod) g.modelo = mod[1].replace(/\b\w/g, c => c.toUpperCase());
    return g;
  }

  /* Intérprete local de la descripción */
  function interpretarLocal(texto) {
    const t = sinTilde(texto), o = { madero: {}, gomaD: {}, gomaR: {} };
    if (!t.trim()) return o;
    if (/\bzurd/.test(t)) o.mano = 'Z'; else if (/\bdiestr/.test(t)) o.mano = 'D';
    const ed = t.match(/(\d{1,2})\s*anos/); if (ed) o.edad = +ed[1];
    const es = t.match(/\b1[.,](\d{2})\s*(m|mt|metros)\b/) || t.match(/\b(1\d{2})\s*cm\b/);
    if (es) o.estatura = es[0].includes('cm') ? +es[1] : 100 + +es[1];
    const pe = t.match(/\b(\d{2,3})\s*(kg|kilos)\b/); if (pe) o.peso = +pe[1];
    if (/femenin|mujer|nina\b|jugadora|senora|defensora|atacante mujer/.test(t)) o.sexo = 'Femenino'; else if (/masculin|hombre|nino\b|varon/.test(t)) o.sexo = 'Masculino';
    if (/delgad|flac/.test(t)) o.contextura = 'Delgada'; else if (/atletic/.test(t)) o.contextura = 'Atlética'; else if (/robust|corpulent|grueso|sobrepeso/.test(t)) o.contextura = 'Robusta';
    if (/principiante|comenzando|recien empez|aprendiendo/.test(t)) o.nivel = K.NIVELES[0];
    else if (/alto rendimiento|seleccion|seleccionad/.test(t)) o.nivel = K.NIVELES[3];
    else if (/avanzad|compite|competidor|federad|ranking/.test(t)) o.nivel = K.NIVELES[2];
    else if (/intermedi/.test(t)) o.nivel = K.NIVELES[1];
    const se = t.match(/(\d{1,2})\s*(veces|entrenamientos|sesiones|dias)\s*(a la|por|x)\s*semana/); if (se) o.sesiones = +se[1];
    /* estilo */
    if (/lapicero|penhold/.test(t)) o.estilo = /reves invertido|rpb|reverse/.test(t) ? 'lapicero_chino' : 'lapicero_tradicional';
    else if (/defensor moderno|defiende y ataca|corta y ataca/.test(t)) o.estilo = 'defensor_moderno';
    else if (/defensor|cortador|defensivo|corta lejos/.test(t)) o.estilo = 'defensor_clasico';
    else if (/media distancia|lejos de la mesa|topspinero|contra-?topspin/.test(t)) o.estilo = 'atacante_media';
    else if (/cerca de la mesa|pegado a la mesa|juego rapido|ataque rapido/.test(t)) o.estilo = 'atacante_cerca';
    else if (/bloque|contraataca|contragolpe/.test(t)) o.estilo = 'contraatacante';
    else if (/all ?round|todo terreno|completo/.test(t)) o.estilo = 'allround';
    else if (/topspin|ataca|ofensiv|atacante/.test(t)) o.estilo = 'atacante_media';
    /* escuela técnica */
    if (/escuela china|estilo chino|tecnica china|a la china/.test(t)) o.escuela = /lapicero|penhold/.test(t) ? 'china_lapicero' : 'china';
    else if (/escuela europea|estilo europeo|tecnica europea/.test(t)) o.escuela = 'europea';
    else if (/japones|corean/.test(t)) o.escuela = 'japonesa';
    else if (/hurricane|pegajosa|tacky/.test(t) && !/lapicero/.test(t)) o.escuela = undefined;
    /* toma */
    if (/japones|corean/.test(t)) o.toma = 'pen_japonesa';
    else if (/lapicero|penhold/.test(t)) o.toma = 'pen_china';
    else if (/seemiller/.test(t)) o.toma = 'seemiller';
    else if (/toma (cargada )?(al|de) derecho/.test(t)) o.toma = 'sh_derecho';
    else if (/toma (cargada )?(al|de) reves/.test(t)) o.toma = 'sh_reves';
    else if (/clasica|shakehand|lapiz no|europea/.test(t)) o.toma = 'sh_neutra';
    /* madero */
    for (const [re, d] of MADEROS) if (re.test(t)) {
      if (d.composicion) o.madero.composicion = d.composicion === 'exterior' ? opcion(K.MADEROS.composicion, 'ALC/ZLC) exterior') : d.composicion === 'interior' ? opcion(K.MADEROS.composicion, 'ALC/ZLC) interior') : opcion(K.MADEROS.composicion, d.composicion);
      if (d.velocidad) o.madero.velocidad = opcion(K.MADEROS.velocidad, d.velocidad);
      break;
    }
    const mm = t.match(/(viscaria|innerforce \w+|timo boll \w+|fan zhendong \w+|zhang jike \w+|clipper(?: \w+)?|korbel|primorac(?: carbon)?|hurricane long \d|harimoto \w+|ma long \w+|lin yun-?ju \w*|joo se hyuk|diode|allround classic|sweden extra|nittaku \w+|stiga \w+|yasaka \w+|dhs \w+|xiom \w+|andro \w+|tibhar \w+ ?\w*)/);
    if (mm && !/goma/.test(mm[1])) o.madero.modelo = mm[1].replace(/\b\w/g, c => c.toUpperCase());
    if (/\bfl\b|concavo/.test(t)) o.madero.mango = opcion(K.MADEROS.mango, 'FL'); else if (/\ban\b|anatomic/.test(t)) o.madero.mango = opcion(K.MADEROS.mango, 'AN'); else if (/\bst\b|recto/.test(t)) o.madero.mango = opcion(K.MADEROS.mango, 'ST');
    /* gomas: ubica cada mención de goma y mira el lado (derecho/revés) en el tramo que la sigue o, si no, en el que la precede */
    const menciones = [];
    for (const [re] of GOMAS) { const g = new RegExp(re.source, 'g'); let x; while ((x = g.exec(t))) menciones.push([x.index, x.index + x[0].length]); }
    menciones.sort((a, b) => a[0] - b[0]);
    const unicas = menciones.filter((m, i) => !menciones.some((n, k) => k < i && n[0] <= m[0] && n[1] >= m[0]));
    const sinLado = [];
    unicas.forEach((m, i) => {
      const fin = i + 1 < unicas.length ? unicas[i + 1][0] : t.length;
      const ini = i > 0 ? unicas[i - 1][1] : Math.max(0, m[0] - 40);
      const tras = t.slice(m[0], fin).split(/\.(?=\s|$)|[;\n]/)[0], antes = t.slice(ini, m[0]);
      const g = detectarGoma(tras);
      const lado = s => /derecho|\bfh\b|forehand/.test(s) ? 'D' : /reves|\bbh\b|backhand/.test(s) ? 'R' : '';
      const l = lado(antes.split(/[.;,]|\sy\s/).pop()) || lado(tras.split(/\sy\s|,/)[0]) || lado(tras);
      if (l === 'D') Object.assign(o.gomaD, g); else if (l === 'R') Object.assign(o.gomaR, g); else sinLado.push(g);
    });
    if (sinLado.length) { if (!o.gomaD.tipo) Object.assign(o.gomaD, sinLado.shift()); if (sinLado.length && !o.gomaR.tipo) Object.assign(o.gomaR, sinLado.shift()); }
    return o;
  }

  /* Perfil técnico redactado sin internet */
  function describirLocal(p, Ev) {
    const est = K.ESTILOS.find(x => x.id === p.estilo);
    const nombre = (p.nombre || 'El jugador').split(' ')[0];
    const partes = [];
    const datos = [p.mano === 'Z' ? 'zurdo' : 'diestro', p.edad ? p.edad + ' años' : '', p.estatura ? p.estatura + ' cm' : '', p.contextura ? 'contextura ' + p.contextura.toLowerCase() : '', p.nivel ? 'nivel ' + p.nivel.split(' (')[0].toLowerCase() : ''].filter(Boolean).join(', ');
    partes.push(`${nombre}: ${datos}.${est ? ' Estilo ' + est.nombre.toLowerCase() + ': ' + est.descripcion.charAt(0).toLowerCase() + est.descripcion.slice(1) : ''}`);
    const escu = K.ESCUELAS.find(x => x.id === p.escuela); if (escu) partes.push(`${escu.nombre}: ${escu.resumen}`);
    const gd = p.gomaD || {}, gr = p.gomaR || {}, m = p.madero || {};
    const mat = [m.modelo || m.composicion ? `madero ${[m.modelo, m.composicion && m.composicion.toLowerCase(), m.velocidad && m.velocidad.split(' ')[0]].filter(Boolean).join(', ')}` : '',
      gd.tipo || gd.modelo ? `derecho con ${[gd.modelo, gd.tipo && gd.tipo.toLowerCase(), gd.esponja].filter(Boolean).join(' ')}` : '',
      gr.tipo || gr.modelo ? `revés con ${[gr.modelo, gr.tipo && gr.tipo.toLowerCase(), gr.esponja].filter(Boolean).join(' ')}` : ''].filter(Boolean);
    if (mat.length) partes.push('Material: ' + mat.join('; ') + '.');
    const esperar = [];
    if (est) esperar.push(`golpes clave: ${est.golpesClave.map(id => (K.GOLPES.find(g => g.id === id) || {}).nombre).filter(Boolean).join(', ').toLowerCase()}`);
    if (/pegajosa|híbrida/i.test(gd.tipo || '')) esperar.push('derecho más hacia adelante, con mucho giro de cintura y uso de piernas (goma pegajosa)');
    if (/pips cortos/i.test(gd.tipo || '') || /pips cortos/i.test(gr.tipo || '')) esperar.push('golpes planos y en la subida del lado de pips cortos');
    if (/pips largos|anti/i.test(gr.tipo || '')) esperar.push('el revés no hará topspin: bloqueos, cortes y empujes con efecto invertido');
    if (/pips largos|anti/i.test(gd.tipo || '')) esperar.push('el derecho no hará topspin: bloqueos y cortes con efecto invertido');
    if (/exterior|OFF\+/.test((m.composicion || '') + (m.velocidad || ''))) esperar.push('madero rápido: recorridos más cortos y exigencia de control');
    if (/DEF/.test(m.velocidad || '')) esperar.push('madero lento: más recorrido y distancia de la mesa');
    if (p.edad && p.edad <= 12) esperar.push('jugador infantil: priorizar técnica básica y desplazamiento antes que potencia');
    if (p.edad >= 55) esperar.push('cuidar la exigencia de piernas y la recuperación');
    if (esperar.length) partes.push('Qué esperar: ' + esperar.join('; ') + '.');
    if (Ev) { const av = Ev.asesorMaterial(p).filter(x => x.nivel === 'alerta').map(x => x.titulo.toLowerCase()); if (av.length) partes.push('Atención: ' + av.join('; ') + '.'); }
    if (p.descripcion) partes.push('Notas del entrenador: ' + p.descripcion.trim());
    return partes.join('\n\n');
  }

  /* Pedido a la IA: devuelve JSON con los campos y un perfil redactado */
  function pedidoIA(texto, actual) {
    const op = {
      estilo: K.ESTILOS.map(x => x.id + ' = ' + x.nombre), escuela: K.ESCUELAS.map(x => x.id + ' = ' + x.nombre), toma: K.TOMAS.map(x => x.id + ' = ' + x.nombre), nivel: K.NIVELES, contextura: K.CONTEXTURAS, sexo: ['Femenino', 'Masculino', 'Otro'],
      'madero.composicion': K.MADEROS.composicion, 'madero.velocidad': K.MADEROS.velocidad, 'madero.mango': K.MADEROS.mango,
      'goma.tipo': K.GOMAS.tipo, 'goma.esponja': K.GOMAS.esponja, 'goma.dureza': K.GOMAS.dureza, 'goma.color': K.GOMAS.color
    };
    const sistema = 'Eres un entrenador experto de tenis de mesa y conoces los maderos y gomas comerciales (Butterfly, Stiga, DHS, Tibhar, Xiom, Yasaka, Nittaku, Andro, Donic, Joola, etc.). Respondes solo con JSON válido, sin texto adicional.';
    const usuario = `Descripción de un jugador escrita por su entrenador:\n"""${texto}"""\n\nDatos ya registrados (pueden estar vacíos): ${JSON.stringify(actual || {})}\n\n` +
      `Devuelve un JSON con esta forma: {"mano":"D|Z","edad":n,"sexo":"","estatura":cm,"peso":kg,"contextura":"","nivel":"","sesiones":n,"estilo":"id","escuela":"id","toma":"id",` +
      `"madero":{"modelo":"","composicion":"","velocidad":"","mango":"","peso":g},"gomaD":{"modelo":"","tipo":"","esponja":"","dureza":"","color":"","meses":n},"gomaR":{...igual},` +
      `"perfil":"texto"}.\nReglas: usa SOLO valores de estas listas para los campos con opciones: ${JSON.stringify(op)}. Para estilo, escuela y toma escribe el id (escuela solo si la descripción lo indica o es evidente por la toma y el material). ` +
      `Si reconoces un modelo comercial, deduce su composición, velocidad, tipo de goma y dureza típica. Omite los campos que no se puedan saber; no inventes edad, estatura ni peso. ` +
      `En "perfil" escribe en español de Chile, en 4 a 7 frases, el perfil técnico del jugador para tenerlo presente al analizar sus videos: estilo, qué golpes y mecánica esperar según su material (por ejemplo, goma pegajosa: derecho más hacia adelante; pips largos: no se espera topspin de ese lado), fortalezas probables, riesgos técnicos a vigilar y si el material es adecuado para su nivel.`;
    return { sistema, usuario };
  }

  /* Lleva la respuesta de la IA a los valores válidos de la app */
  function normalizar(r) {
    const o = { madero: {}, gomaD: {}, gomaR: {} };
    if (!r || typeof r !== 'object') return o;
    const de = (lista, v) => { if (v === undefined || v === null || v === '') return undefined; const s = sinTilde(v); return lista.find(x => sinTilde(x) === s) || lista.find(x => sinTilde(x.split(' (')[0]) === s) || lista.find(x => sinTilde(x).startsWith(s)) || lista.find(x => s.length > 2 && sinTilde(x).includes(s)) || lista.find(x => s.includes(sinTilde(x).split(' (')[0])); };
    const num = v => { const n = parseFloat(v); return isFinite(n) && n > 0 ? n : undefined; };
    if (/^z/i.test(r.mano || '')) o.mano = 'Z'; else if (/^d/i.test(r.mano || '')) o.mano = 'D';
    o.edad = num(r.edad); o.estatura = num(r.estatura); o.peso = num(r.peso); o.sesiones = num(r.sesiones);
    o.sexo = de(['Femenino', 'Masculino', 'Otro'], r.sexo); o.contextura = de(K.CONTEXTURAS, r.contextura); o.nivel = de(K.NIVELES, r.nivel);
    o.estilo = (K.ESTILOS.find(x => x.id === r.estilo) || K.ESTILOS.find(x => sinTilde(x.nombre) === sinTilde(r.estilo)) || {}).id;
    o.escuela = (K.ESCUELAS.find(x => x.id === r.escuela) || {}).id;
    o.toma = (K.TOMAS.find(x => x.id === r.toma) || K.TOMAS.find(x => sinTilde(x.nombre) === sinTilde(r.toma)) || {}).id;
    const m = r.madero || {};
    o.madero = { modelo: m.modelo || undefined, composicion: de(K.MADEROS.composicion, m.composicion), velocidad: de(K.MADEROS.velocidad, m.velocidad), mango: de(K.MADEROS.mango, m.mango), peso: num(m.peso) };
    for (const k of ['gomaD', 'gomaR']) { const g = r[k] || {}; o[k] = { modelo: g.modelo || undefined, tipo: de(K.GOMAS.tipo, g.tipo), esponja: de(K.GOMAS.esponja, g.esponja), dureza: de(K.GOMAS.dureza, g.dureza), color: de(K.GOMAS.color, g.color), meses: num(g.meses) }; }
    if (typeof r.perfil === 'string' && r.perfil.trim().length > 30) o.perfil = r.perfil.trim();
    return o;
  }

  /* Combina: lo nuevo completa o reemplaza solo los campos que trae */
  function combinar(base, nuevo) {
    const o = JSON.parse(JSON.stringify(base || {}));
    for (const [k, v] of Object.entries(nuevo || {})) {
      if (v === undefined || v === null || v === '') continue;
      if (typeof v === 'object' && !Array.isArray(v)) { o[k] = o[k] || {}; for (const [k2, v2] of Object.entries(v)) if (v2 !== undefined && v2 !== null && v2 !== '') o[k][k2] = v2; }
      else o[k] = v;
    }
    return o;
  }

  function extraerJSON(t) { const a = t.indexOf('{'), b = t.lastIndexOf('}'); if (a < 0 || b < a) throw new Error('La IA no devolvió datos.'); return JSON.parse(t.slice(a, b + 1)); }

  return { interpretarLocal, describirLocal, pedidoIA, normalizar, combinar, extraerJSON };
});

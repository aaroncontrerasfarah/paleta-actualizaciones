/* Paleta — informe del video: diagnóstico, fallas priorizadas, fotogramas, ejercicios, material, toma
   y redacción con IA (gratuita, sin claves). Siempre hay un informe completo sin internet. */
"use strict";
const Informe = (() => {
  const e = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmtNum = (k, v) => {
    if (typeof v !== 'number' || !isFinite(v)) return '—';
    if (k === 'fase') return `${Pel.nombreFase(v)} (${v.toFixed(2).replace('.', ',')})`;
    if (k === 'paleta') return Pel.nombrePaleta(v);
    const u = (K.METRICAS[k] || {}).unidad || '';
    if (u === '°') return Math.round(v) + '°';
    if (u === 's') return v.toFixed(2).replace('.', ',') + ' s';
    if (u === 'cm') return Math.round(v) + ' cm';
    return v.toFixed(2).replace('.', ',') + ' ' + u;
  };
  const fmtRango = (k, r) => !r ? '' : k === 'fase' ? `entre ${Pel.nombreFase(r[0]).replace('en ', '')} y ${Pel.nombreFase(r[1]).replace('en ', '')}` : k === 'paleta' ? `de ${Pel.nombrePaleta(r[0])} a ${Pel.nombrePaleta(r[1])}` : `${fmtNum(k, r[0])} a ${fmtNum(k, r[1])}`;
  const fecha = f => { try { return new Date(f).toLocaleString('es-CL', { dateStyle: 'medium', timeStyle: 'short' }); } catch (x) { return f; } };
  const color = p => p >= 80 ? 'bien' : p >= 60 ? 'regular' : 'mal';

  /* Texto de lo que cambia en la animación corregida, por golpe */
  function cambios(diag) {
    const o = {};
    for (const g of diag.golpes) {
      const t = Object.entries(g.metas).map(([k, v]) => `${(K.METRICAS[k] || {}).nombre || k}: ${fmtNum(k, g.medidas[k])} → ${fmtNum(k, v)}`);
      o[g.n] = t.length ? t.slice(0, 3).join(' · ') : 'Golpe correcto';
    }
    return o;
  }

  /* Resumen escrito sin internet */
  function resumenLocal(diag, perfil) {
    const nombre = (perfil.nombre || 'El jugador').split(' ')[0];
    const p = [];
    if (!diag.golpes.length) return 'No se detectaron golpes en el video. Revisa que se vea el cuerpo completo y que el jugador golpee durante la grabación.';
    p.push(`${nombre} realizó ${diag.golpes.length} golpes en ${Math.round(diag.duracion)} segundos; se evaluaron ${diag.usados} como ${diag.golpeNombre.toLowerCase()}. Puntaje técnico: ${diag.puntaje} de 100.`);
    if (diag.distintos > 0 && !Ev.golpe(diag.golpeId).libre) p.push(`${diag.distintos} golpes no se parecen al golpe pedido (por ejemplo, otro lado o un movimiento distinto). Puede ser un error de ejecución o que el ejercicio se mezcló.`);
    const f = diag.fallas.slice(0, 3);
    if (!f.length) p.push('No aparecen fallas repetidas: la técnica está dentro de los rangos esperados para su nivel y estilo. El siguiente paso es aumentar la velocidad y la regularidad.');
    else {
      p.push('Lo más importante para corregir: ' + f.map((x, i) => `${i + 1}) ${x.titulo.toLowerCase()} (en ${Math.round(x.frecuencia * 100)}% de los golpes)`).join('; ') + '.');
      p.push(`Primera prioridad: ${f[0].corregir}`);
    }
    const conFalla = new Set(f.map(x => (K.METRICAS[x.metrica] || {}).grupo));
    const fuertes = Object.entries(diag.puntajes).filter(([k, v]) => v >= 85 && !conFalla.has(k)).map(([k]) => k.toLowerCase());
    if (fuertes.length) p.push(`Puntos fuertes: ${fuertes.join(', ')}.`);
    return p.join('\n\n');
  }

  /* Fotograma del golpe con el esqueleto dibujado y las fallas en rojo */
  async function fotograma(sesion, nGolpe, diag) {
    const g = diag.golpes.find(x => x.n === nGolpe); if (!g) return null;
    const iRef = typeof g.medidas.iContacto === 'number' ? g.medidas.iContacto : g.golpe.impacto;
    const t = sesion.cuadros[iRef].t;
    const c = document.createElement('canvas'); let cuadro;
    const ctx = c.getContext('2d');
    if (sesion.miniaturas && sesion.miniaturas.length) {
      const mini = sesion.miniaturas.reduce((a, b) => Math.abs(b.t - t) < Math.abs(a.t - t) ? b : a);
      const img = new Image(); img.src = mini.img;
      await new Promise(r => { img.onload = r; img.onerror = r; });
      c.width = img.naturalWidth || 320; c.height = img.naturalHeight || 180; ctx.drawImage(img, 0, 0);
      cuadro = sesion.cuadros.reduce((a, b) => Math.abs(b.t - mini.t) < Math.abs(a.t - mini.t) ? b : a);
    } else {
      if (!sesion.cuadros[iRef].n) return null;
      c.width = 320; c.height = 180; ctx.fillStyle = '#10201b'; ctx.fillRect(0, 0, 320, 180); cuadro = sesion.cuadros[iRef];
    }
    const rojo = []; Object.entries(g.ev).forEach(([k, v]) => { if (v.dir !== 'ok') rojo.push(...Ev.articulacionesZona((K.METRICAS[k] || {}).zona, sesion.mano)); });
    Pose.dibujar(ctx, cuadro.n, c.width, c.height, { grosor: 2.5, rojo });
    Pose.dibujarExtras(ctx, cuadro, c.width, c.height);
    const etiqueta = [Pel.nombreFase(g.medidas.fase), g.medidas.paleta !== undefined ? 'paleta ' + Pel.nombrePaleta(g.medidas.paleta) : ''].filter(Boolean).join(' · ');
    if (etiqueta) { ctx.fillStyle = '#000b'; ctx.fillRect(0, c.height - 22, c.width, 22); ctx.fillStyle = '#fff'; ctx.font = 'bold 12px sans-serif'; ctx.fillText(etiqueta, 6, c.height - 7); }
    return c.toDataURL('image/jpeg', 0.8);
  }

  function pelotaHTML(d) {
    if (!d.pelota) return `<div class="card"><h3>Pelota y paleta</h3><p class="note">En esta grabación no se pudo seguir la pelota ni la paleta. Para medir el timing y el ángulo de la paleta: buena luz, pelota de color que contraste con el fondo, la mano con la paleta visible y, si se puede, 60 cuadros por segundo.</p></div>`;
    const usados = d.golpes.filter(g => g.coincide || Ev.golpe(d.golpeId).libre);
    const fases = usados.map(g => g.medidas.fase).filter(x => typeof x === 'number');
    const pals = usados.map(g => g.medidas.paleta).filter(x => typeof x === 'number');
    const cuenta = { subida: 0, alto: 0, bajada: 0 }; fases.forEach(f => { if (f < 0.75) cuenta.subida++; else if (f <= 1.2) cuenta.alto++; else cuenta.bajada++; });
    const ref = (k) => { const g = d.golpes.find(x => x.ref[k]); return g ? g.ref[k] : null; };
    const media = a => a.reduce((x, y) => x + y, 0) / a.length;
    let h = `<div class="card"><h3>Pelota y paleta</h3>
      <p class="note">Pelota seguida en ${d.pelota.golpesConPelota} de ${d.golpes.length} golpes · paleta medida en ${d.pelota.golpesConPaleta}.</p>`;
    if (fases.length) h += `<p><b>Timing:</b> ${cuenta.subida} en la subida · ${cuenta.alto} en el punto más alto · ${cuenta.bajada} en la bajada.${ref('fase') ? ` Para este golpe se espera golpear ${fmtRango('fase', ref('fase'))}.` : ''}</p>
      <div class="fases"><i style="flex:${cuenta.subida || 0.001}" class="f1"></i><i style="flex:${cuenta.alto || 0.001}" class="f2"></i><i style="flex:${cuenta.bajada || 0.001}" class="f3"></i></div>`;
    else h += `<p class="note">No se pudo ver el bote de la pelota antes del golpe, así que no se midió el timing.</p>`;
    if (pals.length) h += `<p><b>Paleta en el impacto:</b> en promedio ${Pel.nombrePaleta(media(pals))}${ref('paleta') ? ` (esperado ${fmtRango('paleta', ref('paleta'))})` : ''}.</p>`;
    if (d.pelota.velSalida) h += `<p><b>Velocidad de salida:</b> unos ${d.pelota.velSalida} km/h <span class="note">(estimada en el plano de la cámara; la real suele ser algo mayor)</span>.</p>`;
    return h + '</div>';
  }

  /* HTML del informe */
  function html(sesion, perfil, opc) {
    const d = sesion.diag, o = opc || {};
    const def = Ev.golpe(d.golpeId);
    let h = `<div class="inf">`;
    h += `<div class="inf-cab"><div class="aro ${color(d.puntaje)}"><b>${d.puntaje}</b><small>de 100</small></div>
      <div><h2>${e(d.golpeNombre)}</h2><p class="note">${e(perfil.nombre || '')} · ${fecha(sesion.fecha)} · ${d.golpes.length} golpes en ${Math.round(d.duracion)} s${sesion.demo ? ' · demostración' : ''}</p>
      <p class="note">${Object.entries(d.tipos).map(([k, v]) => `${v} ${e(k)}`).join(' · ')}</p></div></div>`;
    h += `<div class="card"><h3>Resumen</h3><div class="texto">${e(sesion.resumenIA || resumenLocal(d, perfil)).replace(/\n/g, '<br>')}</div>
      ${sesion.resumenIA ? '<p class="note">Redactado con IA a partir de las mediciones.</p>' : ''}
      ${o.conIA ? `<div class="row"><button class="btn sm" data-a="ia">${sesion.resumenIA ? 'Volver a redactar con IA' : '✨ Redactar el informe con IA'}</button></div><p class="note" id="ia-estado"></p>` : ''}</div>`;
    if (perfil.perfilIA) h += `<details class="card"><summary><b>Perfil técnico del jugador</b></summary><div class="texto">${e(perfil.perfilIA).replace(/\n/g, '<br>')}</div></details>`;
    /* puntajes por aspecto */
    h += `<div class="card"><h3>Por aspecto</h3>${Object.entries(d.puntajes).map(([k, v]) => `<div class="barra"><span>${e(k)}</span><div><i class="${color(v)}" style="width:${v}%"></i></div><b>${v}</b></div>`).join('')}</div>`;
    /* pelota y paleta */
    h += pelotaHTML(d);
    /* fotogramas */
    h += `<div class="card"><h3>Fotogramas</h3><div class="fotos" id="fotos">${o.fotos ? o.fotos : '<p class="note">Preparando fotogramas…</p>'}</div></div>`;
    /* fallas */
    h += `<h3 class="sec">Qué corregir, en orden de prioridad</h3>`;
    if (!d.fallas.length) h += `<div class="card"><p>Sin fallas repetidas. ¡Buen trabajo!</p></div>`;
    d.fallas.forEach((f, i) => {
      h += `<div class="card falla ${f.gravedad}"><div class="row sb"><h4>${i + 1}. ${e(f.titulo)}</h4><span class="badge ${f.gravedad}">${f.gravedad}</span></div>
        <p class="note">${f.golpes.length ? `En ${f.golpes.length} de ${d.usados} golpes` : 'En toda la serie'}${f.rango ? ` · medido ${fmtNum(f.metrica, f.valor)}, lo esperado es ${fmtRango(f.metrica, f.rango)}` : ''}</p>
        <p><b>Por qué importa.</b> ${e(f.porque)}</p><p><b>Cómo corregir.</b> ${e(f.corregir)}</p><p><b>Ejercicio.</b> ${e(f.ejercicio)}</p></div>`;
    });
    /* claves del golpe */
    if (def.claves) {
      const bases = (K.BASES[def.id] || []).concat(K.BASES.general);
      const ref = ids => ids.map(id => { const f = K.FUENTES.find(x => x.id === id); return f ? `<a href="${e(f.url)}" target="_blank" rel="noopener">${e(f.corta)}</a>` : ''; }).join('; ');
      const escu = K.ESCUELAS.find(x => x.id === perfil.escuela);
      h += `<div class="card"><h3>Claves del ${e(def.nombre.toLowerCase())}</h3><ul>${def.claves.map(c => `<li>${e(c)}</li>`).join('')}</ul>
        <h4>Qué dice la investigación</h4><ul class="bases">${bases.map(([t, ids]) => `<li>${e(t)} <span class="note">(${ref(ids)})</span></li>`).join('')}</ul>
        ${escu ? `<p class="note"><b>${e(escu.nombre)}:</b> ${e(escu.resumen)} ${e(escu.evidencia)}</p>` : ''}</div>`;
    }
    /* golpe a golpe */
    h += `<div class="card"><h3>Golpe a golpe</h3><div class="tabla"><table><tr><th>#</th><th>Lado</th><th>Tipo</th><th>Puntaje</th>${d.pelota ? '<th>Impacto</th><th>Paleta</th><th>km/h</th>' : ''}<th>Fallas</th></tr>${d.golpes.map(g => `<tr class="${g.coincide ? '' : 'otro'}"><td>${g.n}</td><td>${g.medidas.lado === 'reves' ? 'Revés' : 'Derecho'}</td><td>${e(K.NOMBRE_TIPO[g.medidas.tipo])}</td><td><b class="${color(g.puntaje)}">${Math.round(g.puntaje)}</b></td>${d.pelota ? `<td>${e(Pel.nombreFase(g.medidas.fase).replace('en la ', '').replace('en el ', '') || '—')}</td><td>${e(Pel.nombrePaleta(g.medidas.paleta) || '—')}</td><td>${g.medidas.velSalida || '—'}</td>` : ''}<td>${Object.entries(g.ev).filter(([, v]) => v.dir !== 'ok').map(([k, v]) => e(((K.FALLAS[k] || {})[v.dir] || {}).titulo || k)).join(', ') || '—'}</td></tr>`).join('')}</table></div>
      ${d.distintos ? '<p class="note">Las filas en gris no corresponden al golpe pedido y no se usaron para el diagnóstico.</p>' : ''}</div>`;
    /* mediciones promedio */
    h += `<details class="card"><summary><b>Mediciones promedio</b></summary><div class="tabla"><table>${Object.entries(d.promedios).map(([k, v]) => { const r = d.golpes[0] && d.golpes[0].ref[k]; return `<tr><td>${e(K.METRICAS[k].nombre)}</td><td><b>${fmtNum(k, v)}</b></td><td class="note">${r ? 'esperado ' + fmtRango(k, r) : ''}</td></tr>`; }).join('')}
      ${d.desplazamiento ? `<tr><td>Desplazamiento lateral</td><td><b>${(d.desplazamiento.rango * 100).toFixed(0)} cm</b></td><td></td></tr>` : ''}
      ${d.regularidad ? `<tr><td>Ritmo entre golpes</td><td><b>${d.regularidad.intervalo.toFixed(2).replace('.', ',')} s</b></td><td class="note">variación ${Math.round(d.regularidad.ritmo * 100)}%</td></tr>` : ''}</table></div>
      ${d.notas.length ? `<p class="note">${d.notas.map(e).join(' ')}</p>` : ''}</details>`;
    /* evolución */
    if (o.historial && o.historial.length > 1) {
      const pts = o.historial.slice(0, 10).reverse();
      const W = 300, H = 90, max = 100;
      const xy = pts.map((s, k) => [12 + k * (W - 24) / Math.max(1, pts.length - 1), H - 10 - (s.puntaje || 0) / max * (H - 20)]);
      h += `<div class="card"><h3>Evolución en este golpe</h3><svg viewBox="0 0 ${W} ${H}" class="evo"><polyline points="${xy.map(p => p.join(',')).join(' ')}" fill="none" stroke="#38e8a0" stroke-width="2.5"/>${xy.map((p, k) => `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="#fff"/><text x="${p[0]}" y="${p[1] - 7}" text-anchor="middle">${pts[k].puntaje}</text>`).join('')}</svg></div>`;
    }
    h += `<p class="note aviso">La app reconstruye el cuerpo a partir del video. La pelota y la paleta se siguen por su color: con poca luz, fondo del mismo color o pelota borrosa pueden no detectarse. El ángulo de la paleta se mide en el plano de la cámara y los giros en profundidad son estimados: úsala como apoyo del entrenador, no como reemplazo. Para mejores resultados graba de lado, a unos 3 m, con el cuerpo completo visible y buena luz.</p>`;
    return h + '</div>';
  }

  /* ---------- IA (gratuita, sin claves) ---------- */
  function datosIA(sesion, perfil) {
    const d = sesion.diag;
    return {
      jugador: { escuela: (K.ESCUELAS.find(x => x.id === perfil.escuela) || {}).nombre, perfil_tecnico: perfil.perfilIA || undefined, descripcion_entrenador: perfil.descripcion || undefined, edad: perfil.edad, estatura_cm: perfil.estatura, contextura: perfil.contextura, mano: perfil.mano === 'Z' ? 'zurdo' : 'diestro', nivel: perfil.nivel, estilo: (K.ESTILOS.find(x => x.id === perfil.estilo) || {}).nombre, toma: (K.TOMAS.find(x => x.id === perfil.toma) || {}).nombre, madero: perfil.madero, goma_derecho: perfil.gomaD, goma_reves: perfil.gomaR },
      pelota_y_paleta: d.pelota ? { golpes_con_pelota: d.pelota.golpesConPelota, golpes_con_paleta: d.pelota.golpesConPaleta, timing_por_golpe: d.golpes.map(g => Pel.nombreFase(g.medidas.fase) || null), paleta_por_golpe: d.golpes.map(g => Pel.nombrePaleta(g.medidas.paleta) || null), velocidad_salida_kmh: d.pelota.velSalida } : 'no detectadas',
      golpe_practicado: d.golpeNombre, golpes_detectados: d.golpes.length, golpes_evaluados: d.usados, golpes_distintos_al_pedido: d.distintos, puntaje: d.puntaje, puntajes_por_aspecto: d.puntajes,
      fallas: d.fallas.slice(0, 6).map(f => ({ falla: f.titulo, gravedad: f.gravedad, frecuencia_pct: Math.round(f.frecuencia * 100), medido: fmtNum(f.metrica, f.valor), esperado: f.rango ? fmtRango(f.metrica, f.rango) : '' }))
    };
  }
  async function redactarIA(sesion, perfil) {
    const sistema = 'Eres un entrenador experto de tenis de mesa. Escribes en español de Chile, claro y directo, para el jugador y su entrenador. No inventes mediciones: usa solo los datos entregados. Ten presente el perfil técnico del jugador (estilo y material) al interpretar las fallas. Si hay datos de pelota y paleta, comenta el timing (subida, punto alto, bajada) y el ángulo de la cara en el impacto; son estimaciones desde el video.';
    const pedido = 'Con estas mediciones de un video, redacta un informe breve (máximo 250 palabras) con: 1) diagnóstico general, 2) las tres correcciones más importantes explicadas de forma práctica, 3) un plan de entrenamiento para la próxima semana con ejercicios concretos, 4) un consejo sobre el material si corresponde. Usa párrafos cortos, sin tablas.\n\n' + JSON.stringify(datosIA(sesion, perfil));
    return limpiar(await llamarIA(sistema, pedido));
  }
  /* IA gratuita y sin claves (Pollinations). Devuelve el texto de la respuesta. */
  async function llamarIA(sistema, pedido, json) {
    const ctrl = new AbortController(); const tm = setTimeout(() => ctrl.abort(), 60000);
    try {
      const cuerpo = { model: 'openai', private: true, messages: [{ role: 'system', content: sistema }, { role: 'user', content: pedido }] };
      if (json) cuerpo.response_format = { type: 'json_object' };
      let r = await fetch('https://text.pollinations.ai/openai', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo), signal: ctrl.signal });
      if (r.ok) { const j = await r.json(); const t = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content; if (t) return t; }
      r = await fetch('https://text.pollinations.ai/' + encodeURIComponent(pedido) + '?model=openai&private=true' + (json ? '&json=true' : '') + '&system=' + encodeURIComponent(sistema), { signal: ctrl.signal });
      if (r.ok) { const t = await r.text(); if (t && t.length > 20) return t; }
      throw new Error('El servicio de IA no respondió.');
    } finally { clearTimeout(tm); }
  }
  const limpiar = t => t.replace(/\*\*/g, '').replace(/^#+\s*/gm, '').trim();

  /* Informe en un archivo HTML independiente, para compartir por WhatsApp o correo */
  function documento(sesion, perfil, fotos) {
    const css = Array.from(document.styleSheets).map(s => { try { return Array.from(s.cssRules).map(r => r.cssText).join('\n'); } catch (x) { return ''; } }).join('\n');
    return `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Informe Paleta · ${e(perfil.nombre || '')}</title><style>${css}</style></head><body class="doc"><main class="wrap"><h1>Paleta · Informe de técnica</h1>${html(sesion, perfil, { fotos })}</main></body></html>`;
  }

  return { html, cambios, resumenLocal, fotograma, redactarIA, llamarIA, documento, fmtNum, fmtRango, fecha, e };
})();

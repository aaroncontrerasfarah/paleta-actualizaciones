/* Paleta — informe del video: diagnóstico, fallas priorizadas, fotogramas, ejercicios, material, toma
   y redacción con IA (gratuita, sin claves). Siempre hay un informe completo sin internet. */
"use strict";
const Informe = (() => {
  const e = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmtNum = (k, v) => {
    if (typeof v !== 'number' || !isFinite(v)) return '—';
    if (k === 'fase') return `${Pel.nombreFase(v)} (${v.toFixed(2).replace('.', ',')})`;
    if (k === 'paleta') return Pel.nombrePaleta(v);
    const u = (K.METRICAS[k] || {}).unidad || '';
    if (u === '°') return Math.round(v) + '°';
    if (u === 's') return v.toFixed(2).replace('.', ',') + ' s';
    if (u === 'cm') return Math.round(v) + ' cm';
    return v.toFixed(2).replace('.', ',') + ' ' + u;
  };
  const fmtRango = (k, r) => !r ? '' : k === 'fase' ? `entre ${Pel.nombreFase(r[0]).replace('en ', '')} y ${Pel.nombreFase(r[1]).replace('en ', '')}` : k === 'paleta' ? `de ${Pel.nombrePaleta(r[0])} a ${Pel.nombrePaleta(r[1])}` : `${fmtNum(k, r[0])} a ${fmtNum(k, r[1])}`;
  const fecha = f => { try { return new Date(f).toLocaleString('es-CL', { dateStyle: 'medium', timeStyle: 'short' }); } catch (x) { return f; } };
  const color = p => p >= 80 ? 'bien' : p >= 60 ? 'regular' : 'mal';

  /* Texto de lo que cambia en la animación corregida, por golpe */
  function cambios(diag) {
    const o = {};
    for (const g of diag.golpes) {
      const t = Object.entries(g.metas).map(([k, v]) => `${(K.METRICAS[k] || {}).nombre || k}: ${fmtNum(k, g.medidas[k])} → ${fmtNum(k, v)}`);
      o[g.n] = t.length ? t.slice(0, 3).join(' · ') : 'Golpe correcto';
    }
    return o;
  }

  /* Resumen escrito sin internet */
  function resumenLocal(diag, perfil) {
    const nombre = (perfil.nombre || 'El jugador').split(' ')[0];
    const p = [];
    if (!diag.golpes.length) return 'No se detectaron golpes en el video. Revisa que se vea el cuerpo completo y que el jugador golpee durante la grabación.';
    p.push(`${nombre} realizó ${diag.golpes.length} golpes en ${Math.round(diag.duracion)} segundos; se evaluaron ${diag.usados} como ${diag.golpeNombre.toLowerCase()}. Puntaje técnico: ${diag.puntaje} de 100.`);
    if (diag.distintos > 0 && !Ev.golpe(diag.golpeId).libre) p.push(`${diag.distintos} golpes no se parecen al golpe pedido (por ejemplo, otro lado o un movimiento distinto). Puede ser un error de ejecución o que el ejercicio se mezcló.`);
    const f = diag.fallas.slice(0, 3);
    if (!f.length) p.push('No aparecen fallas repetidas: la técnica está dentro de los rangos esperados para su nivel y estilo. El siguiente paso es aumentar la velocidad y la regularidad.');
    else {
      p.push('Lo más importante para corregir: ' + f.map((x, i) => `${i + 1}) ${x.titulo.toLowerCase()} (en ${Math.round(x.frecuencia * 100)}% de los golpes)`).join('; ') + '.');
      p.push(`Primera prioridad: ${f[0].corregir}`);
    }
    const conFalla = new Set(f.map(x => (K.METRICAS[x.metrica] || {}).grupo));
    const fuertes = Object.entries(diag.puntajes).filter(([k, v]) => v >= 85 && !conFalla.has(k)).map(([k]) => k.toLowerCase());
    if (fuertes.length) p.push(`Puntos fuertes: ${fuertes.join(', ')}.`);
    return p.join('\n\n');
  }

  /* Fotograma del golpe con el esqueleto dibujado y las fallas en rojo */
  async function fotograma(sesion, nGolpe, diag) {
    const g = diag.golpes.find(x => x.n === nGolpe); if (!g) return null;
    const iRef = typeof g.medidas.iContacto === 'number' ? g.medidas.iContacto : g.golpe.impacto;
    const t = sesion.cuadros[iRef].t;
    const c = document.createElement('canvas'); let cuadro;
    const ctx = c.getContext('2d');
    if (sesion.miniaturas && sesion.miniaturas.length) {
      const mini = sesion.miniaturas.reduce((a, b) => Math.abs(b.t - t) < Math.abs(a.t - t) ? b : a);
      const img = new Image(); img.src = mini.img;
      await new Promise(r => { img.onload = r; img.onerror = r; });
      c.width = img.naturalWidth || 320; c.height = img.naturalHeight || 180; ctx.drawImage(img, 0, 0);
      cuadro = sesion.cuadros.reduce((a, b) => Math.abs(b.t - mini.t) < Math.abs(a.t - mini.t) ? b : a);
    } else {
      if (!sesion.cuadros[iRef].n) return null;
      c.width = 320; c.height = 180; ctx.fillStyle = '#10201b'; ctx.fillRect(0, 0, 320, 180); cuadro = sesion.cuadros[iRef];
    }
    const rojo = []; Object.entries(g.ev).forEach(([k, v]) => { if (v.dir !== 'ok') rojo.push(...Ev.articulacionesZona((K.METRICAS[k] || {}).zona, sesion.mano)); });
    Pose.dibujar(ctx, cuadro.n, c.width, c.height, { grosor: 2.5, rojo });
    Pose.dibujarExtras(ctx, cuadro, c.width, c.height);
    const etiqueta = [Pel.nombreFase(g.medidas.fase), g.medidas.paleta !== undefined ? 'paleta ' + Pel.nombrePaleta(g.medidas.paleta) : ''].filter(Boolean).join(' · ');
    if (etiqueta) { ctx.fillStyle = '#000b'; ctx.fillRect(0, c.height - 22, c.width, 22); ctx.fillStyle = '#fff'; ctx.font = 'bold 12px sans-serif'; ctx.fillText(etiqueta, 6, c.height - 7); }
    return c.toDataURL('image/jpeg', 0.8);
  }

  function pelotaHTML(d) {
    if (!d.pelota) return `<div class="card"><h3>Pelota y paleta</h3><p class="note">En esta grabación no se pudo seguir la pelota ni la paleta. Para medir el timing y el ángulo de la paleta: buena luz, pelota de color que contraste con el fondo, la mano con la paleta visible y, si se puede, 60 cuadros por segundo.</p></div>`;
    const usados = d.golpes.filter(g => g.coincide || Ev.golpe(d.golpeId).libre);
    const fases = usados.map(g => g.medidas.fase).filter(x => typeof x === 'number');
    const pals = usados.map(g => g.medidas.paleta).filter(x => typeof x === 'number');
    const cuenta = { subida: 0, alto: 0, bajada: 0 }; fases.forEach(f => { if (f < 0.75) cuenta.subida++; else if (f <= 1.2) cuenta.alto++; else cuenta.bajada++; });
    const ref = (k) => { const g = d.golpes.find(x => x.ref[k]); return g ? g.ref[k] : null; };
    const media = a => a.reduce((x, y) => x + y, 0) / a.length;
    let h = `<div class="card"><h3>Pelota y paleta</h3>
      <p class="note">Pelota seguida en ${d.pelota.golpesConPelota} de ${d.golpes.length} golpes · paleta medida en ${d.pelota.golpesConPaleta}.</p>`;
    if (fases.length) h += `<p><b>Timing:</b> ${cuenta.subida} en la subida · ${cuenta.alto} en el punto más alto · ${cuenta.bajada} en la bajada.${ref('fase') ? ` Para este golpe se espera golpear ${fmtRango('fase', ref('fase'))}.` : ''}</p>
      <div class="fases"><i style="flex:${cuenta.subida || 0.001}" class="f1"></i><i style="flex:${cuenta.alto || 0.001}" class="f2"></i><i style="flex:${cuenta.bajada || 0.001}" class="f3"></i></div><div class="fases-ley"><span><i class="f1"></i>Subida</span><span><i class="f2"></i>Punto alto</span><span><i class="f3"></i>Bajada</span></div>`;
    else h += `<p class="note">No se pudo ver el bote de la pelota antes del golpe, así que no se midió el timing.</p>`;
    if (pals.length) h += `<p><b>Paleta en el impacto:</b> en promedio ${Pel.nombrePaleta(media(pals))}${ref('paleta') ? ` (esperado ${fmtRango('paleta', ref('paleta'))})` : ''}.</p>`;
    if (d.pelota.velSalida) h += `<p><b>Velocidad de salida:</b> unos ${d.pelota.velSalida} km/h <span class="note">(estimada en el plano de la cámara; la real suele ser algo mayor)</span>.</p>`;
    return h + '</div>';
  }

  /* HTML del informe */
  function html(sesion, perfil, opc) {
    const d = sesion.diag, o = opc || {};
    const def = Ev.golpe(d.golpeId);
    const plegar = (titulo, cuerpo, abierta) => `<details class="pl" ${abierta ? 'open' : ''}><summary><span><b>${titulo}</b></span>${I('adelante', 'flecha')}</summary><div class="pl-cuerpo">${cuerpo}</div></details>`;
    let h = `<div class="inf">`;
    if (!o.embebido) h += `<div class="inf-cab"><div class="aro ${color(d.puntaje)}"><b>${d.puntaje}</b><small>de 100</small></div><div><h2>${e(d.golpeNombre)}</h2><p class="note">${e(perfil.nombre || '')} · ${fecha(sesion.fecha)}</p></div></div>`;
    /* 1. Qué mejorar: lo más importante, claro y corto */
    h += `<h3 class="sec">Qué mejorar</h3>`;
    if (!d.fallas.length) h += `<div class="card mejora ok"><b>${I('check')} Técnica dentro de lo esperado</b><p>Sigue así: el siguiente paso es aumentar la velocidad y la regularidad.</p></div>`;
    d.fallas.slice(0, 3).forEach((f, i) => {
      h += `<div class="card mejora ${f.gravedad}">
        <div class="mejora-cab"><span class="num">${i + 1}</span><b>${e(f.titulo)}</b></div>
        ${f.rango ? `<div class="medida"><span>Tú: <b>${fmtNum(f.metrica, f.valor)}</b></span><span>Ideal: <b>${fmtRango(f.metrica, f.rango)}</b></span></div>${regla(f)}` : ''}
        <p class="mejora-que">${e(f.corregir)}</p>
        <details class="mini"><summary>Por qué y ejercicio</summary><p>${e(f.porque)}</p><p><b>Ejercicio:</b> ${e(f.ejercicio)}</p></details>
        <p class="note">${f.golpes.length ? `En ${f.golpes.length} de ${d.usados} golpes` : 'En toda la serie'}</p></div>`;
    });
    if (d.fallas.length > 3) h += plegar(`Otras ${d.fallas.length - 3} observaciones`, d.fallas.slice(3).map(f => `<div class="obs"><b>${e(f.titulo)}</b><span class="note">${f.rango ? `${fmtNum(f.metrica, f.valor)} · ideal ${fmtRango(f.metrica, f.rango)}` : ''}</span><p>${e(f.corregir)}</p></div>`).join(''));
    /* 2. Cada golpe */
    h += `<h3 class="sec">Cada golpe</h3><div class="golpes-lista">${d.golpes.map(g => {
      const malas = Object.entries(g.ev).filter(([, v]) => v.dir !== 'ok' && v.dev > 0.08).sort((a, b) => b[1].dev - a[1].dev);
      const t = malas[0] ? ((K.FALLAS[malas[0][0]] || {})[malas[0][1].dir] || {}).titulo : 'Bien';
      return `<button class="golpe-chip ${g.coincide ? '' : 'otro'}" data-ir-golpe="${g.n}"><span class="nota-g ${color(g.puntaje)}">${Math.round(g.puntaje)}</span><span><b>Golpe ${g.n}</b><small>${e(t)}</small></span></button>`; }).join('')}</div>
      ${d.distintos ? `<p class="note">Los golpes atenuados no parecen ${e(def.nombre.toLowerCase())} y no se usaron.</p>` : ''}`;
    /* 3. Resumen y detalle, plegados */
    h += `<h3 class="sec">Detalle</h3>`;
    h += plegar('Resumen escrito', `<div class="texto">${e(sesion.resumenIA || resumenLocal(d, perfil)).replace(/\n/g, '<br>')}</div>
      ${o.conIA ? `<div class="row"><button class="btn sm" data-a="ia">${I('ia')} ${sesion.resumenIA ? 'Volver a redactar con IA' : 'Redactar con IA'}</button></div><p class="note" id="ia-estado"></p>` : ''}`);
    h += plegar('Puntaje por aspecto', barrasAspecto(d.puntajes));
    h += plegar('Pelota, timing y paleta', pelotaHTML(d).replace(/^<div class="card"><h3>Pelota y paleta<\/h3>/, '').replace(/<\/div>$/, ''));
    h += plegar('Fotogramas', `<div class="fotos" id="fotos">${o.fotos ? o.fotos : '<p class="note">Preparando fotogramas…</p>'}</div>`);
    if (o.historial && o.historial.length > 1) h += plegar('Evolución en este golpe', evolucion(o.historial));
    if (def.claves) {
      const bases = (K.BASES[def.id] || []).concat(K.BASES.general);
      const ref = ids => ids.map(id => { const f = K.FUENTES.find(x => x.id === id); return f ? `<a href="${e(f.url)}" target="_blank" rel="noopener">${e(f.corta)}</a>` : ''; }).join('; ');
      const escu = K.ESCUELAS.find(x => x.id === perfil.escuela);
      h += plegar('Cómo se hace bien y qué dice la investigación', `<ul class="lista-limpia">${def.claves.map(c => `<li>${e(c)}</li>`).join('')}</ul>
        <h4 class="sub">Investigación</h4><ul class="bases">${bases.map(([t, ids]) => `<li>${e(t)} <span class="note">(${ref(ids)})</span></li>`).join('')}</ul>
        ${escu ? `<p class="note"><b>${e(escu.nombre)}:</b> ${e(escu.resumen)}</p>` : ''}`);
    }
    h += plegar('Todas las mediciones', `<div class="tabla"><table>${Object.entries(d.promedios).map(([k, v]) => { const r = d.golpes[0] && d.golpes[0].ref[k]; return `<tr><td>${e(K.METRICAS[k].nombre)}</td><td><b>${fmtNum(k, v)}</b></td><td class="note">${r ? fmtRango(k, r) : ''}</td></tr>`; }).join('')}</table></div>
      ${d.notas.length ? `<p class="note">${d.notas.map(e).join(' ')}</p>` : ''}`);
    if (perfil.perfilIA) h += plegar('Perfil técnico del jugador', `<div class="texto">${e(perfil.perfilIA).replace(/\n/g, '<br>')}</div>`);
    h += `<p class="note aviso">Mediciones estimadas a partir del video. Graba de lado, a unos 3 m, con el cuerpo completo y buena luz. Es un apoyo para el entrenador, no un reemplazo.</p>`;
    return h + '</div>';
  }
  /* Regla visual: dónde está el valor del jugador respecto del rango ideal */
  function regla(f) {
    const [a, b] = f.rango, ancho = b - a || 1, min = Math.min(a - ancho * 0.6, f.valor), max = Math.max(b + ancho * 0.6, f.valor);
    const x = v => ((v - min) / (max - min) * 100).toFixed(1);
    return `<div class="regla" aria-hidden="true"><i class="zona" style="left:${x(a)}%;width:${(x(b) - x(a)).toFixed(1)}%"></i><i class="punto" style="left:${x(f.valor)}%"></i></div>`;
  }
  function barrasAspecto(p) {
    return `<div class="aspectos">${Object.entries(p).map(([k, v]) => `<div class="aspecto"><div class="row sb"><span>${e(k)}</span><b class="${color(v)}">${v}</b></div><div class="pista"><i class="${color(v)}" style="width:${v}%"></i></div></div>`).join('')}</div>`;
  }
  function evolucion(hist) {
    const pts = hist.slice(0, 10).reverse(), W = 320, H = 120, pad = 18;
    const xy = pts.map((s, k) => [pad + k * (W - 2 * pad) / Math.max(1, pts.length - 1), H - pad - (s.puntaje || 0) / 100 * (H - 2 * pad)]);
    const linea = xy.map(p => p.join(',')).join(' ');
    return `<svg viewBox="0 0 ${W} ${H}" class="evo" role="img" aria-label="Evolución del puntaje">
      ${[0, 50, 100].map(v => { const y = H - pad - v / 100 * (H - 2 * pad); return `<line x1="${pad}" x2="${W - pad}" y1="${y}" y2="${y}" class="guia"/><text x="2" y="${y + 3}" class="eje">${v}</text>`; }).join('')}
      <polygon points="${xy[0][0]},${H - pad} ${linea} ${xy[xy.length - 1][0]},${H - pad}" class="area"/>
      <polyline points="${linea}" class="trazo"/>${xy.map((p, k) => `<circle cx="${p[0]}" cy="${p[1]}" r="4" class="pto"/><text x="${p[0]}" y="${p[1] - 9}" text-anchor="middle" class="val">${pts[k].puntaje}</text>`).join('')}</svg>`;
  }

  /* ---------- IA (gratuita, sin claves) ---------- */
  function datosIA(sesion, perfil) {
    const d = sesion.diag;
    return {
      jugador: { escuela: (K.ESCUELAS.find(x => x.id === perfil.escuela) || {}).nombre, perfil_tecnico: perfil.perfilIA || undefined, descripcion_entrenador: perfil.descripcion || undefined, edad: perfil.edad, estatura_cm: perfil.estatura, contextura: perfil.contextura, mano: perfil.mano === 'Z' ? 'zurdo' : 'diestro', nivel: perfil.nivel, estilo: (K.ESTILOS.find(x => x.id === perfil.estilo) || {}).nombre, toma: (K.TOMAS.find(x => x.id === perfil.toma) || {}).nombre, madero: perfil.madero, goma_derecho: perfil.gomaD, goma_reves: perfil.gomaR },
      pelota_y_paleta: d.pelota ? { golpes_con_pelota: d.pelota.golpesConPelota, golpes_con_paleta: d.pelota.golpesConPaleta, timing_por_golpe: d.golpes.map(g => Pel.nombreFase(g.medidas.fase) || null), paleta_por_golpe: d.golpes.map(g => Pel.nombrePaleta(g.medidas.paleta) || null), velocidad_salida_kmh: d.pelota.velSalida } : 'no detectadas',
      golpe_practicado: d.golpeNombre, golpes_detectados: d.golpes.length, golpes_evaluados: d.usados, golpes_distintos_al_pedido: d.distintos, puntaje: d.puntaje, puntajes_por_aspecto: d.puntajes,
      fallas: d.fallas.slice(0, 6).map(f => ({ falla: f.titulo, gravedad: f.gravedad, frecuencia_pct: Math.round(f.frecuencia * 100), medido: fmtNum(f.metrica, f.valor), esperado: f.rango ? fmtRango(f.metrica, f.rango) : '' }))
    };
  }
  async function redactarIA(sesion, perfil) {
    const sistema = 'Eres un entrenador experto de tenis de mesa. Escribes en español de Chile, claro y directo, para el jugador y su entrenador. No inventes mediciones: usa solo los datos entregados. Ten presente el perfil técnico del jugador (estilo y material) al interpretar las fallas. Si hay datos de pelota y paleta, comenta el timing (subida, punto alto, bajada) y el ángulo de la cara en el impacto; son estimaciones desde el video.';
    const pedido = 'Con estas mediciones de un video, redacta un informe breve (máximo 250 palabras) con: 1) diagnóstico general, 2) las tres correcciones más importantes explicadas de forma práctica, 3) un plan de entrenamiento para la próxima semana con ejercicios concretos, 4) un consejo sobre el material si corresponde. Usa párrafos cortos, sin tablas.\n\n' + JSON.stringify(datosIA(sesion, perfil));
    return limpiar(await llamarIA(sistema, pedido));
  }
  /* IA gratuita y sin claves (Pollinations). Devuelve el texto de la respuesta. */
  async function llamarIA(sistema, pedido, json) {
    const ctrl = new AbortController(); const tm = setTimeout(() => ctrl.abort(), 60000);
    try {
      const cuerpo = { model: 'openai', private: true, messages: [{ role: 'system', content: sistema }, { role: 'user', content: pedido }] };
      if (json) cuerpo.response_format = { type: 'json_object' };
      let r = await fetch('https://text.pollinations.ai/openai', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo), signal: ctrl.signal });
      if (r.ok) { const j = await r.json(); const t = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content; if (t) return t; }
      r = await fetch('https://text.pollinations.ai/' + encodeURIComponent(pedido) + '?model=openai&private=true' + (json ? '&json=true' : '') + '&system=' + encodeURIComponent(sistema), { signal: ctrl.signal });
      if (r.ok) { const t = await r.text(); if (t && t.length > 20) return t; }
      throw new Error('El servicio de IA no respondió.');
    } finally { clearTimeout(tm); }
  }
  const limpiar = t => t.replace(/\*\*/g, '').replace(/^#+\s*/gm, '').trim();

  /* Informe en un archivo HTML independiente, para compartir por WhatsApp o correo */
  function documento(sesion, perfil, fotos) {
    const css = Array.from(document.styleSheets).map(s => { try { return Array.from(s.cssRules).map(r => r.cssText).join('\n'); } catch (x) { return ''; } }).join('\n');
    return `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Informe Paleta · ${e(perfil.nombre || '')}</title><style>${css}</style></head><body class="doc"><main class="wrap"><h1>Paleta · Informe de técnica</h1>${html(sesion, perfil, { fotos })}</main></body></html>`;
  }

  return { html, cambios, resumenLocal, fotograma, redactarIA, llamarIA, documento, fmtNum, fmtRango, fecha, e };
})();

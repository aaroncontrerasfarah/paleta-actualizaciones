/* Paleta — íconos de línea propios (24 × 24, trazo del color del texto). Uso: I('grabar') */
"use strict";
const ICONOS = {
  inicio: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h5v-6h4v6h5V9.5"/>',
  alumnos: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c2.8.2 5 2.5 5 5.3"/>',
  perfil: '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c0-4.1 3.4-7.2 7.5-7.2s7.5 3.1 7.5 7.2"/>',
  grabar: '<rect x="3" y="6" width="13" height="12" rx="2.5"/><path d="m16 10.5 5-3v9l-5-3"/>',
  tactica: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
  mas: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  paleta: '<circle cx="10" cy="10" r="6.5"/><path d="m14.6 14.6 5.4 5.4"/><circle cx="18.5" cy="5.5" r="1.8"/>',
  galeria: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="9.5" r="1.7"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
  play: '<path d="M7 5v14l11-7z"/>',
  pausa: '<path d="M8 5v14M16 5v14"/>',
  anterior: '<path d="M6 5v14M18 6l-9 6 9 6z"/>',
  siguiente: '<path d="M18 5v14M6 6l9 6-9 6z"/>',
  regla: '<path d="M4 15 15 4l5 5L9 20z"/><path d="m8 11 2 2M11 8l2 2M14 5l2 2"/>',
  foco: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  ia: '<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  ubicacion: '<path d="M12 21s-6.5-6-6.5-11a6.5 6.5 0 0 1 13 0c0 5-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  mano: '<path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7c0 4-2.5 7-6.5 7S5 17.5 4.2 15l-1-3a1.4 1.4 0 0 1 2.6-1L8 14"/>',
  postura: '<circle cx="12" cy="4.5" r="2"/><path d="M12 7v6l-3 7M12 13l3 7M7 10l5-1 5 1"/>',
  camara: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  cruz: '<path d="M6 6l12 12M18 6 6 18"/>',
  atras: '<path d="M15 5l-7 7 7 7"/>',
  adelante: '<path d="M9 5l7 7-7 7"/>',
  compartir: '<path d="M12 15V4M8 8l4-4 4 4"/><path d="M5 13v6h14v-6"/>',
  borrar: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  libro: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5"/>',
  estrella: '<path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
  alerta: '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4.5M12 17.5v.5"/>',
  capas: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>'
};
function I(nombre, clase) {
  const d = ICONOS[nombre] || '';
  const relleno = nombre === 'play' ? 'currentColor' : 'none';
  return `<svg class="ic${clase ? ' ' + clase : ''}" viewBox="0 0 24 24" width="22" height="22" fill="${relleno}" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
}
